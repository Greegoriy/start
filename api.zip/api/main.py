#! /usr/local/basement/Python-3.7.4/bin/python3.7
#! /usr/bin/python3 


# import uvicorn
# from fastapi import FastAPI
import json
from typing import Union, List


from db_connectors import PostgresConnection, pg_pool
from schemas import User_Query
from query_search import fields_update, search_query


# app = FastAPI()

pg = PostgresConnection(pg_pool)

# @app.get('/')
def home():
    return {'key':'Hello world2 '}


# @app.get('/filters')
def filters():
    query_system = """
    SELECT DISTINCT
        it_code,
        name_system,
        status,
        owner_company,
        international_name,
        identifier,
        sg_global_id,
        alternative_name,
        producer,
        domain_owner_it_system,
        it_system_owner,
        responsible_employee_system_owner,
        development_department,
        responsible_for_development,
        application_manager,
        information_security_officer,
        "date",
        development_start_date,
        commissioning_date,
        start_date_shutdown,
        decommissioning_date,
        type_of_use,
        development_type,
        hosting_type,
        access_category,
        sensitivity,
        sensitivity_assessment_date,
        pci_dss_processing,
        green_book_compliance,
        internet_access,
        fraud_sensitive,
        integirty,
        confidentiality,
        availability,
        sensivity_category,
        vital,
        rto_target,
        rpo_target,
        note,
        last_modified_date
    FROM dq_sbx.registry_it_system
    WHERE  it_code in (SELECT distinct it_code FROM dq_sbx.descr_tab)
    ORDER BY name_system
    """
    query_owner = """
    SELECT contact_person
    FROM dq_sbx.descr_col
    WHERE contact_person IS NOT NULL
    GROUP BY contact_person
    ORDER BY contact_person
    """
    query_domain = """
    SELECT domain_data_owner
    FROM dq_sbx.descr_col
    WHERE domain_data_owner IS NOT NULL
    GROUP BY domain_data_owner
    ORDER BY domain_data_owner
    """
    system = pg.getData(query_system).to_dict('list')
    owner = pg.getData(query_owner).to_dict('list')
    domain = pg.getData(query_domain).to_dict('list')
    return system, owner, domain


# @app.post('/query55')
def search_item(item: User_Query):
    item = User_Query(**item)
    item = fields_update(item)
    query = search_query(item)
    return pg.getData(query).columns.tolist(), pg.getData(query).values.tolist()



# @app.post('/query')
def create_item(item: User_Query):
    query = User_Query(**item)
    query = fields_update(query)
    return pg.getData(search_query(query))#.to_dict('list')

# @app.post('/query1')
def create_item1(item: User_Query):
    query = User_Query(**item)
    query = fields_update(query)
    return pg.getData(search_query(query)).to_dict('list')


# @app.post('/query2')
def create_item2(item: User_Query):
    query = User_Query(**item)
    query = fields_update(query)
    return pg.getData(search_query(query)).T.to_dict('list')

# @app.post('/query3')
def create_item3(item: User_Query):
    query = User_Query(**item)
    query = fields_update(query)
    return pg.getData(search_query(query)).columns.tolist(), pg.getData(search_query(query)).values.tolist()


# @app.post('/test')
def create_item_test(item: User_Query):
    query = User_Query(**item)
    return query


search ={
    "query":"        profiling'    ",
    "odpp":True,
    "fields_tab":["table", "tab_comment"],
    "fields_col":["col_name", "col_comment","entity_name"],
    "filters_tab":[
        {
            "field":"it_code",
            "value": ["ci467113","ci22222"]
            }
        ]
    , 
    "filters_col":[
        {
            "field":"contact_person",
            "value": ["розумеенко марина сергеевна","test" ]
        }
        , 
        {
            "field":"domain_data_owner",
            "value": ["data","test" ]
        } 
        ]     
        ,
    "limit": 5
}

print(search_item(search))




# if __name__ == "__main__":
#     config = uvicorn.Config("main:app", port=8000, log_level="info", workers=2)
#     server = uvicorn.Server(config)
#     server.run()


