from pydantic import BaseModel, validator
from datetime import date
from typing import Optional, List, Dict, Set, Union
import re



class Filters_Dict(BaseModel):
    field: str
    value: List[str]


class User_Query(BaseModel):
    query: str = ''
    odpp: bool=False
    fields_tab: Optional[Set[str]]
    fields_col: Optional[Set[str]]

    filters_tab: Optional[List[Filters_Dict]]
    filters_col: Optional[List[Filters_Dict]]
    limit: int = 0

    @validator('query')
    def str_to_lower(cls, query: str):
        return query.lower().replace("'",'').replace('"','').replace('%','').replace('\\','').strip()
    

class Table_Info(BaseModel):
    table_code: str

