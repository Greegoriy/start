import pandas as pd


class DuplicateRowsError(Exception):
    def __init__(self, df: pd.DataFrame) -> None:
        self.__df = df
        self.__message = f'Наличие дубликатов в таблице: \n {df} \n'
        super().__init__(self.__message)
     
    @property
    def error_dataframe(self):
        return self.__df  

    
class InitializationDataFrameError(Exception):
    def __init__(self) -> None:
        self.__message = 'Ошибка инициализации датафрейма'
        super().__init__(self.__message)
        
        
class LoadingDataError(Exception):
    def __init__(self) -> None:
        self.__message = 'Ошибка при загрузке данных'
        super().__init__(self.__message)