import datetime
import pandas as pd
import numpy as np
from typing import Optional, Union, Dict, List
import warnings


# импорт собственных библиотек
from postgres_connector import *
from logger import Logger
from description_exceptions import *


# настройка pandas
warnings.filterwarnings('ignore', category=UserWarning, module='openpyxl')
pd.set_option('display.max_rows', 10000)
pd.set_option('display.max_columns', 100)
pd.set_option('display.width', 1000)

# получение файлового логера
descr_logger = Logger.create_file_logger('descr_logger', 'descr_logger.log')

def read_excel(file_name: str) -> pd.DataFrame:
    """Функция для преобразования экселя в формат датафрейма"""
    
    df = pd.read_excel(file_name)
    exception_args = ['технические поля', 'описательные поля', 'обязательные поля' ,'https://sm.rosbank.rus.socgen/login/files/Registry_IT_System.xlsx']
    
    df = (df
        .rename(columns={'It система (код)*':'it_code',
                         'Схема БД источника*':'src_schema',
                         'Наименование Таблицы в источнике*':'src_table',
                         'Имя колонки (атрибута)*':'col_name',
                         'Бизнес-описание атрибута*':'col_comment',
                         'Бизнес-описание таблицы*':'tab_comment',
                         'Бизнес сущность BE (Business Entry) ':'entity_name',
                         'Контактное лицо для решения вопросов при выявлении аномалий ("Владелец данных rbxxxxxxx")*':'rb',
                         'Контактное лицо для решения вопросов при выявлении аномалий ("Владелец данных ФИО")*':'contact_person',
                         'Группа перс данных (по классификации ИБ C0-C3, C0 – дефолтное значение)':'personal_data_group',
                         'Тип данных атрибута':'col_type',
                         'Домен*': 'domain_data_owner', 
                         'Требования к качеству атрибута (формат / обязательность заполнения и т.п.)':'attribute_quality'})
         .query('src_schema not in @exception_args'))
    df = df[df.notnull().any(axis=1)]
    return df


class DescriptionLoading:
    """Класс для загрузки описаний атрибутов в БД описаний"""
    
    __success_tasks = 0
    __failed_tasks = 0
    
    # Словарь таблиц и их целевых колонок
    __main_cols_dict = {'data_group': ['personal_data_group'],
                        'col_type': ['col_type'],
                        'description_table': ['tab_comment'],  
                        'description_col': ['col_comment'],
                        'entity': ['entity_name'],
                        'quality':['attribute_quality'],
                        'data_owner': ['contact_person', 'rb', 'domain_data_owner']}
    
    
    def __init__(self, df: pd.DataFrame) -> None:
        self.__df_sample = self.__get_df_sample(df)
    
    
    def __get_df_sample(self, source_df: pd.DataFrame) -> Optional[pd.DataFrame]:
        """Функция для получения обработанного датафрейма"""     
        
        descr_logger.info('RUNNING OF NEW DESCRIPTION LOADING')
        null_key_columns = self.__is_key_columns_contains_null(source_df)
        null_personal_data = self.__is_personal_data_contains_null(source_df)
                
        if null_personal_data or null_key_columns:
            descr_logger.info('ENDING OF DESCRIPTION LOADING')
            raise InitializationDataFrameError
        else:
            df_sample = self.__initial_data_transform(source_df) 
            return df_sample 
    
    
    @staticmethod
    def __display_and_log_error(error: str, error_df: pd.DataFrame) -> None:
        """Функция для отображения и логгирования ошибок"""
        
        print(error)
        display(error_df)
        descr_logger.error(f'{error} \n  {error_df} \n')
    

    @staticmethod              
    def __get_rows_with_null(df_sample: pd.DataFrame, key_columns: List[str]) -> pd.DataFrame:
        """Функция для проверки пустых строк по определенныи столбцам"""
        
        df_with_key_cols = df_sample[key_columns].dropna(how='all')
        null_values_df = df_with_key_cols[df_with_key_cols.isnull().any(axis=1)]
        return null_values_df
    
    
    @classmethod              
    def __is_personal_data_contains_null(self, df_sample: pd.DataFrame) -> bool:
        """Функция для проверки заполнения столбцов контактных данных"""
        
        key_cols = ['contact_person', 'rb', 'domain_data_owner']
        null_personal_data_df = self.__get_rows_with_null(df_sample, key_cols)
        table_name = 'data_owner'
        
        if not null_personal_data_df.empty:
            error = 'Столбцы контактных данных содержат пустые значения'
            error_message = 'FAILED - ' + error + ':' 
            self.__display_and_log_error(error_message, null_personal_data_df)
            self.__log_to_db(table_name, error=error)
            return True
        return False
            
            
    @classmethod     
    def __is_key_columns_contains_null(self, df_sample: pd.DataFrame) -> bool:
        """Функция для проверки наличия пустых значений в ключевых столбцах датафрейма"""
        
        key_cols = ['it_code', 'src_schema', 'src_table', 'col_name']
        null_key_columns_df = self.__get_rows_with_null(df_sample, key_cols)
        
        if not null_key_columns_df.empty:
            error = 'Ключевые столбцы датафрейма содержат пустые значения'
            error_message = 'FAILED - ' + error + ':' 
            self.__display_and_log_error(error_message, null_key_columns_df)
            
            for table_name in self.__main_cols_dict.keys():
                self.__log_to_db(table_name, error=error)
            
            return True
        return False
          
    
    @staticmethod
    def __initial_data_transform(source_df: pd.DataFrame) -> pd.DataFrame:
        """Функция для первоначальной обработки данных в таблице"""
        
        df_sample = (source_df[source_df.notnull().any(axis=1)]
            .fillna('NULL')
            .drop_duplicates())
        
        df_sample['sampling_date'] = datetime.datetime.now().strftime('%Y-%m-%d')

        for column in df_sample.columns:
            col_unique_values = df_sample[column].unique()
            if not (len(col_unique_values) == 1 and col_unique_values[0] == 'NULL'):
                df_sample[column] = df_sample[column].str.lower().str.strip()

        return df_sample
    
    
    @classmethod
    def __convertDF_to_format(cls, df_sample: pd.DataFrame, table_name: str, schema_name: str='dq_sbx') -> Optional[pd.DataFrame]:
        """Функция для приведения датафрейму к целевой структуре таблицы в БД"""
        
        db_table_cols = get_df_from_dq_profiling(f"""
            SELECT "column_name" 
            FROM information_schema.columns 
            WHERE  table_schema = '{schema_name}' 
            AND table_name = '{table_name}'""").column_name.tolist()
        
        delta_cols = list(set(db_table_cols) - set(df_sample.columns))
        df_sample[[delta_cols]] = 'NULL'
        
        main_column = cls.__main_cols_dict[table_name][0]
        convertedDF = (df_sample[db_table_cols]
            .drop_duplicates()
            .query(f'{main_column}!="NULL"'))
        
        return convertedDF
 
    
    
    @staticmethod
    def __check_duplicates_rows(df_sample: pd.DataFrame, table_name: str) -> pd.DataFrame:
        """Функция для проверки наличия дубликатов в строках таблицы"""
        
        key_columns = ['it_code', 'src_schema', 'src_table']

        if table_name == 'description_table':
            key_df = df_sample[key_columns]
        else:
            key_columns.append('col_name')
            key_df = df_sample[key_columns]

        result_df = df_sample[key_df.duplicated(keep=False)].sort_values(by=key_columns)

        return result_df 

                                         
    def get_dataframe_by_name(self, table_name: str) -> Union[pd.DataFrame, str]:
        """Функция для получения обработанного отдельного датафрейма по названию таблицы"""
        
        df_sample = self.__df_sample.replace('null', 'NULL')
        result_df = self.__convertDF_to_format(df_sample, table_name)

        if not result_df.empty:
            duplicated_df = self.__check_duplicates_rows(result_df, table_name)
            
            if duplicated_df.empty:
                return result_df
            else:
                raise DuplicateRowsError(duplicated_df)
        else:
            return 'DataFrame is empty'
        
        
    def __check_all_tables_on_duplicates(self) -> Optional[pd.DataFrame]:
        """Функция для проверки сразу всех таблиц на дубликаты"""
        
        success_handled_dfs_dict = {}
        error = None
        
        for table_name in list(self.__main_cols_dict.keys()):
            try:
                success_handled_dfs_dict[table_name] = self.get_dataframe_by_name(table_name)
            except DuplicateRowsError as e:
                error = str(e).split(":")[0]
                display(f'ERROR - {error}: {table_name}', e.error_dataframe)
                descr_logger.error(e)
                self.__log_to_db(table_name, error=error)
            
        if not error:
            return success_handled_dfs_dict
        else:
            raise LoadingDataError       
        
        
    @staticmethod
    def __clear_line(line):  
        """Функция для возврата обработанного элемента для последующей вставки в SQL-запрос"""   
        
        if isinstance(line, (int, float, complex)):
            return line
        else:
            return str(line).replace("'", '"')
    
    
    def transform_df_to_SQL(self, df_sample: pd.DataFrame, target_table_name: str, target_schema_name: str = 'dq_sbx') -> str:
        """Функция для преобразования датафрейма в строку SQL-запроса для загрузки значений в БД"""
        
        df_sample = df_sample.fillna('NULL')
        query_list = []

        for row in df_sample.itertuples(index=False):
            query_list.append('\n' + str(tuple(map(self.__clear_line, row))).replace("'NULL'", "NULL"))

        insert_query = f'INSERT INTO {target_schema_name}.{target_table_name} VALUES' +  ', '.join(query_list)
        return insert_query
    
    
    @staticmethod
    def __log_to_db(table_name: str, number_of_rows: int=0, error: str='NULL') -> None: 
        """Функция для логирования ошибок в БД"""
        
        sampling_date = str(datetime.datetime.now())
        if error != 'NULL':
            state = 'FAILED' 
        else:
            state = 'SUCCESS'
        log_message = f"""INSERT INTO dq_sbx.description_loading_log 
                          VALUES {table_name, state, error, number_of_rows, sampling_date}"""
        log_message = log_message.replace("'NULL'", "NULL")
        execute_postgres_dq_profiling(log_message)
    
    
    @classmethod
    def __log_message(cls, message: str,  table_name: str, number_of_rows: int=0, error: str='NULL') -> None:
        """Функция для записи успешной загрузки в лог """
        
        print(message)
        descr_logger.info(message)
        cls.__log_to_db(table_name, number_of_rows, error)
    
    
    def __upload_data(self, df_to_load: pd.DataFrame, table_name: str) -> None:
        """Функция для загрузки данных в таблицы БД"""

        if isinstance(df_to_load, pd.DataFrame):
            SQL_query = self.transform_df_to_SQL(df_to_load, table_name)
            try:
                execute_postgres_dq_profiling(SQL_query)
                self.__success_tasks += 1
                df_rows_number = df_to_load.shape[0]
                log_message = f'SUCCESS: Описание данных успешно загружено в таблицу "{table_name}".'
                self.__log_message(log_message, table_name, number_of_rows=df_rows_number)
            except Exception as e:
                self.__failed_tasks += 1
                log_message = f'FAILED - Произошла ошибка во время загрузки описания в таблицу "{table_name}":{e}'
                self.__log_message(log_message, table_name, error=e)
        else:
            self.__failed_tasks += 1
            error = f'Отсутствие данных в ключевых столбцах: {", ".join(self.__main_cols_dict[table_name])}'
            log_message = f'WARNING: Описание данных не может быть загружено в таблицу "{table_name}" по причине: ' + error
            self.__log_message(log_message, table_name, error=error)
    
    
    def load_to_db(self) -> None:
        """Функция для загрузки обработанных датафреймов в таблицы БД"""

        success_handled_dfs_dict = self.__check_all_tables_on_duplicates()
        
        for table_name in list(success_handled_dfs_dict.keys()):
            df_to_load = success_handled_dfs_dict[table_name]
            self.__upload_data(df_to_load, table_name)

        status_message = '\n' + f'ALL TABLES: {self.__success_tasks + self.__failed_tasks}, SUCCESS TABLES: {self.__success_tasks}, FAILED TABLES: {self.__failed_tasks}'
        print(status_message)
        descr_logger.info(f'ENDING OF DESCRIPTION LOADING.{status_message}')

            