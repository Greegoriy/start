import logging

class Logger:
    
    def create_file_logger(logger_name: str, file_name: str) -> logging.Logger: 
        """Функция для настройки логгирования в файл"""
    
        logger = logging.getLogger(logger_name)
        logger.setLevel(logging.INFO)
        formatter = logging.Formatter(fmt='%(asctime)s - %(levelname)s - %(message)s', datefmt='%d-%m-%y %H:%M:%S')
        handler = logging.FileHandler(file_name)
        handler.setFormatter(formatter)
        logger.addHandler(handler)

        return logger