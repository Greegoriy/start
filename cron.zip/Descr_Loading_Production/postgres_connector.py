import pandas as pd
import psycopg2
from psycopg2 import sql
import os
import subprocess
import json


# json с логинами и паролями
with open("user_pass.json", "r") as read_file:
    user_pass = json.load(read_file)

    
def get_df_from_dq_profiling(query: str) -> pd.DataFrame:
    """Функция для чтения из базы данных dq_profiling в Postgres"""
    
    conn=None
    try:
        user=user_pass['user_dq_prof']
        password=user_pass['pass_dq_prof']
        dbname='dq_profiling'
        host='193.48.6.35'
        port=5432
        conn=psycopg2.connect(dbname=dbname, user=user,
                                password=password, host=host, port=port)
        cursor=conn.cursor()
 
        cursor.execute(query)
        columns=[column[0] for column in cursor.description]
        records=cursor.fetchall()
        cursor.close()
        return pd.DataFrame(data=records, columns=columns)
    except Exception as e:
        print(e)
    finally:
        if conn is not None:
            conn.close()
            
                       
def execute_postgres_dq_profiling(query: str) -> None:
    """Функция для записи в базу данных dq_profiling в Postgres"""
        
    conn=None
    try:
        user=user_pass['user_dq_prof']
        password=user_pass['pass_dq_prof']
        dbname='dq_profiling'
        host='193.48.6.35'
        port=5432
        conn=psycopg2.connect(dbname=dbname, user=user,
                                password=password, host=host, port=port)
        cursor=conn.cursor()
        cursor.execute(query)
        conn.commit()
    except Exception as e:
        raise e
    finally:
        if conn is not None:
            conn.close()
                        

