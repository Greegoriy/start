CREATE OR REPLACE FUNCTION dq_sbx.update_profiling_date()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
BEGIN
	WITH updated_tables AS (
		SELECT 
			pt.schema_name, 
			pt.table_name,
			pt.id_table
		FROM dq_sbx.profiling_table pt
		LEFT JOIN dq_sbx.info i ON i.schema_name = pt.schema_name AND i.table_name = pt.table_name AND i.id_table = pt.id_table
		WHERE pt.sampling_date >= i.last_dt_from::date OR i.last_dt_from IS NULL OR i.is_in_archive='true')
	
	UPDATE dq_sbx.profiling_table pt
	SET sampling_date = CURRENT_DATE
	FROM updated_tables c
	WHERE c.schema_name = pt.schema_name AND c.table_name = pt.table_name AND c.id_table = pt.id_table;
	RETURN NEW;
 END;
 $function$
;

CREATE TRIGGER update_profiling_date_trigger AFTER INSERT
OR UPDATE ON
dq_sbx.info FOR EACH STATEMENT EXECUTE FUNCTION dq_sbx.update_profiling_date();
