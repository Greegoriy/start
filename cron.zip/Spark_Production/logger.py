import logging
from datetime import datetime


class Logger:
    """Класс для создания кастомного логирования"""
    
    @staticmethod
    def create_file_logger(logger_name: str, file_name: str) -> logging.Logger: 
        """Функция для создания логгирования в файл"""
    
        logger = logging.getLogger(logger_name)
        logger.setLevel(logging.INFO)
        formatter = logging.Formatter(fmt='%(asctime)s - %(levelname)s - %(message)s', datefmt='%d-%m-%y %H:%M:%S')
        handler = logging.FileHandler(file_name)
        handler.setFormatter(formatter)
        logger.addHandler(handler)
        return logger
    
    
    @classmethod
    def get_profiling_logger(cls) -> logging.Logger:
        """Функция для создания логера для профилирования"""
        
        logger_name = 'profiling_logger'
        log_path = f'./profiling_{datetime.today().date()}.log'
        logger = cls.create_file_logger(logger_name, log_path)       
        return logger
    
    
    @classmethod
    def get_detection_logger(cls) -> logging.Logger:
        """Функция для создания логера для профилирования"""
        
        logger_name = 'detection_logger'
        log_path = f'./unavailable_tables_{datetime.today().date()}.log'
        logger = cls.create_file_logger(logger_name, log_path)       
        return logger
    
    
    
    
    
    
    
    
    
