import psycopg2
from psycopg2.extensions import connection
import pandas as pd
import json


# импорт собственных модулей
from logger import Logger


import psycopg2
from psycopg2.extensions import connection
import pandas as pd
import json


class MetaSingleton(type):
    """Мета-класс одиночка"""
   
    _instances = {}
    
    def __call__(cls, *args, **kwargs):
        if cls not in cls._instances:
            cls._instances[cls] = super(MetaSingleton, cls).__call__(*args, **kwargs)
        return cls._instances[cls]
    
    
class PostgresConnection(metaclass=MetaSingleton):
    """Класс для работы с БД Postgres"""
    
    db_connection = None
    
    def __init__(self) -> None:
        if self.db_connection is None:
            self.db_connection = self._get_db_connection()
            self.cursor = self.db_connection.cursor()
            self.logger = Logger.get_detection_logger()
    
    
    @staticmethod    
    def _get_db_connection() -> connection:
        """Функция для получения соединения с БД"""
        
        with open("user_pass.json", "r") as read_file:
            user_pass = json.load(read_file)
        
        user=user_pass['user_dq_prof']
        password=user_pass['pass_dq_prof']
        dbname ='dq_profiling'
        host='193.48.6.35'
        port=5432
        db_connection = psycopg2.connect(dbname=dbname, user=user, password=password, host=host, port=port)
        return db_connection
    
    
    def get_data(self, query: str) -> pd.DataFrame:
        """Функция для получения данных в виде датафрейма"""
        
        self.cursor.execute(query)
        columns = [column[0] for column in self.cursor.description]
        records = self.cursor.fetchall()
        return pd.DataFrame(data=records, columns=columns)

        
    def execute_sql(self, query) -> None:
        """Функция для выполнения SQL-запроса"""
        
        try:
            self.cursor.execute(query)
            self.db_connection.commit()
        except Exception as e:
            self.db_connection.rollback()
            raise e
       
    
    def close_db_connection(self) -> None:
        """Функция для закрытия соединения с БД"""
        
        self.db_connection.close()
        self.cursor.close()
        self.db_connection = None
        MetaSingleton._instances = {}