-- dq_sbx.profiling_relevance_rating_v source

CREATE OR REPLACE VIEW dq_sbx.profiling_relevance_rating_v
AS WITH delta_tables AS (
         SELECT i.schema_name,
            i.table_name,
            i.id_table,
            i.last_dt_from AS last_load_dt_hist,
            pt.sampling_date AS last_load_dt_dq,
            COALESCE(
                CASE
                    WHEN pt.sampling_date > i.last_dt_from THEN 0
                    WHEN pt.sampling_date IS NULL AND i.last_dt_from IS NOT NULL THEN 2000000
                    ELSE i.last_dt_from::date - pt.sampling_date
                END, 1000000) AS update_delta
           FROM dq_sbx.info i
             LEFT JOIN dq_sbx.profiling_table pt ON i.schema_name::text = pt.schema_name::text AND i.table_name::text = pt.table_name::text
          WHERE 1 = 1 AND NOT (i.last_dt_from IS NULL AND pt.sampling_date IS NOT NULL) AND i.is_in_archive::text = 'false'::text AND (i.schema_name::text <> ALL (ARRAY['hist_dq_profiling_etl'::character varying::text, 'dq_sbx'::character varying::text]))
        ), unavailable_tables AS (
         SELECT unavailable_tables.schema_name,
            unavailable_tables.table_name,
            unavailable_tables.reason
           FROM dq_sbx.unavailable_tables
          WHERE unavailable_tables.reason::text = ANY (ARRAY['Table is empty'::character varying::text, 'Table is not found'::character varying::text, 'Path does not exist'::character varying::text])
        )
 SELECT dt.schema_name,
    dt.table_name,
    dt.id_table,
    dt.last_load_dt_hist,
    dt.last_load_dt_dq,
    dt.update_delta
   FROM delta_tables dt
     LEFT JOIN unavailable_tables ut ON dt.schema_name::text = ut.schema_name::text AND dt.table_name::text = ut.table_name::text
  WHERE 1 = 1 AND dt.update_delta > 0 AND ut.reason IS NULL
  ORDER BY dt.update_delta DESC;