from datetime import datetime


# импорт собственных модулей
from spark_profiling_exceptions import StoppedSparkContextError
from postgres_connection import PostgresConnection


class SparkExceptionsHandler:
    """Класс для идентификации типов ошибок в Apache Spark"""
    
    def __init__(self, db: PostgresConnection, schema_name: str, table_name: str, id_table: str):
        self.db = db
        self.schema_name = schema_name
        self.table_name = table_name
        self.id_table = id_table
        
    
    def _tag_unvailable_table(self, reason: str) -> None:
        """Функция для загрузки причины ошибки доступа к таблице в БД"""
        
        sampling_date = datetime.now().strftime('%Y-%m-%d')
        query = f"""DELETE FROM dq_sbx.unavailable_tables
                    WHERE 1=1
                    AND schema_name = '{self.schema_name}' 
                    AND table_name = '{self.table_name}'
                    AND id_table= '{self.id_table}';
                    INSERT INTO dq_sbx.unavailable_tables VALUES {self.schema_name,
                                                                  self.table_name, 
                                                                  self.id_table, 
                                                                  reason, 
                                                                  sampling_date}"""
        self.db.execute_sql(query)
  

    def get_error_type(self, error) -> str:
        """Функция для идентификации ошибки"""
        
        error = str(error)
       
        if 'Table or view not found' in error:
            error_message = 'Table is not found'
            self._tag_unvailable_table(error_message)
            
        elif 'Client cannot authenticate via:[TOKEN, KERBEROS]' in error:
            error_message = 'Access to the table is denied'
            self._tag_unvailable_table(error_message)
            
        elif 'Path does not exist' in error:
            error_message = 'Path does not exist'
            self._tag_unvailable_table(error_message)
            
        elif 'Table is empty' in error:
            error_message = error
            self._tag_unvailable_table(error_message)
            
        elif 'SparkContext was shut down' in error or 'stopped SparkContext' in error:
            error_message = 'SparkContext is stopped'
            
        else:
            error_message = f'FAILED DUE TO EXCEPTION: {error}'
            
        return error_message