from pyspark.sql import SparkSession
from datetime import datetime
import time


# импорт собственных модулей
from logger import Logger
from postgres_connection import PostgresConnection
from spark_profiling_exceptions import  StoppedSparkContextError
from spark_exceptions_handler import SparkExceptionsHandler
from spark_profiling import SparkProfiling


class DataProfileLogging:
    """Класс для логирования процесса профилирования"""
    
    def __init__(self, spark: SparkSession, db: PostgresConnection, logger: Logger, schema_name: str, table_name: str, id_table: int) -> None:
        
        self.schema_name = schema_name
        self.table_name = table_name
        self.id_table = id_table
        self.spark = spark # спарк-сессия
        self.db = db
        self.start_time = datetime.now().replace(microsecond=0) # время начало работы профилирования
        self.sampling_date = datetime.now().strftime('%Y-%m-%d') # дата профилирования
        self.logger = logger # логгер 
 
    
    def _log_to_db(self, error_message: str = None, rows_processed: int = 0, columns_processed: int = 0) -> None:
        """Функция для загрузки лог-сообщения в БД"""
        
        end_time = datetime.now().replace(microsecond=0) # время окончания профилирования
        lead_time = time.strftime('%H:%M:%S', time.gmtime((end_time - self.start_time).total_seconds())) # время выполнения профилирования
        app_id = self.spark.sparkContext.applicationId # id спарк-приложения
        
        if error_message:
            status = 'FAILED'
        else:
            status = 'FINISHED'
         
        params = (self.schema_name,
                  self.table_name, 
                  self.id_table,
                  status,
                  str(self.start_time), 
                  str(end_time),
                  lead_time,
                  self.sampling_date,
                  rows_processed,
                  columns_processed,
                  error_message,
                  app_id)
        
        query = f'INSERT INTO dq_sbx.profiling_log VALUES {params}'.replace('None', 'NULL')
        self.db.execute_sql(query)
        
        
        
    def log_to_file(self, error_message: str) -> None:
        """Функция для загрузки лог-сообщения в файл"""
        
        log_message =  f'{self.schema_name}.{self.table_name} - {error_message}'
        self.logger.error(log_message)
        
    
    def _catch_error(self, error) -> None:
        """Функция для идентификации ошибки во время профилирования"""
        
        try:
            error_message = SparkExceptionsHandler(self.db, self.schema_name, self.table_name, self.id_table).get_error_type(error) # вызываем функции из класс для определения типа ошибки  
            self._log_to_db(error_message=error_message) # записываем ошибку в лог в БД    
        except Exception as e:
            error_message = f'LoadingError: {e}' # на случай, если произошла ошибка во время записи в БД
  
        # в случае если спарк отключили извне, выкидываем исключение
        if 'SparkContext is stopped' in error_message:
            raise StoppedSparkContextError
        
        # если произошла ошибка без определенного типа, записываем ее также в файл для дальнейшего анализа
        if 'FAILED DUE TO EXCEPTION' in error_message or 'LoadingError' in error_message:
            self.log_to_file(error_message)
        

    def execute_data_profiling(self) -> None:
        """Функция для запуска профилирования вместе с логированием"""
        
        try:
            data_profile = SparkProfiling(self.spark, self.db, self.schema_name, self.table_name, self.id_table) # экземпляр класса профилирования
            data_profile.get_data_profile() # вызываем функцию для запуска процесса профилирования
            rows_count = data_profile.sample_total_count # кол-во строк в выборке
            columns_count = data_profile.number_of_columns # кол-во столцбов в выборке
            self._log_to_db(rows_processed=rows_count, columns_processed=columns_count) # записываем лог в БД
        except Exception as error:
            self._catch_error(error)