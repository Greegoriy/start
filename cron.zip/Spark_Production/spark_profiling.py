import os 
import sys
import subprocess
import pyspark.sql.functions as f
from pyspark.sql import SparkSession, DataFrame
from pyspark import StorageLevel
from pyspark.sql.window import Window
from pyspark.sql.column import Column
from pyspark.sql.types import Row
import pandas as pd
import numpy as np
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
import re
import logging
from typing import Callable, List, Dict


# импорт собственных модулей
from logger import Logger
from postgres_connection import PostgresConnection


class SparkProfiling:
    """Класс для реализации логики профилирования"""
    
    STORAGE_LEVEL = StorageLevel(False, True, False, True, 1) # уровень сохранения в кэш данных. В данном случае все сохраняется в оперативную память
    NUM_CORES = 60 # количество используемых ядер для спарк приложения
    SAMPLE_COUNT_ROWS = 5000000 # количество строк для выборки
    
    
    def __init__(self, spark: SparkSession, db: PostgresConnection, schema_name: str, table_name: str, id_table: str) -> None:
        """Инициализатор для класса, хранящий основные параметры"""
        
        self.schema_name = schema_name # схема
        self.table_name = table_name # таблица
        self.id_table = id_table # номер таблиц
        self.spark = spark # передаваемая спарк-сессия
        self.db = db
        self.__source_table = self.__source_table() # таблица-источник
        self.source_total_count = self.__get_source_total_count() # количество строк в таблице из Hive до взятия выборки
        self.__blacklist_table = self.__get_blacklist_table() # таблица с исключениями таблица, содержащих нестандартные значения (XML, HTML и т.д)
        self.__blacklist_columns = self.__blacklist_table.column_name.tolist() # сами столбцы исключения
        self.hive_df_sample = self.__get_sample_from_hive() # основная целевая таблица после выборки
        self.sample_total_count = self.hive_df_sample.count() # количество строк после выборки
        self.data_types_df = self.get_data_types() # типы данных столбцов в целевой таблице
        self.number_of_columns = len(self.hive_df_sample.columns) # количество столбца целевой таблицы
 

    def __get_source_total_count(self) -> int:  
        """Функция для определения количества строк в таблице Hive"""
        
        source_total_count = self.__source_table.count()
        if source_total_count == 0:
            raise EmptyTableError
        return source_total_count
    

    def __get_blacklist_table(self) -> pd.DataFrame:
        """Функция для получения таблиц, содержащих нестандартные значения"""
        
        query = """
        SELECT 
            schema_name,
            table_name,
            column_name
        FROM dq_sbx.blacklist_columns_by_memory_size
        """
        blacklist_table = (self.db.get_data(query)
            .query(f'(schema_name=="{self.schema_name}") & (table_name=="{self.table_name}")'))
        return blacklist_table
    
    
    def __source_table(self) -> DataFrame:
        """Функция для получения датафрейма из таблицы Hive"""
        
        source_table = self.spark.table(f'{self.schema_name}.{self.table_name}')
        lower_column_names = [f.col(x).alias(x.lower()) for x in source_table.columns] # понижаем регистр названий всех колонок для унификации
        source_table = source_table.select(lower_column_names)
        return source_table
    
    
    def __get_checked_df(self) -> DataFrame:
        """Функция для получения датафрейма без колонок с нестандартными значениями"""
        
        source_table = self.__source_table
        if self.__blacklist_columns:
            checked_columns = list(filter(lambda col: col not in self.__blacklist_columns, source_table.columns))
            checked_df = source_table.select(*checked_columns)
        else:
            checked_df = source_table
        return checked_df
    
    
    def __get_sample_from_hive(self) -> pd.DataFrame:
        """Функция для определения размера датафрейма из источника"""
        
        checked_df = self.__get_checked_df()
        
        # определяем размер, если больше 5млн, берем выборку
        if self.source_total_count > self.SAMPLE_COUNT_ROWS:
            p_fraction = self.SAMPLE_COUNT_ROWS / self.source_total_count # определение коэффициента фракции
            df_sample = (checked_df
                .sample(fraction=p_fraction) 
                .repartition(self.NUM_CORES) # перераспределяем на кол-во экзекуторов, чтобы данные были равномерно распределены
                .persist(self.STORAGE_LEVEL)) # кэшируем датафрейм
        else:
            df_sample = (checked_df
                .repartition(self.NUM_CORES)
                .persist(self.STORAGE_LEVEL))
        return df_sample

        
    
    def get_data_types(self) -> pd.DataFrame:
        """Функция для получения типов данных таблицы"""
                         
        data_types_df = pd.DataFrame(self.__source_table.dtypes, columns=['column_name', 'type_c'])
        self.__tag_unsupported_type(data_types_df, self.__blacklist_columns)
        data_types_df['data_category_type'] = data_types_df.type_c.apply(self.__validate_datatype)
        return data_types_df
    
    
    
    @staticmethod
    def __validate_datatype(datatype: str) -> str:
        """Функция для определения категории типа данных каждого столбца"""              
                         
        NUMERIC_TYPES  = ['tinyint', 'smallint', 'integer','int', 'bigint', 'decimal', 'float', 'double', 'numeric', 'double precision']
        STRING_TYPES   = ['string', 'varchar', 'char']
        DATETIME_TYPES = ['date', 'timestamp', 'interval']

        clear_datatype = ''.join(re.findall('^[a-z]*', datatype.lower()))

        if clear_datatype in NUMERIC_TYPES:
            return 'numeric_type'
        elif clear_datatype in STRING_TYPES:
            return 'string_type'    
        elif clear_datatype in DATETIME_TYPES:
            return 'datetime_type'   
        elif clear_datatype == 'boolean':
            return 'boolean_type'   
        else:
            return 'unsupported_type'
     
    
    
    def __collect_agg_metrics(self, func_struct: Callable[[str], Column], func_columns: List[str], pd_columns: List[str]) -> pd.DataFrame:
        """Функция для получения датафрейма из расчетных метрик"""
                         
        descExpr = f.array(list(map(func_struct, func_columns))).alias('data') # создаем список всех функций для каждого столбца таблицы

        collectedData = (self.hive_df_sample
            .select(descExpr) # выбираем  все расчетные функции. На данном этапе получится одна строка с большим количество столбцов из метрик для каждой колонки 
            .select(f.explode('data').alias('data')) # транспонируем данные в столбец
            .select('data.*') # разделяем столбец на столбцы и получаем для каждой колонки только свои метрики
            .collect()) # cобираем

        result_df = pd.DataFrame(collectedData, columns=pd_columns)
        return result_df
    
    
    
    def __collect_agg_array_metrics(self, col: str) -> List[Row]:
        """Функция для расчета count, countDistinct, массивов top15, max15, min15"""
         
        # получение количество каждого значения в столбце                 
        agg_count_by_column = (self.hive_df_sample
            .filter(f.col(col).isNotNull())   
            .repartition(self.NUM_CORES // 2, col) # уменьшаем количество партиций перед группировкой, по дефолту датафрейм будет разделен на 200 после группировки, но это много, т.к. данные небольшие, распределим на кол-во ядер 30. После этого шага в группировке перетасовки не будет   
            .groupBy(col)
            .agg(f.count(col).alias('_count_values')) # вычисляем количество значений для столбца
            .withColumn('column_name', f.lit(col)) # столбец с названием колонки
            .withColumnRenamed(col, '_value')
            .persist(self.STORAGE_LEVEL))

        # получение общих значений                      
        agg_count_by_df =  (agg_count_by_column
            .select(f.lit(col).alias('column_name'),
                    f.sum('_count_values').alias('number_of_values'), # количество строк без учета пустых в столбце
                    f.count('_value').alias('number_of_distinct_values'), # количество уникальных в столбце
                    f.sum(f.when(f.col('_count_values')==1, 1).otherwise(0)).alias('count_unique')) # количество уникальных, где количество равно 1
            .withColumn('p_unique', (f.col('count_unique') / f.col('number_of_values') * 100))
            .drop('count_unique')
            .persist(self.STORAGE_LEVEL))
        
        
        # топ 15 по количеству значений в столбце                    
        p_top = (agg_count_by_column
            .sort(f.col('_count_values').desc())
            .limit(15)
            .join(agg_count_by_df, on='column_name', how='inner') # приджойним общие значений
            .withColumn('p_count', f.col('_count_values') / f.col('number_of_values') * 100)
            .groupBy('column_name','number_of_values', 'number_of_distinct_values', 'p_unique') 
            .agg(f.array(f.collect_list(f.col('_value').cast('string')), 
                         f.collect_list('p_count')).alias('p_top')))   # вычисляем массивы  
        
        # топ 15 самых больших значений
        maximum_15 = (agg_count_by_column
            .sort(f.col('_value').desc())
            .limit(15)
            .join(agg_count_by_df, on='column_name', how='inner')
            .withColumn('p_count', f.col('_count_values') / f.col('number_of_values') * 100)
            .groupBy('column_name','number_of_values', 'number_of_distinct_values', 'p_unique')
            .agg(f.array(f.collect_list(f.col('_value').cast('string')), 
                         f.collect_list('p_count')).alias('maximum_15')))  
        
        # топ 15 самых минимальных значений
        minimum_15  = (agg_count_by_column
            .sort(f.col('_value').asc())
            .limit(15)
            .join(agg_count_by_df, on='column_name', how='inner')
            .withColumn('p_count', f.col('_count_values') / f.col('number_of_values') * 100)
            .groupBy('column_name','number_of_values', 'number_of_distinct_values', 'p_unique')
            .agg(f.array(f.collect_list(f.col('_value').cast('string')), 
                         f.collect_list('p_count')).alias('minimum_15')))   
        
        # соберем все метрики в один датафрейм         
        collected_data = (p_top             
            .union(maximum_15) # union, т.к. не вызывает перетасовки данных, а джойн вызывает
            .union(minimum_15)
            .groupBy('column_name','number_of_values','number_of_distinct_values', 'p_unique')
            .agg(f.collect_list('p_top').alias('data')) # получаем один столбец из p_top, max_15, min_15
            .select(f.col('column_name'),
                    f.col('number_of_values'),
                    f.col('number_of_distinct_values'),
                    f.col('p_unique'),
                    f.col('data').getItem(0), # p_top 
                    f.col('data').getItem(1), # max_15
                    f.col('data').getItem(2)) # min_15
            .collect())

        agg_count_by_column.unpersist() # очищаем кэш
        agg_count_by_df.unpersist() # очищаем кэш
        
        return collected_data
    
    
    @staticmethod                              
    def __tag_unsupported_type(df: pd.DataFrame, except_columns: List[str]) -> None:
        """Функция для обновления категории типа данных на неподдерживаемый формат"""
                          
        df.loc[(df.column_name.isin(except_columns)), 'type_c'] = 'unsupported_type'
    
    
     
    @staticmethod
    def __get_mode(column: pd.Series) -> str:
        """Функция для расчета наиболее встречающегося значения"""
                          
        if column:
            return list(column.keys())[0]
        
        
    @staticmethod
    def __get_dict_from_arrays(column: pd.Series) -> Dict[str, float]:
        """Функция для создания словаря из массивов. Применяется в метриках p_top, max_15, min_15"""
                          
        if column == column:
            return dict(zip(column[0], pd.to_numeric(column[1])))
        
        
    
    @staticmethod
    def __get_warnings(df_sample: pd.DataFrame) -> str:
        """Функция для определения варнингов(предупреждений)"""                
                          
        warnings = []
            
        if df_sample.number_of_distinct_values == 1:
            warnings.append('constant')

        if df_sample.p_missing != 100 and df_sample.number_of_distinct_values == df_sample.number_of_values:
            warnings.append('unique')

        if df_sample.p_missing == 100:
            warnings.append('all_null')
        elif df_sample.p_missing > 0.01:
            warnings.append('contains_null')
        
        if df_sample.p_zeros != 'NULL':
            if df_sample.p_zeros > 0.01:
                warnings.append('contains_zeros')

        return ', '.join(warnings)
    
    
    
    @staticmethod
    def __count_by_datacategory(data_categories_df: pd.DataFrame, datacategory: str) -> int:
        """Функция для получения количества по типу категории"""
                          
        try:
            return data_categories_df.loc[datacategory][0]
        except KeyError:
            return 0

        
    @staticmethod
    def __check_zero(df_column: pd.Series) -> pd.Series:
        """Функция для расчета процента от деления и проверка деления на 0"""             
                          
        return df_column.apply(lambda x: 1 if x==0  else x) 
    
    
    @staticmethod
    def __clear_line(line: pd.Series) -> pd.Series :  
        """Функция для очистки строки запроса SQL"""
                          
        if isinstance(line, (int, float, complex)):
            return line
        return str(line).replace("'", '"')
        
         
    def __get_query_from_df(self, target_table: str, sample_df: pd.DataFrame, target_schema: str ='dq_sbx') -> str:
        """Функция преобразования датафрейма в SQL запрос для записи в таблицу БД"""                
                          
        values = []
        df = sample_df.fillna('NULL')

        for row in df.itertuples(index=False):
            values.append(str(tuple(map(self.__clear_line, row))).replace("'NULL'", "NULL"))

        query = f"""DELETE FROM {target_schema}.{target_table} 
                    WHERE 1=1
                    AND schema_name = '{self.schema_name}'
                    AND table_name = '{self.table_name}'
                    AND id_table = '{self.id_table}';
                    INSERT INTO {target_schema}.{target_table} VALUES""" 
        final_query = query +  ', '.join(values)
        final_query = re.sub(r'\t|\\t|\n|\\n', ' ', final_query)
        return final_query
    
    
    def get_max_min_df(self) -> pd.DataFrame:
        """Функция для вычисления максимума и минимимума всех столбцов"""
                      
        max_min_struct = lambda col: f.struct(f.lit(col),
                                              f.max(col).cast('string'),
                                              f.min(col).cast('string')) # функции для вычисления данных метрик для каждой колонки
        
        pd_cols = ['column_name', 'max_c', 'min_c']
        max_min_df = self.__collect_agg_metrics(max_min_struct, self.hive_df_sample.columns, pd_cols)
        return max_min_df
    
    
    def __get_columns_by_data_type(self, max_min_df: pd.DataFrame) -> Dict[str, List[str]]:
        """Функция для определения типов данных каждой колонки"""
                          
        # Пустые и константные столбцы
        nan_cols = max_min_df[(max_min_df.max_c.isnull()) & (max_min_df.min_c.isnull())].column_name.tolist()   
        constant_cols = max_min_df.query('(column_name not in @nan_cols) & (max_c==min_c)').column_name.tolist() 
        exception_cols = constant_cols + nan_cols 

        # Числовые столбцы
        numeric_cols  = self.data_types_df \
            .query('(data_category_type=="numeric_type") & (column_name not in @constant_cols) & (column_name not in @nan_cols)') \
            .column_name \
            .to_list()

        # Столбцы таблицы за исключением константных и пустых столбцов
        basic_cols = list(set(self.hive_df_sample.columns) - set(exception_cols)) 
        columns_by_data_type = {'empty': nan_cols,
                                'constant': constant_cols,
                                'exception': exception_cols,
                                'numeric': numeric_cols,
                                'basic': basic_cols}  
        return columns_by_data_type
    
    
    def __get_constant_df(self, constant_cols: List[str]) -> pd.DataFrame:
        """Функция для расчета количества строк и уникальных значений для константных столбцов"""
                          
        count_struct = lambda col: f.struct(f.lit(col), f.count(col)) # функции для вычисления данных метрик для каждой колонки
        pd_cols = ['column_name', 'number_of_values']
        constant_df = self.__collect_agg_metrics(count_struct, constant_cols, pd_cols)
        constant_df['number_of_distinct_values'] = np.where(constant_df.column_name.isin(constant_cols), 1, 0) # не вычисляем отдельно кол-во уникальных, т.к. всегда будет один,  distinct
        return constant_df

    
    @staticmethod
    def __get_nan_df(nan_cols: List[str]) -> pd.DataFrame:
        """Функция для расчета количества строк и уникальных значений для столбцов с NULL значениями"""
        
        nan_df = pd.DataFrame({'column_name': nan_cols, 
                               'number_of_values': np.zeros(len(nan_cols)),
                               'number_of_distinct_values': np.zeros(len(nan_cols))})  
        return nan_df
    
    
    def __get_exception_df(self, columns_by_data_type: Dict[str, List[str]]) -> pd.DataFrame:
        """Функция для создания датафрейма из столбцов исключений (nan и constant)"""
                          
        nan_cols = columns_by_data_type['empty']
        constant_cols = columns_by_data_type['constant']
        
        if nan_cols and constant_cols:
            nan_df = self.__get_nan_df(nan_cols)
            constant_df = self.__get_constant_df(constant_cols)
            exception_df = pd.concat([constant_df, nan_df])
        elif nan_cols:
            exception_df = self.__get_nan_df(nan_cols)
        elif constant_cols: 
            exception_df = self.__get_constant_df(constant_cols)
        
        return exception_df
    
    
    def __multithreaded_collect(self, columns_by_data_type: Dict[str, List[str]]) -> pd.DataFrame:
        """Функция для мультипочного вызова функции __collect_agg_array_metrics"""
                          
        basic_cols = columns_by_data_type['basic']
        with ThreadPoolExecutor(self.NUM_CORES) as pool:
            collected_array_metrics = list(pool.map(self.__collect_agg_array_metrics, basic_cols))

        # Датафрейм из столбцов, не равных nan и constant
        key_cols = ['column_name', 'number_of_values', 'number_of_distinct_values', 'p_unique', 'top_15_array', 'max_15_array', 'min_15_array']
        collected_array_df  = pd.DataFrame([row[0] for row in collected_array_metrics], columns=key_cols)
        return collected_array_df
    
                       
    def __get_agg_count_metrics_df(self, columns_by_data_type: Dict[str, List[str]]) -> pd.DataFrame:
        """Функция для соединения общих метрик с разными типами данных в один датафрейм"""                  
                          
        # Датафрейм из столбов исключений     
        exception_cols = columns_by_data_type['exception']
        collected_array_df = self.__multithreaded_collect(columns_by_data_type)
        
        if exception_cols:
            # Расчет количества строк в каждом из столбцов исключений
            exception_df = self.__get_exception_df(columns_by_data_type)

            # Датафрейм с базовыми метриками 
            basic_metrics_df = pd.concat([collected_array_df, exception_df])
        else:
            basic_cols = columns_by_data_type['basic']
            basic_metrics_df = collected_array_df    
        return basic_metrics_df
    
    
    @staticmethod
    def __get_byte_cols(profiling_columns: pd.DataFrame) -> List[str]:
        """Функция для получения столбцов, содержащих байты"""                  
                          
        byte_cols = (profiling_columns
            .query('(number_of_distinct_values==2) & (min_c==0) & (max_c==1)')
            .column_name
            .tolist())
        return byte_cols
    
    
    def __collect_numeric_metrics(self, col: str) -> pd.DataFrame:
        """Функция для создания датафрейма из числовых столбцов"""
        
        # вычисляем числовые метрики  
        numeric_metrics = (self.hive_df_sample
            .select(f.lit(col).alias('column_name'),
                    f.stddev(col).alias('std'),
                    f.mean(col).alias('mean_c'),
                    f.variance(col).alias('variance'),
                    f.count(f.when(f.col(col)==0, f.lit(1))).alias('values_zeros'),
                    f.count(f.when(f.col(col)<0, f.lit(1))).alias('values_negative'))) 
        
        # отдельно вычисляем перцентили
        approx_percentiles =(self.hive_df_sample
            .select(f.expr(f'approx_percentile({col}, array(0.05, 0.25, 0.5, 0.75, 0.95))').alias('approx_percentiles'))
            .select(f.lit(col).alias('column_name'), 
                    f.col('approx_percentiles')[0].alias('p_5'),
                    f.col('approx_percentiles')[1].alias('p_25'),
                    f.col('approx_percentiles')[2].alias('p_50'),
                    f.col('approx_percentiles')[3].alias('p_75'),
                    f.col('approx_percentiles')[4].alias('p_95')))
        
        # собираем в один датафрейм
        numeric_df = (numeric_metrics
            .join(approx_percentiles, on='column_name', how='inner')
            .collect())
        return numeric_df
    
                                   
    def __calculate_numeric_metrics(self, basic_metrics_df: pd.DataFrame, columns_by_data_type: Dict[str, List[str]]):
        """Функция для расчета числовых значений """                
                          
        numeric_cols = columns_by_data_type['numeric']
        if numeric_cols:  
            # Столбцы с типом данных - байт
            byte_cols = self.__get_byte_cols(basic_metrics_df)
            
            if byte_cols:
                self.__tag_unsupported_type(basic_metrics_df, byte_cols)
                numeric_cols = set(numeric_cols) - set(byte_cols)

            # Расчет числовых метрик в мультипотоке  
            with ThreadPoolExecutor(self.NUM_CORES) as pool:
                collected_numeric_data = list(pool.map(self.__collect_numeric_metrics, numeric_cols))
                      
            num_key_cols = ['column_name', 'std', 'mean_c', 'variance', 'values_zeros', 
                            'values_negative', 'p_5',  'p_25', 'p_50', 'p_75', 'p_95']   
            numeric_df  = pd.DataFrame([row[0] for row in collected_numeric_data], columns=num_key_cols)
                  
            # Добавление датафрейма из числовых метрик к общему датафрейму
            basic_metrics_df = (basic_metrics_df.merge(numeric_df, on=['column_name'], how='left'))

            # Метрики только для числовых столбцов 
            basic_metrics_df['p_zeros'] = pd.to_numeric(basic_metrics_df.values_zeros) / self.__check_zero(basic_metrics_df.number_of_values) * 100
            basic_metrics_df['p_negative'] = pd.to_numeric(basic_metrics_df.values_negative) / self.__check_zero(basic_metrics_df.number_of_values) * 100
            basic_metrics_df['iqr'] = pd.to_numeric(basic_metrics_df.p_75) - pd.to_numeric(basic_metrics_df.p_25)                             
        else:
            basic_metrics_df[['std', 'mean_c', 'variance',  'p_5', 'p_25','p_50', 'p_75','p_95',
                               'values_zeros', 'values_negative', 'p_zeros', 'p_negative', 'iqr']] = 'NULL'
        
        return basic_metrics_df
    
        
    def get_profiling_columns(self) -> pd.DataFrame:
        """Функция для профилирования столбцов"""         
                          
        # Определение макс и мин для всех столбцов
        max_min_df = self.get_max_min_df()

        # Определение типов данных столбцов, столбцов-констант и пустых столбцов
        columns_by_data_type = self.__get_columns_by_data_type(max_min_df)

        # Агрегированные по количеству значений метрики профилирования
        agg_count_metrics_df = self.__get_agg_count_metrics_df(columns_by_data_type)
    
        # Объединение всех фреймов в один общий, создание датафрейма метрик для столбцов - profiling_columns
        basic_metrics_df = (max_min_df
            .merge(agg_count_metrics_df, on=['column_name'], how='left') 
            .merge(self.data_types_df, on=['column_name'], how='left')
            .drop(columns='data_category_type'))
        
        # Добавляем числовые метрики
        profiling_columns = self.__calculate_numeric_metrics(basic_metrics_df, columns_by_data_type)
            
        # Общие метрики для всех столбцов таблицы profiling_columns
        profiling_columns['p_distinct'] = profiling_columns.number_of_distinct_values / self.__check_zero(profiling_columns.number_of_values) * 100
        profiling_columns['p_missing'] = ((self.sample_total_count - profiling_columns.number_of_values) / self.sample_total_count) * 100
        profiling_columns['p_top'] = profiling_columns.top_15_array.apply(self.__get_dict_from_arrays)
        profiling_columns['maximum_15'] = profiling_columns.max_15_array.apply(self.__get_dict_from_arrays)
        profiling_columns['minimum_15'] = profiling_columns.min_15_array.apply(self.__get_dict_from_arrays)
        profiling_columns['mode'] = profiling_columns.p_top.apply(self.__get_mode)
        profiling_columns['warning'] = profiling_columns.apply(lambda df: self.__get_warnings(df), axis=1)
        profiling_columns['schema_name'] = self.schema_name.lower()
        profiling_columns['table_name'] = self.table_name.lower()
        profiling_columns['column_name'] = profiling_columns.column_name.str.lower()
        profiling_columns['id_table'] = self.id_table
        profiling_columns['histogram_y'] = np.NaN
        profiling_columns['histogram_x'] = np.NaN
        profiling_columns['kurtosis'] = np.NaN
        profiling_columns['skewness'] = np.NaN
        
        # Оставим только необходимые cтолбцы                                       
        profiling_columns = profiling_columns[['schema_name', 'table_name','column_name','p_distinct', 'p_unique','type_c',
                                             'p_missing','p_zeros', 'p_negative', 'mean_c','min_c','max_c','p_5','p_25',
                                             'p_50','p_75','p_95', 'std','variance','iqr','mode','kurtosis','skewness',
                                             'histogram_y', 'histogram_x','maximum_15','minimum_15','p_top','warning',
                                             'id_table','number_of_values','number_of_distinct_values']]
         
        # Если таблица содержит нестандартные значения, то добавляем их к основному датафрейму, но без расчета всех метрик                 
        if not self.__blacklist_table.empty:
            profiling_columns = pd.concat([profiling_columns, self.__blacklist_table])
            self.__tag_unsupported_type(profiling_columns, self.__blacklist_columns)
                                   
                                   
        # Полностью удаляем кэш для данного экземпляра
        self.hive_df_sample.unpersist()
        self.spark.catalog.clearCache()
        return profiling_columns
    
    
    def __get_data_categories_df(self):
        """Функция расчета количества столбцев в каждой дата-категории"""
                          
        data_categories_df = (self.data_types_df
            .groupby('data_category_type', as_index=False)
            .agg({'type_c':'count'})
            .rename(columns={'type_c':'count'})
            .set_index('data_category_type')) 
        return data_categories_df
    
    
    def __get_profiling_table(self, sample_df: pd.DataFrame) -> pd.DataFrame:
        """Функция для профлирования общих метрик самой таблицы"""                
                          
        # Создание датафрейма метрик для таблицы из таблицы profiling_columns
        profiling_table = sample_df[:]

        # Общая сумма по таблице, состоящая из уникальных значений и количества строк без nan по каждому столбцу
        profiling_table = (profiling_table
            .groupby(['schema_name', 'table_name', 'id_table']) 
            .agg({'number_of_distinct_values':'sum',
                  'number_of_values':'sum'}) 
            .reset_index())

        # Общая сумма таблицы по общему количеству строк
        sample_total_count_sum = self.sample_total_count * self.number_of_columns

        # Количество категорий по типу данных
        data_categories_df = self.__get_data_categories_df()

        # Основные метрики profiling_table
        profiling_table['duplicates_percent'] = (profiling_table.number_of_values - profiling_table.number_of_distinct_values) / self.__check_zero(profiling_table.number_of_values) * 100
        profiling_table['missing_cells_percent'] = (sample_total_count_sum - profiling_table.number_of_values) / sample_total_count_sum * 100
        profiling_table['full_size'] = self.source_total_count
        profiling_table['number_of_observations'] = self.sample_total_count
        profiling_table['sample_size_percent'] = self.sample_total_count / self.source_total_count * 100
        profiling_table['number_of_variables'] = self.number_of_columns
        profiling_table['numeric_types'] = self.__count_by_datacategory(data_categories_df, 'numeric_type')
        profiling_table['string_types'] =  self.__count_by_datacategory(data_categories_df, 'string_type')
        profiling_table['datetime_types'] =  self.__count_by_datacategory(data_categories_df, 'datetime_type')
        profiling_table['boolean_types'] =  self.__count_by_datacategory(data_categories_df, 'boolean_type')
        profiling_table['unsupported_types'] =  self.__count_by_datacategory(data_categories_df, 'unsupported_type')
        profiling_table['heatmap'] = np.NaN
        profiling_table['heatmap_columns'] = np.NaN
        profiling_table['sampling_date'] = datetime.now().strftime('%Y-%m-%d')

                                   
        # Оставим только необходимые cтолбцы               
        profiling_table = profiling_table[
            ['schema_name', 'table_name', 'sampling_date', 'full_size', 'number_of_observations',
             'sample_size_percent', 'duplicates_percent', 'number_of_variables', 'missing_cells_percent',
             'unsupported_types', 'numeric_types', 'string_types', 'datetime_types', 'boolean_types',
             'heatmap', 'heatmap_columns', 'id_table']]

        return profiling_table
    

    def get_data_profile(self) -> None:
        """Главная функция, вызывающую всю логику профилирования для таблицы"""
                          
        # Получение профилирования по столбцам таблицы иобщего профилирования по таблице
        profiling_columns = self.get_profiling_columns()                                  
        profiling_table = self.__get_profiling_table(profiling_columns)

        # Преобразование датафреймов в SQL запрос для последующей записи                                    
        query_profiling_cols = self.__get_query_from_df('profiling_columns', profiling_columns)
        query_profiling_table = self.__get_query_from_df('profiling_table', profiling_table)  

        # Запись в БД отпрофилированных таблиц profiling_columns и profiling_table
        self.db.execute_sql(query_profiling_cols)
        self.db.execute_sql(query_profiling_table)