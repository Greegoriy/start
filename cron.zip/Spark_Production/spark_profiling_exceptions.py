class EmptyTableError(Exception):
    """Класс-исключение для вызова при пустой таблице"""

    def __init__(self) -> None:
        self.message = 'Table is empty'
        super().__init__(self.message)
        
    
class StoppedSparkContextError(Exception):
    """Класс-исключение для вызова при отключении спарка"""

    def __init__(self) -> None:
        self.message = 'SparkContext is stopped'
        super().__init__(self.message)   
        
        
class TimeOverError(Exception):
    """Класс-исключение для вызова при истечении работы профилирования"""

    def __init__(self) -> None:
        self.message = 'Profiling time is over'
        super().__init__(self.message)        
      
           
class DiskMemoryUsageError(Exception):  
    """Класс-исключение для вызова при использовании спарком дисковой памяти"""

    def __init__(self) -> None:
        self.message = 'The size of the dataframe exceeds the RAM. Disk memory is used'
        super().__init__(self.message)
        
        
