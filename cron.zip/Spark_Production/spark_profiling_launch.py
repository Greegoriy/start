import os 
import sys
import subprocess
from pyspark.sql import SparkSession
import pandas as pd
from datetime import datetime


# импорт собственных модулей
from postgres_connection import PostgresConnection
from spark_profiling_exceptions import StoppedSparkContextError, TimeOverError
from spark_logging import DataProfileLogging
from logger import Logger



# настройка окружения
username = "rbsdq_odpp@ROSBANK.RUS.SOCGEN"
p = subprocess.Popen(f"/usr/bin/id {username} -u", shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
id_str1 = p.stdout.readline().decode("utf-8").replace("\n", "")
p = subprocess.Popen(f"id  -u", shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
id_str2 = p.stdout.readline().decode("utf-8").replace("\n", "")
os.environ ["JAVA_TOOL_OPTIONS"] = "-Djava.security.krb5.conf=/etc/krb5.conf.d/krb5.conf"
os.environ ["KRB5_CONFIG"] = "/etc/krb5.conf.d/krb5.conf"
os.environ ["KRB5CCNAME"] = f"/tmp/krb5cc_{id_str1}_{id_str2}"
spark_home = "/usr/hdp/current/spark2-client/"
os.environ ['SPARK_HOME'] = spark_home
sys.path.insert(0, os.path.join(spark_home, 'python'))
os.environ['PYSPARK_PYTHON'] = './environment/bin/python3.7'
os.environ ['HADOOP_CONF_DIR'] = '/usr/hdp/current/hadoop-client/conf/'
os.environ ['PYTHONPATH'] = '/usr/hdp/current/spark2-client/python/lib/py4j-0.10.7-src.zip:/usr/hdp/current/spark2-client/python/'
os.environ ['PYTHONSTARTUP'] = '/usr/hdp/current/spark2-client/python/pyspark/shell.py'

    
class RunDataProfile:
    """Класс для запуска профилирования"""
    
    _LIMIT_TIME_IN_HOURS = 21 # время отключения профилирования
    _LIMIT_APP_DURATION_IN_MINUTES = 150 # длительность в минутах после которого спарк-сессия сделает рестарт
    
    
    def __init__(self) -> None:
        self.spark = self.get_spark_session() # спарк-сессия
        self.app_start_time = datetime.now() # время начала спарк-приложения
        self.logger = Logger.get_profiling_logger() # логгер
        self.db = PostgresConnection() # подключение к БД Postgres
        
        
    @staticmethod
    def get_spark_session() -> SparkSession:
        """Функция для создания спарк-сессии"""
        
        spark = (SparkSession
            .builder
            .enableHiveSupport()
            .appName('profiling_data')
            .getOrCreate())
        return spark
    
    
    def _get_source_tables(self) -> pd.DataFrame:
        """Функция для получения таблиц, которые необходимо отпрофилировать"""
        
        query = """
        SELECT 
            schema_name,
            table_name,
            id_table
        FROM dq_sbx.profiling_relevance_rating_v
        """ 
        source_tables = self.db.get_data(query)
        return source_tables
    
        
        
    def _stop_spark_job(self) -> None:
        """Функция для остановки спарк-приложения"""
       
        self.spark.stop()
        self.app_start_time = datetime.now()
        self.spark = self.get_spark_session()
    
    
    def _run_spark_job(self, schema_name: str, table_name: str, id_table: str) -> None:
        """Функция для запуска спарк-приложения"""
        
        current_time = datetime.now()
        app_duration_in_minutes = (current_time - self.app_start_time).total_seconds() / 60
        
        # если текущий час больше 21 по МСК, то приложение выключается. Если время работы приложения больше 150 минут, то происходит рестарт спарк-сессии (это необходимо для сброса кэша и мусора, так спарк приложение работает эффективнее и быстрее).
        if current_time.hour >= self._LIMIT_TIME_IN_HOURS:
            raise TimeOverError
        elif app_duration_in_minutes >= self._LIMIT_APP_DURATION_IN_MINUTES:
            self._stop_spark_job()
            
        DataProfileLogging(self.spark, self.db, self.logger, schema_name, table_name, id_table).execute_data_profiling() # вызываем процесс профилирования вместе с логированием
        
    
    def run(self) -> None:
        """Главная функция для запуска спарк-приложения по профилированию"""
        
        source_tables = self._get_source_tables()
          
        # проходимся по всем таблицам. Останавливаеся в том случае, если время больше 21:00 или спарк остановили извне на кластере из-за незватки ресурсов
        for row in source_tables.itertuples(index=False):
            try:  
                self._run_spark_job(row.schema_name, row.table_name, row.id_table)   
            except (TimeOverError, StoppedSparkContextError):
                break
            except Exception as e:
                error_message = f'{row.schema_name}.{row.table_name} - {e}'
                self.logger.error(error_message)
                
        self.spark.stop()
        
        
if __name__ == "__main__":
    RunDataProfile().run()