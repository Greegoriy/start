import psycopg2
from psycopg2.pool import ThreadedConnectionPool
import pandas as pd
import json



"""
Для API сервере путь "/var/www/mflow_api/user_pass.json", для теста на юпитере "./user_pass.json"
Стоит исправить на универсальные пути 
"""

with open("./user_pass.json", "r") as read_file:
    user_pass = json.load(read_file)

pg_pool = ThreadedConnectionPool(minconn=1,
    maxconn=300, # число очередей запросов достаточно 50~100, на всякий случай 300
    user=user_pass['user_dq_prof'],
    password=user_pass['pass_dq_prof'],
    host='193.48.6.35',
    port=5432,
    dbname='dq_profiling')


class PostgresConnection:

    def __init__(self, db_connection: ThreadedConnectionPool):
        self.db_connection = db_connection


    def getData(self, query: str) -> pd.DataFrame:
        """получает sql - возвращает DataFrame """
        db = self.db_connection.getconn()
        cursor = db.cursor()
        try:
            cursor.execute(query)
            columns=[column[0] for column in cursor.description]
            records=cursor.fetchall()
            return pd.DataFrame(data=records, columns=columns)
        except Exception as e:
            print(e)
        finally:
            self.db_connection.putconn(db)
            cursor.close()

    def execute(self, query: str):
        """ выполняет sql - ничего не возвращает """
        db = self.db_connection.getconn()
        cursor = db.cursor()
        try:
            cursor.execute(query)
            db.commit()
        except Exception as e:
            print(e)
        finally:
            self.db_connection.putconn(db)
            cursor.close()