import uvicorn
from fastapi import FastAPI
import json
from typing import Union, List
import re

from db_connectors import PostgresConnection, pg_pool
from schemas import *
from query_search import fields_update, search_query

# Создаёт экземпляр класса FastAPI
app = FastAPI()

# Коннектор
pg = PostgresConnection(pg_pool)


"""
Основной функционал API, импортируем коннекторы, схемы и функции поиска.
Декоратор @app.get() - для GET запросов
Декоратор @app.post() - для POST запросов
"""

@app.get('/')
def home():
    """ Тестовая функция GET для запроса в корень API """
    return '<h1>&#10031 &#10031 &#10031 MetaFlow API &#10031 &#10031 &#10031</h1>'


@app.get('/filters')
def filters():
    """Получаем информацию по всем фильтрам"""
    query_system = """
    SELECT DISTINCT
        it_code,
        name_system,
        status,
        owner_company,
        international_name,
        identifier,
        sg_global_id,
        alternative_name,
        producer,
        domain_owner_it_system,
        it_system_owner,
        responsible_employee_system_owner,
        development_department,
        responsible_for_development,
        application_manager,
        information_security_officer,
        "date",
        development_start_date,
        commissioning_date,
        start_date_shutdown,
        decommissioning_date,
        type_of_use,
        development_type,
        hosting_type,
        access_category,
        sensitivity,
        sensitivity_assessment_date,
        pci_dss_processing,
        green_book_compliance,
        internet_access,
        fraud_sensitive,
        integirty,
        confidentiality,
        availability,
        sensivity_category,
        vital,
        rto_target,
        rpo_target,
        note,
        last_modified_date
    FROM dq_sbx.registry_it_system
    WHERE  it_code in (SELECT distinct it_code FROM dq_sbx.descr_tab)
    ORDER BY name_system
    """
    query_owner = """
    SELECT contact_person
    FROM dq_sbx.descr_col
    WHERE contact_person IS NOT NULL
    GROUP BY contact_person
    ORDER BY contact_person
    """
    query_domain = """
    SELECT domain_data_owner
    FROM dq_sbx.descr_col
    WHERE domain_data_owner IS NOT NULL
    GROUP BY domain_data_owner
    ORDER BY domain_data_owner
    """
    system = pg.getData(query_system).to_dict('list')
    owner = pg.getData(query_owner).to_dict('list')
    domain = pg.getData(query_domain).to_dict('list')
    return system, owner, domain


@app.post('/query')
def search_item(item: User_Query):
    """Реализует поиск в туле mflow функции fields_update и search_query импортируем из query_search"""
    item = fields_update(item)
    query = search_query(item)
    return pg.getData(query).columns.tolist(), pg.getData(query).values.tolist()


@app.post('/table')
def table_item(item: Table_Info):
    """Возвращает инфу по таблицам из результатов поиска"""
    query = f"""
        SELECT
        d.it_code,d.src_name,d.src_schema,d.src_table,d.tab_comment,d.schema_name,
        d.table_name,d.is_in_archive,i.last_state,i.last_dt_from,i.load_mode,d.table_code,
        d.editable, d.team, d.developer_rb, d.developer_fio, d.analyst_rb, d.analyst_fio, d.link_confluence
        FROM dq_sbx.descr_tab as d
        LEFT JOIN dq_sbx.info as i ON d.schema_name = i.schema_name and d.table_name = i.table_name
        WHERE table_code = '{item.table_code}'"""
    return pg.getData(query).columns.tolist(), pg.getData(query).values.tolist()


@app.post('/column')
def column_item(item: Column_Info):
    """Возвращает инфу по столбцам из результатов поиска"""
    if item.odpp is not None:
        query = f"""
        SELECT
            d.table_code, d.col_name, d.col_type, d.col_comment, d.flag_algorithm,
            d.personal_data_group, d.contact_person, d.domain_data_owner,
            d.user_comments, d.entity_name, p.warning
        FROM dq_sbx.descr_col as d
        LEFT JOIN dq_sbx.profiling_columns as p
            ON d.col_name = p.t_column and schema_name = '{item.odpp.schema_name}' and table_name = '{item.odpp.table_name}'
        WHERE d.table_code = '{item.table_code}'
        ORDER BY d.col_position"""
        return pg.getData(query).columns.tolist(), pg.getData(query).values.tolist()
    else:
        query = f"""
        SELECT
            d.table_code, d.col_name, d.col_type, d.col_comment, d.flag_algorithm,
            d.personal_data_group, d.contact_person, d.domain_data_owner,
            d.user_comments, d.entity_name, NULL as warning
        FROM dq_sbx.descr_col as d
        WHERE d.table_code = '{item.table_code}'
        ORDER BY d.col_position"""
        return pg.getData(query).columns.tolist(), pg.getData(query).values.tolist()


@app.post('/profiling')
def profiling_item(item: Profiling_Info):
    """Возвращает инфу по профилированию"""
    if item.col_name:
        query = f"""
        SELECT
            schema_name, table_name, t_column,
            p_distinct, p_unique, type_c, p_missing, p_zeros, p_negative, mean_c, min_c, max_c,
            p_5, p_25, p_50, p_75, p_95, std, variance, iqr, "mode", kurtosis, skewness, histogram_y, histogram_x,
            maximum_15, minimum_15, p_top, warning
        FROM dq_sbx.profiling_columns
        WHERE schema_name = '{item.odpp.schema_name}' AND table_name = '{item.odpp.table_name}' AND t_column = '{item.col_name}'
        """
        return pg.getData(query).columns.tolist(), pg.getData(query).values.tolist()
    else:
        query = f"""
        SELECT
            schema_name, table_name, sampling_date,
            full_size, number_of_observations, sample_size_percent, duplicates_percent, number_of_variables, missing_cells_percent, 
            unsupported_types, numeric_types, string_types, datetime_types, boolean_types, heatmap, heatmap_columns
        FROM dq_sbx.profiling_table
        WHERE schema_name = '{item.odpp.schema_name}' AND table_name = '{item.odpp.table_name}'
        """
        return pg.getData(query).columns.tolist(), pg.getData(query).values.tolist()


def editable_object(item: List_Item):
    """Информация по редактируемым объектам"""
    item.name = re.sub(r"[^a-z_.#0-9 ]",'',item.name.lower())
    query = f"""
    SELECT 
        src_schema||'.'||src_table as object_name, object_type
    FROM dq_sbx.descr_tab
    WHERE editable = 'editable' 
        AND (src_schema||'.'||src_table ilike '{item.name}%' OR src_schema ilike '{item.name}%' OR  src_table ilike '{item.name}%')
    GROUP BY src_schema||'.'||src_table, object_type
    ORDER BY src_schema||'.'||src_table, object_type
    limit {item.limit}
        """
    return pg.getData(query).columns.tolist(), pg.getData(query).values.tolist()


@app.post('/users_rb')
def user_item(item: List_Item):
    """Информация по пользователеям"""
    item.name = re.sub(r"[^а-яёa-z0-9 ]",'',item.name.lower())
    query = f"""
    SELECT fio, rb
    FROM dq_sbx.rb_list
    WHERE fio ilike '%{item.name}%' OR rb ilike '%{item.name}%'
    ORDER BY fio
    LIMIT {item.limit}
        """
    return pg.getData(query).columns.tolist(), pg.getData(query).values.tolist()


@app.post('/update_editable_object')
def update_editable_object(item: Update_GP_Object):
    """Добавляет записи в GP объкты по разработчику, команде и аналитику - Update descr_tab и INSERT gp_object, возвращает True или ошибку"""
    try:
        "Очистка полей от лишних символов (на всякий случай)"
        item.team = re.sub(r"[^a-zA-Z_#0-9 ]",'',item.team)
        item.developer_rb = re.sub(r"[^a-zA-Z0-9_-]",'',item.developer_rb)
        item.developer_fio = re.sub(r"[^а-яёА-ЯЁa-zA-Z ]",'',item.developer_fio)
        item.analyst_rb = re.sub(r"[^a-zA-Z0-9_-]",'',item.analyst_rb)
        item.analyst_fio = re.sub(r"[^а-яёА-ЯЁa-zA-Z ]",'',item.analyst_fio)

        item.src_schema = re.sub(r"[^a-z0-9_-]",'',item.src_schema.lower())
        item.src_table = re.sub(r"[^a-z0-9_-]",'',item.src_table.lower())
        item.object_type = re.sub(r"[^a-z/]",'',item.object_type.lower())
        query = f"""
        UPDATE dq_sbx.descr_tab
        SET (team, developer_rb, developer_fio, analyst_rb, analyst_fio) =
            ('{item.team}', '{item.developer_rb}', '{item.developer_fio}', '{item.analyst_rb}', '{item.analyst_fio}')
        WHERE editable = 'editable'
            AND src_schema = '{item.src_schema}'
            AND src_table = '{item.src_table}'
            AND object_type='{item.object_type}'
            """.replace("''", "NULL")
        pg.execute(query)
        query2 = f"""
        DELETE FROM dq_sbx.gp_object
        WHERE object_schema='{item.src_schema}'
            AND object_name='{item.src_table}'
            AND object_type='{item.object_type}';

        INSERT INTO dq_sbx.gp_object (it_code, src_name, object_schema, object_name, object_type, team, developer_rb, analyst_rb)
        VALUES('ci466068', 'greenplum',
            '{item.src_schema}', '{item.src_table}', '{item.object_type}', '{item.team}', '{item.developer_rb}', '{item.analyst_rb}');
        """.replace("''", "NULL")
        pg.execute(query2)
        return True
    except Exception as e:
        return e


@app.post('/aba')
def aba(item: List_Item):
    """Информация по aba - возвращает aba и id_aba.Или всю строку, в зависмости от влага list_flag.
    Если list_flag - True то выпадающий список по аналогии с users_rb"""
    item.name = re.sub(r"[^a-z_0-9.#а-яё ]",'',item.name.lower())
    if item.list_flag:
        query = f"""
        SELECT id_aba, aba
        FROM cmd.aba
        WHERE aba ilike '%{item.name}%'
        ORDER BY aba
        limit {item.limit}
        """
        return pg.getData(query).columns.tolist(), pg.getData(query).values.tolist()
    else:
        query = f"""
        SELECT *
        FROM cmd.aba
        WHERE aba ilike '%{item.name}%'
        ORDER BY aba
        limit {item.limit}
        """
        return pg.getData(query).columns.tolist(), pg.getData(query).values.tolist()


@app.post('/data_object_name')
def data_object_name(item: List_Item):
    """Информация по dd - возвращает data_object_name и id_dd. Или всю строку, в зависмости от влага list_flag.
    Если list_flag - True то выпадающий список по аналогии с users_rb"""
    item.name = re.sub(r"[^a-z_0-9.#а-яё ]",'',item.name.lower())
    if item.list_flag:
        query = f"""
        SELECT id_dd, data_object_name
        FROM cmd.dd
        WHERE data_object_name ilike '%{item.name}%'
        ORDER BY data_object_name
        limit {item.limit}
        """
        return pg.getData(query).columns.tolist(), pg.getData(query).values.tolist()
    else:
        query = f"""
        SELECT *
        FROM cmd.dd
        WHERE data_object_name ilike '%{item.name}%'
        ORDER BY data_object_name
        limit {item.limit}
        """
        return pg.getData(query).columns.tolist(), pg.getData(query).values.tolist()


@app.post('/termin')
def termin(item: List_Item):
    """Информация по BG - возвращает termin и id_bg. Или всю строку, в зависмости от влага list_flag.
    Если list_flag - True то выпадающий список по аналогии с users_rb"""
    item.name = re.sub(r"[^a-z_0-9.#а-яё ]",'',item.name.lower())
    if item.list_flag:
        query = f"""
        SELECT id_bg, termin
        FROM cmd.bg
        WHERE termin ilike '%{item.name}%'
        ORDER BY termin
        limit {item.limit}
        """
        return pg.getData(query).columns.tolist(), pg.getData(query).values.tolist()
    else:
        query = f"""
        SELECT *
        FROM cmd.bg
        WHERE termin ilike '%{item.name}%'
        ORDER BY termin
        limit {item.limit}
        """
        return pg.getData(query).columns.tolist(), pg.getData(query).values.tolist()


@app.post('/name_system')
def name_system(item: List_Item):
    """Информация по it_code  - возвращает name_system и it_code. Выпадающий список по аналогии с users_rb"""
    item.name = re.sub(r"[^a-z_0-9.#а-яё ]",'',item.name.lower())
    query = f"""
    SELECT it_code, name_system
    FROM dq_sbx.registry_it_system
    WHERE name_system ilike '%{item.name}%' or it_code ilike '%{item.name}%'
    ORDER BY name_system
    limit {item.limit}
        """
    return pg.getData(query).columns.tolist(), pg.getData(query).values.tolist()


@app.post('/update_aba')
def update_aba(item: Update_ABA):
    """По аналогии с Update_GP_Object, но для ABA"""
    try:
        item.business_area = re.sub(r"[^а-яёА-ЯЁa-zA-Z0-9_.#/ ]",'',item.business_area)
        item.organisation_domain = re.sub(r"[^а-яёА-ЯЁa-zA-Z0-9_.#/ ]",'',item.organisation_domain)
        item.domain_data_owner = re.sub(r"[^а-яёА-ЯЁa-zA-Z0-9_.#/ ]",'',item.domain_data_owner)
        item.aba = re.sub(r"[^а-яёА-ЯЁa-zA-Z0-9_.#/ ]",'',item.aba)
        item.aba_description = re.sub(r"[^а-яёА-ЯЁa-zA-Z0-9_.#/ ]",'',item.aba_description)

        item.data_owner = re.sub(r"[^а-яёА-ЯЁa-zA-Z0-9_.#/ ]",'',item.data_owner)
        item.buisness_process = re.sub(r"[^а-яёА-ЯЁa-zA-Z0-9_.#/ ]",'',item.buisness_process)
        item.status = re.sub(r"[^а-яёА-ЯЁa-zA-Z0-9_.#/ ]",'',item.status)
        item.critical = re.sub(r"[^а-яёА-ЯЁa-zA-Z0-9_.#/ ]",'',item.critical)

        if item.id_aba:
            query = f"""
            UPDATE cmd.aba
            SET
            (business_area, organisation_domain, domain_data_owner,
            aba, aba_description, data_owner, buisness_process,
            status, critical) =
            ('{item.business_area}', '{item.organisation_domain}', '{item.domain_data_owner}', 
            '{item.aba}', '{item.aba_description}','{item.data_owner}','{item.buisness_process}',
            '{item.status}','{item.critical}')
            WHERE id_aba = {item.id_aba}
            """.replace("''", "NULL")
            pg.execute(query)
            return True
        else:
            query = f"""
            INSERT INTO cmd.aba
            ('{item.business_area}', '{item.organisation_domain}', '{item.domain_data_owner}', 
            '{item.aba}', '{item.aba_description}','{item.data_owner}','{item.buisness_process}',
            '{item.status}','{item.critical}')
            """.replace("''", "NULL")
            pg.execute(query)
            return True
    except Exception as e:
        return e


@app.post('/update_bg')
def update_bg(item: Update_BG):
    """По аналогии с update_aba, но для BG"""
    try:
        item.termin = re.sub(r"[^а-яёА-ЯЁa-zA-Z0-9_.#/ ]",'',item.termin)
        item.description = re.sub(r"[^а-яёА-ЯЁa-zA-Z0-9_.#/ ]",'',item.description)
        item.master_type = re.sub(r"[^а-яёА-ЯЁa-zA-Z0-9_.#/ ]",'',item.master_type)
        item.it_code = re.sub(r"[^а-яёА-ЯЁa-zA-Z0-9_.#/ ]",'',item.it_code)

        if item.id_bg:
            query = f"""
            UPDATE cmd.bg
            SET
            (termin, description, master_type, it_code) =
            ('{item.termin}', '{item.description}', '{item.master_type}', '{item.it_code}')
            WHERE id_bg = {item.id_bg}
            """.replace("''", "NULL")
            pg.execute(query)
            return True
        else:
            query = f"""
            INSERT INTO cmd.bg
            ('{item.termin}', '{item.description}', '{item.master_type}', '{item.it_code}')
            """.replace("''", "NULL")
            pg.execute(query)
            return True
    except Exception as e:
        return e


@app.post('/update_dd')
def update_dd(item: Update_DD):
    """По аналогии с update_aba, но для DD"""
    try:
        item.data_object_name = re.sub(r"[^а-яёА-ЯЁa-zA-Z0-9_.#/ ]",'',item.data_object_name)
        item.business_object_flag = re.sub(r"[^а-яёА-ЯЁa-zA-Z0-9_.#/ ]",'',item.business_object_flag)
        item.format_dd = re.sub(r"[^а-яёА-ЯЁa-zA-Z0-9_.#/ ]",'',item.format_dd)
        item.parent_object = re.sub(r"[^а-яёА-ЯЁa-zA-Z0-9_.#/ ]",'',item.parent_object)
        item.status_bo = re.sub(r"[^а-яёА-ЯЁa-zA-Z0-9_.#/ ]",'',item.status_bo)
        item.adoit_id = re.sub(r"[^а-яёА-ЯЁa-zA-Z0-9_.#/ ]",'',item.adoit_id)

        if item.id_dd:
            query = f"""
            UPDATE cmd.dd
            SET
            (data_object_name, business_object_flag, format_dd, parent_object,
            status_bo, adoit_id) =
            ('{item.data_object_name}', '{item.business_object_flag}', '{item.format_dd}', '{item.parent_object}',
            '{item.status_bo}', '{item.adoit_id}')
            WHERE id_dd = {item.id_dd}
            """.replace("''", "NULL")
            pg.execute(query)
            return True
        else:
            query = f"""
            INSERT INTO cmd.dd
            ('{item.data_object_name}', '{item.business_object_flag}', '{item.format_dd}', '{item.parent_object}',
            '{item.status_bo}', '{item.adoit_id}')
            """.replace("''", "NULL")
            pg.execute(query)
            return True
    except Exception as e:
        return e


@app.post('/bg_aba_dd')
def bg_aba_dd(item: List_Item):
    """Информация по вьюхе связей bg_aba_dd_view - возвращает termin и id_bg. Или всю строку, в зависмости от влага list_flag.
    Если list_flag - True то выпадающий список по аналогии с users_rb"""
    item.name = re.sub(r"[^a-z_0-9.#а-яё ]",'',item.name.lower())
    if item.list_flag:
        query = f"""
        SELECT id_bg, termin
        FROM cmd.bg_aba_dd_view
        WHERE termin ilike '%{item.name}%'
        ORDER BY termin
        limit {item.limit}
        """
        return pg.getData(query).columns.tolist(), pg.getData(query).values.tolist()
    else:
        query = f"""
        SELECT *
        FROM cmd.bg_aba_dd_view
        WHERE termin ilike '%{item.name}%'
        ORDER BY termin
        limit {item.limit}
        """
        return pg.getData(query).columns.tolist(), pg.getData(query).values.tolist()


@app.post('/update_bg_aba_dd')
def update_bg_aba_dd(item: Update_BG_ABA_DD):
    """По аналогии с BG но для таблице связей bg_aba_dd"""
    try:
        query = f"""
            UPDATE cmd.bg_aba_dd
            SET
            (id_dd, id_aba) =
            ('{item.id_dd}', '{item.id_aba}')
            WHERE id_bg = {item.id_bg}
            """.replace("'None'", "NULL")
        pg.execute(query)
        return True
    except Exception as e:
        return e


if __name__ == "__main__":
    """ запускает сервер  uvicorn для API"""
    config = uvicorn.Config("main:app", port=8000, log_level="info", workers=2)
    server = uvicorn.Server(config)
    server.run()