import re


"""
Функционал поиска, формирует финальный поисковый запрос к таблице на основе ключей и фильтров в запросе.
Переписать на ООП
"""

f_odpp = lambda x: ' AND table_name IS NOT NULL ' if x else ''
f_col = lambda x: ' AND table_code in (SELECT table_code FROM filters_col ) ' if x else ''
f_limit = lambda x: f' LIMIT {x}' if x > 0 else ''
f_search_val = lambda x: ' as search_val,' if x else ''


def f_true_false(query, filters, fields):
    """ Условия для WHERE включают или выключают подзапросы в зависимости от фильтров поиска """
    if query:
        if filters:
            if fields:
                return ' 1=1 '
            else:
                return ' 1=2 '
        else:
            if fields:
                return ' 1=1 '
            else:
                return ' 1=2 '
    else:
        return ' 1=1 '


def filters_unzip(filters):
    """ Распаковка фильтров
    ---and it_code in ('ci467113', 'ci22222') """
    tmp =''
    if filters:
        for ft in filters:
            tmp = tmp+' AND '+str(ft.field)+' IN ('+str(ft.value)[1:-1]+')'
        return tmp
    else:
        return tmp


def fields_update(query):
    """Апдейт столбцов для поиска"""
    if query.fields_tab:
        if 'table' in query.fields_tab:
            """Заменить table на table_name и src_table """
            query.fields_tab.discard('table')
            query.fields_tab.update({'table_name','src_table'})
        return query
    else:
        return query



def fields_unzip(query, fields):
    """Распакуем столбцы для поиска
     ---and ( entity_name like '%dq_sbx.profiling_columns%' OR col_comment like '%dq_sbx.profiling_columns%')
    """
    if query:
        if fields:
            tmp =[]
            for fl in fields:
                tmp.append(str(fl)+" like '%"+str(query)+"%' \n                ")
            return ' and \n                ( '+ 'OR '.join(tmp) + ' ) '
        return ''
    else:
        return ''



def fields_unzip_case(query, fields):
    """Распакуем столбцы для сбора результата поиска
    ---WHEN table_name like '%dq_sbx.profiling_columns%' THEN table_name
    """
    if query:
        if fields:
            tmp =[]
            for fl in fields:
                tmp.append("WHEN "+str(fl)+" like '%"+str(query)+"%' THEN "+str(fl))
                s = 'CASE ' + '\n                '.join(tmp) + ' ELSE NULL \n                END'
            return s
        else:
            return "''"
    else:
        return "''"



def filters_col_with(filters_col, query):
    """Генерирует WITH для фильра в decr_col"""
    tmp = ''
    if filters_col:
        tmp =f"""
        WITH filters_col AS (
        SELECT table_code FROM dq_sbx.descr_col WHERE 1=1
        {filters_unzip(query.filters_col)}
        GROUP BY table_code
        )"""
        return tmp
    else:
        return tmp


def search_query(query):
    """ Функция формирующая финальный запрос к базе"""
#     Очистим запрос от потенциальных sql-иньекций
    query.query = query.query.lower().replace("'",'').replace('"','').replace('%','').replace('\\','').strip()
    # if query: - лишняя ? Зачем я это написал?
    if query:
        q = f"""
        {filters_col_with(query.filters_col, query)}

            SELECT
            it_code, src_table, tab_comment, table_code,
            array_agg(coalesce(schema_name||'.'||table_name, 'NULL')||','||src_schema||'.'||src_table) as search_val
            FROM dq_sbx.descr_tab
            WHERE {f_true_false(query.query, query.filters_tab, query.fields_tab)}
                AND (schema_name||'.'||table_name='{query.query}' OR src_schema||'.'||src_table= '{query.query}')
                {filters_unzip(query.filters_tab)}
                {f_odpp(query.odpp)}
                {f_col(query.filters_col)}
            GROUP BY it_code, src_table, table_code, tab_comment

            UNION
            (
            SELECT
            it_code, src_table, tab_comment, table_code, NULL as search_val

            FROM dq_sbx.descr_tab
            WHERE {f_true_false(query.query, query.filters_tab, query.fields_tab)}
                {fields_unzip(query.query, query.fields_tab)}
                {filters_unzip(query.filters_tab)}
                {f_odpp(query.odpp)}
                {f_col(query.filters_col)}
            GROUP BY it_code, src_table, table_code, tab_comment
            )
            UNION
            (
            SELECT
                t.it_code, t.src_table, max(t.tab_comment) as tab_comment, c.table_code,
                c.search_val
            FROM (
                SELECT
                table_code,
                array_agg(col_name||','||coalesce (col_comment,'NULL')) as search_val
                FROM dq_sbx.descr_col
                WHERE {f_true_false(query.query, query.filters_col, query.fields_col)}
                {fields_unzip(query.query, query.fields_col)}
                {filters_unzip(query.filters_col)}
                GROUP BY table_code
                ) as c
            LEFT JOIN dq_sbx.descr_tab  as t ON c.table_code = t.table_code
            WHERE 1=1
            {filters_unzip(query.filters_tab)}
            GROUP BY t.it_code, t.src_table, c.table_code, c.search_val
            )

        {f_limit(query.limit)}
            """
    return q

