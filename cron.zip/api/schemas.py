from pydantic import BaseModel, validator
from datetime import date
from typing import Optional, List, Dict, Set, Union



""" schemas нужна для валидации json, автоматом проверяет типы данных, заполняет дефолтные значения и т.д.
Базируется на pydantic и частично на typing. validator в самом api не заводиться (но это не точно) его функции реализавнны вручную"""

class Filters_Dict(BaseModel):
    """ Модель для фильтров по it_code, contact_person и domain_data_owner"""
    field: str
    value: List[str]


class User_Query(BaseModel):
    """ Схема для поискового запроса в mflow"""
    query: str = ''
    odpp: bool = False
    fields_tab: Set[str] = None
    fields_col: Set[str] = None

    filters_tab: List[Union[Filters_Dict, None]] = None
    filters_col: List[Union[Filters_Dict, None]] = None
    limit: int = 300

# {
#   "query": "profiling",
#   "odpp": true,
#   "fields_tab": ["table", "tab_comment"],
#   "fields_col": ["col_name", "col_comment","entity_name"],
#   "filters_tab": [
#     {
#             "field":"it_code",
#             "value": ["ci467113","ci22222"]
#             }
#   ],
#   "filters_col": [
#     {
#             "field":"contact_person",
#             "value": ["розумеенко марина сергеевна","test" ]
#         }
#         ,
#         {
#             "field":"domain_data_owner",
#             "value": ["data","test" ]
#         }
#   ],
#   "limit": 50
# }


class Table_Info(BaseModel):
    """Для запроса информации по таблицам"""
    table_code: str

# {
#   "table_code": "ci75307_bis __sdal__sddu"
# }


class Table_Name(BaseModel):
    """Таблица Odpp - Часть модели для профайлинга и инфо по сталбцам"""
    schema_name: str
    table_name: str


class Column_Info(BaseModel):
    """Для запроса информации по столбцам """
    table_code: str
    odpp: Union[Table_Name, None] = None

# {
#   "table_code": "ci75307_bis __sdal__sddu",
#   "odpp": {
#     "schema_name": "hist_bis_sbl_etl",
#     "table_name": "sdal_sbl_sddu"
#   }
# }


class Profiling_Info(BaseModel):
    """Для запроса информации по профилированию """
    odpp: Table_Name
    col_name: str = None


# {
#   "odpp": {
#     "schema_name": "hist_bis_sbl_etl",
#     "table_name": "sdal_sbl_sddu"
#   },
# "col_name": "ddcode"
# }


class List_Item(BaseModel):
    """ Схема для поиска RB, фио, ABA, DD, BG, объектов GP и т.д. """
    name: str = ''
    limit: int = 100
    list_flag: bool = True

# {
# "name": "dds.f_calc",
# "limit": 100
# }


class Update_GP_Object(BaseModel):
    """ Схема для апдета объектов GP, добавляет разработчика, аналитика и команду """
    team: str = ''
    developer_rb: str = ''
    developer_fio: str = ''
    analyst_rb: str = ''
    analyst_fio: str = ''
    src_schema: str
    src_table: str
    object_type: str

# {
#     "team": "Test_team",
#     "developer_rb": "developer_rb_test",
#     "developer_fio": "Developer Fio Test",
#     "analyst_rb": "analyst_rb_test",
#     "analyst_fio": "Analyst Fio Test",
#     "src_schema": "dict",
#     "src_table": "account_block_type",
#     "object_type": "table/view"
# }


class Update_ABA(BaseModel):
    """ Схема для апдета таблицы ABA, добавляет ABA, описание, владельцев и т.д."""
    id_aba: int = None
    business_area: str = ''
    organisation_domain: str = ''
    domain_data_owner: str = ''
    aba: str = ''
    aba_description: str = ''
    data_owner: str = ''
    buisness_process: str = ''
    status: str = ''
    critical: str = ''

# {
#     "id_aba": 1014,
#     "business_area": "Business Support",
#     "organisation_domain": "AUDIT",
#     "domain_data_owner": "Далиненко Андрей Борисович",
#     "aba": "Audit reporting",
#     "aba_description": "Отчетность по внутреннему аудиту",
#     "data_owner": "Далиненко Андрей Борисович",
# }


class Update_BG(BaseModel):
    """ Схема для апдета таблицы BG, добавляет termin, description, master_type, it_code"""
    id_bg: int = None
    termin: str = ''
    description: str = ''
    master_type: str = ''
    it_code: str = ''

# {
#     "id_bg": 1003,
#     "termin": "Сотрудник",
#     "description": "Наемный работник по трудовому договору в Организации",
#     "master_type": "Мастер",
#     "it_code": "ci272858"
# }


class Update_DD(BaseModel):
    """ Схема для апдета таблицы DD, добавляет data_object_name, business_object_flag, format, parent_object, status_bo, adoit_id"""
    id_dd: int = None
    data_object_name: str = ''
    business_object_flag: str = ''
    format_dd: str = ''
    parent_object: str = ''
    status_bo: str = ''
    adoit_id: str = ''

# {
#     "id_dd": 1008,
#     "data_object_name": "Employee",
#     "business_object_flag": "Yes",
#     "format_dd": "BO",
#     "parent_object": "person",
#     "status_bo": "Кандидат",
#     "adoit_id": "BIAN.BO.467"
# }