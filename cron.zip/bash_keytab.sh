#!/bin/bash

export KRB5CCNAME=/tmp/krb5cc_$(/usr/bin/id rbsdq_odpp@ROSBANK.RUS.SOCGEN -u)_$(/usr/bin/id -u)
export KRB5_CONFIG=/etc/krb5.conf.d/krb5.conf
export JAVA_TOOL_OPTIONS="-Djava.security.krb5.conf=/etc/krb5.conf.d/krb5.conf"

export SPARK_HOME=/usr/hdp/current/spark2-client/
export PYSPARK_PYTHON=/usr/local/bin/python3.7
export HADOOP_CONF_DIR=/usr/hdp/current/hadoop-client/conf/
export PYTHONPATH=/usr/hdp/current/spark2-client/python/lib/py4j-0.10.7-src.zip:/usr/hdp/current/spark2-client/python/
export PYTHONSTARTUP=/usr/hdp/current/spark2-client/python/pyspark/shell.py

kinit -v -R -c /tmp/krb5cc_$(/usr/bin/id rbsdq_odpp@ROSBANK.RUS.SOCGEN -u)_$(/usr/bin/id -u) -k -t /home/rosbank.rus.socgen/rba079895/rbsdq_odpp.keytab rbsdq_odpp@ROSBANK.RUS.SOCGEN
