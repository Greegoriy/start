import os 
import sys
import subprocess
from pyspark.sql import SparkSession
import pandas as pd
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor


# импорт собственных модулей
from spark_exceptions_handler import SparkExceptionsHandler
from spark_profiling_exceptions import EmptyTableError
from postgres_connection import PostgresConnection
from logger import Logger


# настройка окружения
username = "rbsdq_odpp@ROSBANK.RUS.SOCGEN"
p = subprocess.Popen(f"/usr/bin/id {username} -u", shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
id_str1 = p.stdout.readline().decode("utf-8").replace("\n", "")
p = subprocess.Popen(f"id  -u", shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
id_str2 = p.stdout.readline().decode("utf-8").replace("\n", "")
os.environ ["JAVA_TOOL_OPTIONS"] = "-Djava.security.krb5.conf=/etc/krb5.conf.d/krb5.conf"
os.environ ["KRB5_CONFIG"] = "/etc/krb5.conf.d/krb5.conf"
os.environ ["KRB5CCNAME"] = f"/tmp/krb5cc_{id_str1}_{id_str2}"
spark_home = "/usr/hdp/current/spark2-client/"
os.environ ['SPARK_HOME'] = spark_home
sys.path.insert(0, os.path.join(spark_home, 'python'))
os.environ['PYSPARK_PYTHON'] = './environment/bin/python3.7'
os.environ ['HADOOP_CONF_DIR'] = '/usr/hdp/current/hadoop-client/conf/'
os.environ ['PYTHONPATH'] = '/usr/hdp/current/spark2-client/python/lib/py4j-0.10.7-src.zip:/usr/hdp/current/spark2-client/python/'
os.environ ['PYTHONSTARTUP'] = '/usr/hdp/current/spark2-client/python/pyspark/shell.py'



class DetectingUnavailableTables:
    """Класс для идентификации недоступных таблиц в Hive"""

    def __init__(self) -> None:
        self.spark = (SparkSession
            .builder
            .enableHiveSupport()
            .appName('detecting_unavailable_hive_tables')
            .getOrCreate())
        self.db = PostgresConnection() 
        self.logger = Logger.get_detection_logger()

    
    def _get_source_tables(self) -> pd.DataFrame:
        """Функция для получения списка таблиц, которые нужно проверить"""
        
        query = """
        SELECT 
            schema_name,
            table_name,
            id_table
        FROM dq_sbx.profiling_relevance_rating_v
        """
        source_tables = self.db.get_data(query)
        return source_tables
    
    
    def truncate_table(self) -> None:
        """Функция для удаления данных из таблицы dq_sbx.unavailable_tables"""
        
        query = 'TRUNCATE dq_sbx.unavailable_tables'
        self.db.execute_sql(query)
    
    
    def _catch_error(self, source: pd.DataFrame, error: str) -> None:
        """Функция для определения ошибки"""
        
        error_handler = SparkExceptionsHandler(self.db, source.schema_name, source.table_name, source.id_table)
        error_message = error_handler.get_error_type(error)
        
        if 'FAILED DUE TO EXCEPTION' in error_message:
            self.logger.error(f'{source.schema_name}.{source.table_name} - {error_message}')

                
    def check_unavailable_table(self, source: pd.DataFrame) -> None:
        """Функция для проверки таблицы на доступность"""
        
        try:
            table_rows_count = (self.spark
                .table(f'{source.schema_name}.{source.table_name}')
                .limit(10000)
                .count())
            if table_rows_count == 0:
                raise EmptyTableError
        except Exception as error:
            self._catch_error(source, error)
         
           
    def detect(self) -> None:
        """Функция для определения всех недоступных таблиц на текущий момент в Hive"""
        
        try:
            self.truncate_table()
            source_tables = self._get_source_tables()
        
            with ThreadPoolExecutor(30) as pool:
                pool.map(self.check_unavailable_table, source_tables.itertuples(index=False))
        except Exception as e:
            self.logger.error(e)
        
        self.spark.stop()
        self.db.close_db_connection()
        
        
if __name__ == "__main__":
    DetectingUnavailableTables().detect()