#!/bin/bash

# Переменные окружения
export KRB5CCNAME=/tmp/krb5cc_$(/usr/bin/id rbsdq_odpp@ROSBANK.RUS.SOCGEN -u)_$(/usr/bin/id -u)
export KRB5_CONFIG=/etc/krb5.conf.d/krb5.conf
export JAVA_TOOL_OPTIONS="-Djava.security.krb5.conf=/etc/krb5.conf.d/krb5.conf"
export SPARK_HOME=/usr/hdp/current/spark2-client/
export PYSPARK_PYTHON=/usr/local/bin/python3.7
export HADOOP_CONF_DIR=/usr/hdp/current/hadoop-client/conf/
export PYTHONPATH=/usr/hdp/current/spark2-client/python/lib/py4j-0.10.7-src.zip:/usr/hdp/current/spark2-client/python/
export PYTHONSTARTUP=/usr/hdp/current/spark2-client/python/pyspark/shell.py

# Запуск скрипта Spark
spark-submit --master yarn \
--deploy-mode client \
--num-executors 60 \
--executor-cores 1 \
--driver-memory 15g  \
--executor-memory 8g \
--conf spark.driver.cores=1   \
--conf spark.driver.maxResultSize=12g  \
--conf spark.serializer=org.apache.spark.serializer.KryoSerializer  \
--conf spark.kryoserializer.buffer.max=128 \
--conf spark.sql.execution.arrow.pyspark.enabled=true  \
--conf spark.sql.crossJoin.enabled=true \
--conf spark.sql.autoBroadcastJoinThreshold=-1 \
--conf spark.executor.memoryOverhead=2048 \
--conf spark.driver.memoryOverhead=1042 \
--conf spark.executor.extraJavaOptions=-XX:+UseG1GC  \
--conf spark.driver.extraJavaOptions=-XX:+UseG1GC \
--conf spark.shuffle.service.enabled=true \
--conf spark.task.maxDirectResultSize=1g \
--conf spark.yarn.dist.archives=hdfs:///datalab/python/python-3.7-dev/python3-venv.tar.gz  \
--py-files ./files_profiling.zip \
./spark_profiling_launch.py