#! /usr/local/basement/Python-3.7.4/bin/python3.7

import time
import numpy as np
from datetime import date


from db_connectors import *

print('*********************************')
print('*      active_tables.py         *')
print('*********************************')

def get_query_from_df(schema, table, df):
    query_list = []
    df = df.fillna('NULL')
    for index, row in df.iterrows():
        row = row.apply(lambda x: x.replace("'",'`') if type(x) == str else 
                        (str(x) if type(x) == pd._libs.tslibs.timestamps.Timestamp or type(x) == date else float(x)))
        query_list.append(str(tuple(row)).replace("'NULL'", "NULL").replace("''", "NULL"))

    query_full = f'INSERT INTO {schema}.{table} VALUES' +  ', '.join(query_list)
    return query_full

max_data = str(get_df_from_dq_profiling('SELECT max(event_date) FROM dq_sbx.active_tables').loc[0][0])

print(max_data)

query = f"""
SELECT
    ip,
    ip_group,
    requser as rb,
    rb_mask,
    event_date,
    schema_name,
    table_name,
    CASE 
        WHEN table_name = table_name_full THEN 'normal' 
        ELSE 'technical' 
    END as technical_mask,
    hist_mask,
    COUNT(DISTINCT sess) AS count_query
FROM
(
    SELECT 
        cliip as ip,
        CASE 
            WHEN cliip = '10.46.132.24' THEN 'IBM information analyzer'
            WHEN cliip = '10.46.65.237' THEN 'bi1' 
            WHEN cliip = '10.46.64.204' THEN 'bi2'
            WHEN cliip = '10.46.64.13' THEN 'bi3'
            WHEN cliip = '10.45.3.101' THEN 'bi4'
            WHEN cliip = '10.45.8.54' THEN 'autoQA1'
            WHEN cliip = '10.45.8.9' THEN 'autoQA2'
            WHEN cliip = '10.45.8.20' THEN 'jh'
            
            WHEN cliip = '10.45.0.63' THEN 'rtd_bi'
            WHEN cliip = '10.46.74.69' THEN 'iis_ods_retail'
            WHEN cliip in ('10.46.74.127','10.46.74.126') THEN 'sas_alm'
            WHEN cliip in ('10.45.8.45', '10.45.8.46') THEN 'gp'
            WHEN cliip in ('10.45.1.71', '10.45.1.72', '10.45.1.73', '10.45.1.74', '10.45.1.75','10.45.8.54',
                '10.45.8.6', '10.45.8.7', '10.45.8.9', '10.45.8.10', '10.45.8.12', '10.45.8.13', '10.45.8.14', 
                '10.45.8.18', '10.45.8.19') THEN 'odpp'
            ELSE 'other' 
        END as ip_group,
        lower(requser) as requser,
        CASE WHEN lower(SUBSTRING(requser,1,3)) = 'rbs' THEN 'rbs' 
            WHEN lower(SUBSTRING(requser,1,3)) = 'rba' THEN 'rba'
            WHEN lower(SUBSTRING(requser,1,3)) = 'rbx' THEN 'rbx'
            WHEN lower(SUBSTRING(requser,1,2)) = 'rb' THEN 'rb'
            ELSE 'other'
        END as rb_mask,
        to_date(evttime) as event_date,
        regexp_extract(resource,'(^[0-9a-z_]+)/([0-9a-z_]+)',1) as schema_name,
        regexp_extract(resource,'(^[0-9a-z_]+)/([0-9a-z_]+)',2) as table_name_full,
        CASE 
            WHEN lower(SUBSTRING(regexp_extract(resource,'(^[0-9a-z_]+)/([0-9a-z_]+)',2),-5)) in ('_loc1','_loc2') THEN lower(SUBSTRING(regexp_extract(resource,'(^[0-9a-z_]+)/([0-9a-z_]+)',2),1,length(regexp_extract(resource,'(^[0-9a-z_]+)/([0-9a-z_]+)',2))-5))
            WHEN lower(SUBSTRING(regexp_extract(resource,'(^[0-9a-z_]+)/([0-9a-z_]+)',2),-8)) = '_capture' THEN lower(SUBSTRING(regexp_extract(resource,'(^[0-9a-z_]+)/([0-9a-z_]+)',2),1,length(regexp_extract(resource,'(^[0-9a-z_]+)/([0-9a-z_]+)',2))-8))
            WHEN lower(SUBSTRING(regexp_extract(resource,'(^[0-9a-z_]+)/([0-9a-z_]+)',2),-3)) = '_gp' THEN lower(SUBSTRING(regexp_extract(resource,'(^[0-9a-z_]+)/([0-9a-z_]+)',2),1,length(regexp_extract(resource,'(^[0-9a-z_]+)/([0-9a-z_]+)',2))-3))
            WHEN lower(SUBSTRING(regexp_extract(resource,'(^[0-9a-z_]+)/([0-9a-z_]+)',2),-6)) = '_parts' THEN lower(SUBSTRING(regexp_extract(resource,'(^[0-9a-z_]+)/([0-9a-z_]+)',2),1,length(regexp_extract(resource,'(^[0-9a-z_]+)/([0-9a-z_]+)',2))-6))
            ELSE regexp_extract(resource,'(^[0-9a-z_]+)/([0-9a-z_]+)',2) 
        END as table_name,
        CASE 
            WHEN SUBSTRING(regexp_extract(resource,'(^[0-9a-z_]+)/([0-9a-z_]+)',1),1,4) = 'hist' THEN 'hist' 
            ELSE 'other'
        END as hist_mask,
        sess
    FROM default.ranger_hive_audit_ext
WHERE 1=1
        AND evttime BETWEEN date_add(date('{max_data}'),+1) and date_add(current_date(),-1)
        AND restype ='@column'
        AND `action` = 'select'
) as t
GROUP BY ip, ip_group, requser, rb_mask, event_date, schema_name, table_name,
    CASE 
        WHEN table_name = table_name_full THEN 'normal' 
        ELSE 'technical' 
    END,
    hist_mask
ORDER BY event_date
"""

df_odpp = get_df_from_hive(query)

# БК
rb = '('+str(set(df_odpp.rb))[1:-1]+')'

query = f"""
select 
    fio,
    department,
    lower(rb) as rb,
    is_fired
from (
select
    h.full_nm  as fio ,
    CASE 
        WHEN (string_to_array(d.department_full_nm, ' -> '))[4] IS NOT NULL THEN (string_to_array(d.department_full_nm, ' -> '))[4] 
        ELSE (string_to_array(d.department_full_nm, ' -> '))[array_upper((string_to_array(d.department_full_nm, ' -> ')), 1)] 
        END as department,
    COALESCE(rb.value_text, 'rb' || "right"('000000' || h.employee_code, 6)) AS rb,
    CASE
        WHEN h.dt_to <= now() THEN 1
        ELSE 0
    END AS is_fired
FROM dds.employee h
    LEFT JOIN dds.employee_property rb
        ON h.id_employee = rb.id_employee 
        AND now() >= rb.dt_from 
        AND now() <= rb.dt_to 
        AND rb.id_property = 53
LEFT JOIN dict.department d 
    ON h.id_department = d.id_department
where 1=1
    and ( rb.value_text in {rb}
    or ('rb' || "right"('000000' || h.employee_code, 6)) in {rb} )
) as t
"""
df_bk = get_df_from_greenplum_rb(query)

df_full = df_odpp.merge(df_bk, how='left', on='rb')

query ="""
SELECT distinct
    src_name, schema_name, --table_name, 
    lower(i.it_system_code) as it_code, 
    ris.name_system
FROM dq_sbx.info as i
left join dq_sbx.registry_it_system as ris
    on lower(i.it_system_code) = lower(ris.it_code)
"""

df_info = get_df_from_dq_profiling(query)

df_full = df_full.merge(df_info[['src_name','schema_name','it_code','name_system']], how='left', on=['schema_name']).drop_duplicates()
df_full = df_full[['ip', 'ip_group', 'rb', 'rb_mask', 'event_date', 'schema_name', 'table_name', 'technical_mask', 'hist_mask', 'count_query', 'fio', 'is_fired', 'department', 'src_name', 'it_code', 'name_system']]


query = get_query_from_df('dq_sbx','active_tables',df_full)
# execute_dq_profiling(""" DELETE FROM dq_sbx.active_tables WHERE event_date < Current_date-1095 """)
# execute_dq_profiling(""" DELETE FROM dq_sbx.active_tables WHERE 1=1 """)
execute_dq_profiling(query)

print('active_tables - готово!')