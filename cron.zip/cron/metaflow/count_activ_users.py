#! /usr/local/basement/Python-3.7.4/bin/python3.7

from datetime import datetime,date,timedelta
import sqlite3 as sq
import os

from db_connectors import *


print('*********************************')
print('*     count_activ_users.py      *')
print('*********************************')


def get_query_from_df(schema, table, df):
    query_list = []
    df = df.fillna('NULL')
    for index, row in df.iterrows():
        row = row.apply(lambda x: x.replace("'",'`') if type(x) == str else 
                        (str(x) if type(x) == pd._libs.tslibs.timestamps.Timestamp or type(x) == date else 
                         float(x)))
        query_list.append(str(tuple(row)).replace("'NULL'", "NULL"))

    query_full = f'INSERT INTO {schema}.{table} VALUES' +  ', '.join(query_list)
    return query_full
    
# execute_dq_profiling("""DROP TABLE IF EXISTS "dq_sbx"."count_activ_users" """)
# execute_dq_profiling("""
# CREATE TABLE "dq_sbx"."count_activ_users"  ( 
#     "source_system" varchar NULL,
#     "sampling_date" timestamp NULL,
#     "activ_user" int NULL
#     )
# """)


#GP
df_gp = get_df_from_greenplum("""
SELECT 
'gp' as source_system,
CURRENT_DATE as sampling_date,
SUM(active_cnt) as activ_user
from  meta.vw_active_users
""")

#Mflow
df_mflow = get_df_from_dq_profiling_ro("""
SELECT 
    'mflow' as source_system,
    CURRENT_DATE as sampling_date,
    COUNT(DISTINCT login) as activ_user
FROM  dq_sbx.users_log
WHERE action_time >= (NOW() - INTERVAL '30 DAY')
""")

#ODPP
df_odpp = get_df_from_hive("""
SELECT 
'odpp' as source_system,
current_date() as sampling_date ,
count(distinct requser) as activ_user
FROM default.ranger_hive_audit_ext
where evttime >= date_add(current_date(),-30)
""")

#JH
os.system('cp /etc/jupyterhub/jupyterhub.sqlite jupyterhub.sqlite')
con = sq.connect("jupyterhub.sqlite")
cur = con.cursor()

cur.execute("""
SELECT 
'jh' as source_system,
date('now') as sampling_date ,
count(distinct name) as activ_user
FROM users 
WHERE last_activity >= datetime('now', '-30 days')""")

columns = [column[0] for column in cur.description]
records = cur.fetchall()
df_jh = pd.DataFrame(data=records, columns=columns)


df = pd.concat([df_odpp, df_mflow, df_gp, df_jh])
execute_dq_profiling(get_query_from_df("dq_sbx","count_activ_users",df))
print(' count_activ_users - готово')