#! /usr/local/basement/Python-3.7.4/bin/python3.7

import time
import numpy as np
from datetime import date

from db_connectors import *

print('*********************************')
print('*         descr.py              *')
print('*********************************')


# query = """
# CREATE TABLE dq_sbx.descr (
# 	id_table int4 NULL, -- id таблицы
# 	src_name varchar NULL, -- полное имя источника
# 	src_schema varchar NULL, -- схема в источнике
# 	src_table varchar NULL, -- таблица в источнике
# 	last_state varchar NULL,
# 	last_dt_from timestamp null,
# 	load_mode varchar NULL,
# 	tab_comment varchar NULL, -- комментарий к таблице
# 	col_name varchar NULL, -- название столбца
# 	col_type varchar NULL, -- тип столбца
# 	col_comment varchar NULL, -- комментарий к столбцу
# 	personal_data_group varchar NULL, -- группа перс данных (по классификации ИБ)
# 	attribute_quality varchar NULL, -- требования к качеству атрибута (формат / обязательность заполнения и т.п.)
# 	contact_person varchar NULL, -- контактное лицо (Владелец данных)
# 	domain_data_owner varchar NULL, -- домен владельца данных
# 	col_comment_meta varchar NULL, -- комментарий столбца из меты
# 	col_comment_glossary varchar NULL, -- комментарий столбца из глоссария
# 	flag_algorithm varchar NULL, -- флаг заполнения комментария
# 	schema_name varchar NULL, -- база
# 	table_name varchar NULL, -- таблица
# 	it_code varchar NULL, -- Код ИТ-системы
# 	table_code varchar NULL, -- ключ таблицы
# 	is_in_archive varchar NULL, -- флаг архивации таблицы
# 	count_columns int4 NULL,
# 	col_position int4 NULL,
# 	user_comments varchar NULL, -- пользовательский комментарий
# 	entity_name varchar NULL, -- Сущность
# 	entity_flag varchar NULL -- Флаг сущности
# );
# """




query = """ truncate dq_sbx.descr;
insert into dq_sbx.descr 
SELECT 
	id_table, 
	src_name, 
	src_schema, 
	src_table, 
	tab_comment, 
	col_name, 
	col_type, 
	col_comment, 
	personal_data_group, 
	attribute_quality, 
	contact_person, 
	domain_data_owner, 
	col_comment_meta, 
	col_comment_glossary, 
	flag_algorithm, 
	schema_name, 
	table_name, 
	it_code, 
	table_code, 
	is_in_archive, 
	count_columns, 
	col_position, 
	user_comments, 
	entity_name, 
	null as entity_flag 
FROM dq_sbx.full_description
ORDER BY table_code,col_position,col_name;"""
execute_dq_profiling(query)


query = """
truncate dq_sbx.descr_tab;
insert into dq_sbx.descr_tab 

SELECT DISTINCT 
    it_code,
    id_table,
    src_name,
    src_schema,
    src_table,
    tab_comment,
    schema_name,
    table_name,
    is_in_archive,
    table_code
FROM dq_sbx.full_description;

"""
execute_dq_profiling(query)


query = """
truncate dq_sbx.descr_col;
insert into dq_sbx.descr_col 

SELECT DISTINCT 
    table_code,
    col_name,
    col_type,
    col_comment,
    flag_algorithm,
    personal_data_group,
    attribute_quality,
    contact_person,
    domain_data_owner,
    min(col_position) as col_position,
    user_comments,
    entity_name
FROM dq_sbx.full_description
group by table_code, col_name, col_type, col_comment, flag_algorithm, personal_data_group, attribute_quality, contact_person, domain_data_owner, user_comments, entity_name
ORDER BY table_code,min(col_position),col_name;

"""
execute_dq_profiling(query)

# # Бекап
# query = """
# INSERT  INTO dq_sbx.descr_backup
# SELECT 
#     id_table, 
#     src_name, 
#     src_schema, 
#     src_table, 
#     tab_comment, 
#     col_name, 
#     col_type, 
#     col_comment, 
#     personal_data_group, 
#     attribute_quality, 
#     contact_person, 
#     domain_data_owner, 
#     col_comment_meta, 
#     col_comment_glossary, 
#     flag_algorithm, 
#     schema_name, 
#     table_name, 
#     it_code, 
#     table_code, 
#     is_in_archive, 
#     count_columns, 
#     col_position, 
#     user_comments, 
#     entity_name,
#     entity_flag,
#     CURRENT_DATE backup_date
# FROM dq_sbx.descr;

# DELETE FROM dq_sbx.descr_backup WHERE backup_date < (NOW() - INTERVAL '365 DAY') 
# """

# execute_dq_profiling(query)
# execute_dq_profiling("""DELETE FROM dq_sbx.descr_backup WHERE backup_date < (NOW() - INTERVAL '30 DAY') """)

print()
print('descr.py - готово')