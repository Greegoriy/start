#! /usr/local/basement/Python-3.7.4/bin/python3.7
from datetime import date



from db_connectors import *

print('*********************************')
print('*         info_count.py         *')
print('*********************************')

def get_query_from_df(schema, table, df):
    query_list = []
    df = df.fillna('NULL')
    for index, row in df.iterrows():
        row = row.apply(lambda x: x.replace("'",'`') if type(x) == str else 
                        (str(x) if type(x) == pd._libs.tslibs.timestamps.Timestamp or type(x) == date else 
                         float(x)))
        query_list.append(str(tuple(row)).replace("'NULL'", "NULL"))

    query_full = f'INSERT INTO {schema}.{table} VALUES' +  ', '.join(query_list)
    return query_full


# удалить после перезда на count_table
query = """
    DELETE FROM dq_sbx.info_count WHERE cdate < Current_date-1095 ;
    INSERT INTO dq_sbx.info_count
    
    SELECT  
    DISTINCT
        CURRENT_DATE as cdate
        ,lower(src_name) src_name
        ,lower(src_schema) src_schema
        ,lower(src_table) src_table
        ,lower(it_system_code) it_code
        ,id_table
        ,is_in_archive
    FROM dq_sbx.info 
    WHERE src_name is not NULL AND src_table not ilike '%test%' ;
    """
execute_dq_profiling(query)

count_table
query = """
    DELETE FROM dq_sbx.count_table WHERE cdate < Current_date-1095 ;
    INSERT INTO dq_sbx.count_table
    
    SELECT  
    DISTINCT
        CURRENT_DATE as cdate
        ,lower(src_name) src_name
        ,lower(src_schema) src_schema
        ,lower(src_table) src_table
        ,lower(it_system_code) it_code
        ,id_table
        ,is_in_archive
        ,'Data_Lake' as source_system
    FROM dq_sbx.info 
    WHERE src_name is not NULL AND src_table not ilike '%test%' ;
    """
execute_dq_profiling(query)

# Данные из GP
query = """
    SELECT distinct 
        CURRENT_DATE as cdate,
        src_name_meta as src_name,
        src_schema, 
        src_table,
        it_code_meta as it_code,
        NULL as id_table, 
        NULL as is_in_archive, 
        'Greenplum' as source_system
    FROM dq_sbx.meta
    WHERE meta = 'greenplum'

"""
                                     
greenplum_df = get_df_from_dq_profiling_ro(query)

# Greenplum
execute_dq_profiling(get_query_from_df("dq_sbx","count_table", greenplum_df))

# Бекап
query = """
INSERT  INTO dq_sbx.descr_backup
SELECT 
    id_table, 
    src_name, 
    src_schema, 
    src_table, 
    tab_comment, 
    col_name, 
    col_type, 
    col_comment, 
    personal_data_group, 
    attribute_quality, 
    contact_person, 
    domain_data_owner, 
    col_comment_meta, 
    col_comment_glossary, 
    flag_algorithm, 
    schema_name, 
    table_name, 
    it_code, 
    table_code, 
    is_in_archive, 
    count_columns, 
    col_position, 
    user_comments, 
    entity_name,
    entity_flag,
    CURRENT_DATE backup_date
FROM dq_sbx.descr;

DELETE FROM dq_sbx.descr_backup WHERE backup_date < (NOW() - INTERVAL '365 DAY') 
"""

execute_dq_profiling(query)

print('backup - готово')
print('info_count.py - готово')