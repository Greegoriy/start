#! /usr/local/basement/Python-3.7.4/bin/python3.7
from datetime import date

from db_connectors import *

print('*********************************')
print('*           info_log.py         *')
print('*********************************')


def get_query_from_df(schema, table, df):
    query_list = []
    df = df.fillna('NULL')
    for index, row in df.iterrows():
        row = row.apply(lambda x: x.replace("'",'`') if type(x) == str else 
                        (str(x) if type(x) == pd._libs.tslibs.timestamps.Timestamp or type(x) == date else x))
        query_list.append(str(tuple(row)).replace("'NULL'", "NULL"))

    query_full = f'INSERT INTO {schema}.{table} VALUES' +  ', '.join(query_list)
    return query_full


# бeрём данные из hist_info
query = """
    SELECT  
        i.id_source
        ,i.id_table
        ,lower(i.src_full_name) src_name
        ,lower((regexp_split_to_array(i.hist_table, E'\\\.'))[1]) schema_name
        ,lower((regexp_split_to_array(i.hist_table, E'\\\.'))[2]) table_name
        ,lower(i.load_mode) load_mode
        ,lower(i.last_state) last_state
        ,(i.is_src_active)
        ,(i.on_support)
        ,i.last_load as last_dt_from
        ,lower(i.src_schema) src_schema
        ,lower(i.src_table) src_table
        ,col.count_columns
        ,lower(t.etl_increment_col) etl_increment_col
        ,t.etl_increment_last_val
        ,t.is_in_archive
        ,s.it_system_code
    FROM hist.table_info as i 
    LEFT JOIN (
    SELECT 
        id_table
        ,count(id_table) as count_columns
    FROM hist.columns
    GROUP BY id_table
    ) as col
    ON col.id_table = i.id_table
    LEFT JOIN hist.tables as t
    ON t.id = i.id_table
    LEFT JOIN hist.sources as s
    ON i.id_source = s.id 
    WHERE i.src_full_name IS NOT NULL
    
    """
df_info = get_df_from_hist(query)

# перезаливка
if len(df_info) > 0:
    query_info  = get_query_from_df('dq_sbx', 'info', df_info)
    execute_dq_profiling("""TRUNCATE TABLE dq_sbx.info """)
    execute_dq_profiling(query_info)
    del query_info
    del df_info
    print('info - готово')
else:
    print('!!!!!!! info - Пустое !!!!!!!')

# Лог загрузки
# id лог на котором остановились
max_id = get_df_from_dq_profiling_ro("SELECT max(id) FROM dq_sbx.log_table").loc[0][0]

# Перегрузить полностью
# max_id = 1
# догружаем остальные данные
query = f"""
SELECT 
    id,id_table,date_begin,date_end,status,message,rows_processed,
    id_projection,appid,is_archive,stage,load_tag,dt_from,locationsuffix, 
    src_count,tgt_count,etl_increment_last_val 
FROM hist.log_table
WHERE id > {max_id}"""

df_id = get_df_from_hist(query)

# грузим если есть чё
if len(df_id) > 0:
    query_id  = get_query_from_df('dq_sbx', 'log_table', df_id)
    execute_dq_profiling("""DELETE FROM dq_sbx.log_table WHERE date_end < Current_date-28""")
    execute_dq_profiling(query_id)
    del query_id
else:
    pass

del df_id
print('Дозаливка - Готово')

# Обновим строки где status = 'running'
df = get_df_from_dq_profiling_ro("SELECT distinct id  FROM dq_sbx.log_table Where lower(status) = 'running' and id IS NOT NULL")

if len(df) > 0 :
    id_running = '(' + ','.join(list(str(x) for x in df.id)) + ')'
    query = f"""SELECT 
                    id, 
                    id_table, 
                    date_begin, 
                    date_end, 
                    status, 
                    message, 
                    rows_processed, 
                    id_projection, 
                    appid, 
                    is_archive, 
                    stage, 
                    load_tag, 
                    dt_from, 
                    locationsuffix, 
                    src_count, 
                    tgt_count, 
                    etl_increment_last_val 
                FROM hist.log_table
                WHERE id in {id_running} 
                AND date_end IS NOT NULL 
                AND id IS NOT NULL"""
    
    df = get_df_from_hist(query)
    if len(df) > 0 :
        id_update = '(' + ','.join(list(str(x) for x in df.id)) + ')'
        query_id  = get_query_from_df('dq_sbx', 'log_table', df)
        execute_dq_profiling(f"DELETE FROM dq_sbx.log_table WHERE id in {id_update}")
        execute_dq_profiling(query_id)
    else:
        pass
else:
    pass
print('Готово для running')

print('info_log.py - готово')

