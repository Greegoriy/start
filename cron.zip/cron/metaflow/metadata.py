#! /usr/local/basement/Python-3.7.4/bin/python3.7

import time
from datetime import date
import numpy as np

from db_connectors import *

print('*********************************')
print('*          metadata.py            *')
print('*********************************')

def get_query_from_df(schema, table, df):
    query_list = []
    df = df.fillna('NULL')
    for index, row in df.iterrows():
        row = row.apply(lambda x: x.replace("'",'`') if type(x) == str else 
                        (str(x) if type(x) == pd._libs.tslibs.timestamps.Timestamp or type(x) == date else float(x)))
        query_list.append(str(tuple(row)).replace("'NULL'", "NULL").replace("''", "NULL"))

    query_full = f'INSERT INTO {schema}.{table} VALUES' +  ', '.join(query_list)
    return query_full

#MetaFlow
query = """
SELECT DISTINCT
    lower(me.nspname) as src_schema,
    lower(c.relname) as src_table,
    lower(a.attname) as col_name,
    lower(format_type(a.atttypid, a.atttypmod)) as col_type_meta,
    CASE WHEN obj_description(c.oid) = '' THEN NULL ELSE lower(obj_description(c.oid)) END as tab_comment_meta,
    CASE WHEN d.description = '' THEN NULL ELSE lower(d.description) END as col_comment_meta,
    lower('CI467113') as it_code_meta,
    lower('metaflow') as src_name_meta,
    lower('metaflow') as meta,
    a.attnum as col_position
FROM pg_namespace  me
LEFT JOIN pg_class c 
    ON c.relnamespace = me.oid
LEFT JOIN pg_attribute a
    ON c.oid = a.attrelid
LEFT JOIN pg_description d 
    ON a.attnum = d.objsubid
    AND d.objoid = c.oid
WHERE 1=1
    AND a.attnum > 0
    AND NOT a.attisdropped 
    AND lower(me.nspname) = 'dq_sbx'
    AND lower(c.relname) in (
        SELECT DISTINCT
            lower(c.relname) as src_table
        FROM pg_description d
        JOIN pg_attribute a on a.attnum = d.objsubid
        JOIN pg_class c on (d.objoid = c.oid and c.oid = a.attrelid)
        WHERE 1=1
            AND a.attnum > 0
            AND NOT a.attisdropped )
"""
df_metaflow = get_df_from_dq_profiling_ro(query)
print('MetaFlow - готово')

# Данные из GP
query = """
SELECT DISTINCT
    lower(me.nspname) as src_schema,
    lower(c.relname) as src_table,
    lower(a.attname) as col_name,
    lower(format_type(a.atttypid, a.atttypmod)) as col_type_meta,
    CASE WHEN obj_description(c.oid) = '' THEN NULL ELSE lower(obj_description(c.oid)) END as tab_comment_meta,
    CASE WHEN d.description = '' THEN NULL ELSE lower(d.description) END as col_comment_meta,
    lower('ci466068') as it_code_meta,
    lower('greenplum') as src_name_meta,
    lower('greenplum') as meta,
    a.attnum as col_position
FROM pg_namespace  me
LEFT JOIN pg_class c 
    ON c.relnamespace = me.oid
LEFT JOIN pg_attribute a
    ON c.oid = a.attrelid
LEFT JOIN pg_description d 
    ON a.attnum = d.objsubid
    AND d.objoid = c.oid
WHERE 1=1
AND a.attnum > 0
AND NOT a.attisdropped 

AND (lower(me.nspname) in ('dds','dm','dict','dq','ods','stg','em') OR lower(me.nspname) like 'dm_%' ) 
AND lower(c.relname) NOT LIKE '%_prt_%'
"""
                                     
greenplum_df = get_df_from_greenplum(query)
print('GP - готово')

# #Риски
# query = """
# SELECT 
#     lower(tc.OWNER) as src_schema,
#     lower(tc.TABLE_NAME) as src_table,
#     lower(tc.COLUMN_NAME) as col_name,
#     lower(tc.DATA_TYPE) as col_type_meta,
#     NULL AS tab_comment_meta,
#     CASE WHEN cc.COMMENTS = '' THEN NULL ELSE lower(cc.COMMENTS) END as col_comment_meta,
#     lower('ci272726') as it_code_meta,
#     lower('RISK') as src_name_meta,
#     lower('RISK') as meta, 
#     tc.COLUMN_ID as col_position
# FROM ALL_TAB_COLUMNS tc
# LEFT JOIN ALL_COL_COMMENTS cc 
#     ON tc.OWNER = cc.OWNER
#     AND tc.TABLE_NAME = cc.TABLE_NAME
#     AND tc.COLUMN_NAME = cc.COLUMN_NAME
# WHERE 1=1
#     AND lower(tc.OWNER) NOT IN ('sys','system','work')
#     AND NOT regexp_like(lower(tc.OWNER), '^rb[x0-9]+')
# """
# df_risk = get_df_from_risk(query)
# # столбци в нижний регистр
# params ={}
# for columns in df_risk.columns:
#     params['columns'] = columns
#     params['new_columns'] = str(columns).lower()
#     df_risk.rename(columns={'{columns}'.format(**params): '{new_columns}'.format(**params)}, inplace=True)
# print('Риски - готово')
    
# КХД
query = """
SELECT DISTINCT
    trim(lower(t.TABSCHEMA))  as src_schema,
    lower(t.TABNAME) as src_table,
    lower(c.COLNAME) as col_name,
    lower(c.TYPENAME) as col_type_meta, 
    t.tab_comment_meta,
    REGEXP_REPLACE(lower(REMARKS), '[^«»\[\]"_*:;+<>а-я`ёa-z0-9.,№%&?()//\\|	# =–-]+','') as col_comment_meta,
    lower('ci85455') as it_code_meta,
    lower('CDWH_MART') as src_name_meta,
    lower('CDWH_MART') as meta,
    c.COLNO + 1 as col_position
FROM (
    SELECT 
        TABSCHEMA, 
        TABNAME, 
        REGEXP_REPLACE(lower(REMARKS), '[^«»\[\]"_*:;+<>а-я`ёa-z0-9.,№%&?()//\\|	# =–-]+','') as tab_comment_meta
        FROM SYSCAT.TABLES
    WHERE 1=1
        AND DEFINER !='SYSIBM'
        AND NOT regexp_like(lower(TABSCHEMA), '^rb[0-9]+')
        AND NOT regexp_like(lower(TABSCHEMA), '^rba[0-9]+')
        AND NOT regexp_like(lower(TABSCHEMA), '^rbx[0-9]+')
        AND NOT regexp_like(lower(TABSCHEMA), '^rbs[0-9-]+')
        AND NOT regexp_like(lower(TABSCHEMA), '^rosbank rb[0-9]+')
        AND lower(TABSCHEMA) != 'test'
        AND lower(TABSCHEMA) != 'tmp'
        AND lower(TABSCHEMA) != 'dev'
        AND lower(TABNAME) NOT LIKE '%test%'
        ) as t
LEFT JOIN SYSCAT.COLUMNS as c
    ON c.TABSCHEMA = t.TABSCHEMA
    AND c.TABNAME = t.TABNAME

"""
df_MART = get_df_from_mart(query)

query = """
SELECT DISTINCT
    trim(lower(t.TABSCHEMA))  as src_schema,
    lower(t.TABNAME) as src_table,
    lower(c.COLNAME) as col_name,
    lower(c.TYPENAME) as col_type_meta, 
    t.tab_comment_meta,
    REGEXP_REPLACE(lower(REMARKS), '[^«»\[\]"_*:;+<>а-я`ёa-z0-9.,№%&?()//\\|	# =–-]+','') as col_comment_meta,
    lower('ci85455') as it_code_meta,
    lower('CDWH_DWH') as src_name_meta,
    lower('CDWH_DWH') as meta,
    c.COLNO + 1 as col_position
FROM (
    SELECT 
        TABSCHEMA, 
        TABNAME, 
        REGEXP_REPLACE(lower(REMARKS), '[^«»\[\]"_*:;+<>а-я`ёa-z0-9.,№%&?()//\\|	# =–-]+','') as tab_comment_meta
        FROM SYSCAT.TABLES
    WHERE 1=1
        AND DEFINER !='SYSIBM'
        AND NOT regexp_like(lower(TABSCHEMA), '^rb[0-9]+')
        AND NOT regexp_like(lower(TABSCHEMA), '^rba[0-9]+')
        AND NOT regexp_like(lower(TABSCHEMA), '^rbx[0-9]+')
        AND NOT regexp_like(lower(TABSCHEMA), '^rbs[0-9-]+')
        AND NOT regexp_like(lower(TABSCHEMA), '^rosbank rb[0-9]+')
        AND lower(TABSCHEMA) != 'test'
        AND lower(TABSCHEMA) != 'tmp'
        AND lower(TABSCHEMA) != 'dev'
        AND lower(TABNAME) NOT LIKE '%test%'
        ) as t
LEFT JOIN SYSCAT.COLUMNS as c
    ON c.TABSCHEMA = t.TABSCHEMA
    AND c.TABNAME = t.TABNAME

"""
df_DWH = get_df_from_dwh(query)

query = """
SELECT DISTINCT
    trim(lower(t.TABSCHEMA))  as src_schema,
    lower(t.TABNAME) as src_table,
    lower(c.COLNAME) as col_name,
    lower(c.TYPENAME) as col_type_meta, 
    t.tab_comment_meta,
    REGEXP_REPLACE(lower(REMARKS), '[^«»\[\]"_*:;+<>а-я`ёa-z0-9.,№%&?()//\\|	# =–-]+','') as col_comment_meta,
    lower('ci85455') as it_code_meta,
    lower('CDWH_DATAHUB') as src_name_meta,
    lower('CDWH_DATAHUB') as meta,
    c.COLNO + 1 as col_position
FROM (
    SELECT 
        TABSCHEMA, 
        TABNAME, 
        REGEXP_REPLACE(lower(REMARKS), '[^«»\[\]"_*:;+<>а-я`ёa-z0-9.,№%&?()//\\|	# =–-]+','') as tab_comment_meta
        FROM SYSCAT.TABLES
    WHERE 1=1
        AND DEFINER !='SYSIBM'
        AND NOT regexp_like(lower(TABSCHEMA), '^rb[0-9]+')
        AND NOT regexp_like(lower(TABSCHEMA), '^rba[0-9]+')
        AND NOT regexp_like(lower(TABSCHEMA), '^rbx[0-9]+')
        AND NOT regexp_like(lower(TABSCHEMA), '^rbs[0-9-]+')
        AND NOT regexp_like(lower(TABSCHEMA), '^rosbank rb[0-9]+')
        AND lower(TABSCHEMA) != 'test'
        AND lower(TABSCHEMA) != 'tmp'
        AND lower(TABSCHEMA) != 'dev'
        AND lower(TABNAME) NOT LIKE '%test%'
        ) as t
LEFT JOIN SYSCAT.COLUMNS as c
    ON c.TABSCHEMA = t.TABSCHEMA
    AND c.TABNAME = t.TABNAME
    
"""
df_DATAHUB = get_df_from_datahub(query)

# объеденим в 1 df
df_cdwh = pd.concat([df_DATAHUB, df_DWH,df_MART ])
del df_DATAHUB 
del df_DWH
del df_MART
# столбци в нижний регистр
params ={}
for columns in df_cdwh.columns:
    params['columns'] = columns
    params['new_columns'] = str(columns).lower()
    df_cdwh.rename(columns={'{columns}'.format(**params): '{new_columns}'.format(**params)}, inplace=True)
print('КХД - готово')
    
# RDWH
query = """
SELECT 
    lower(s.name)  as src_schema,
    lower(t.name) as src_table,
    lower(c.name) as col_name,
    NULL as col_type_meta,
    (e2.value) AS tab_comment_meta,
    (e.value) AS col_comment_meta,
    lower('ci384677')  as it_code_meta, 
    lower('RDWH') as src_name_meta,
    lower('rdwh') as meta,
    c.column_id as col_position
FROM sys.schemas s
LEFT JOIN sys.tables t
    ON s.schema_id = t.schema_id 
LEFT JOIN sys.columns c
    ON c.object_id = t.object_id
LEFT JOIN sys.extended_properties e
    ON e.major_id = c.object_id and e.minor_id = c.column_id
LEFT JOIN sys.extended_properties e2
    ON e2.major_id = t.object_id and e2.minor_id = 0
WHERE 1=1 
    AND lower(s.name) NOT IN ('sys','information_schema','log','meta','guest')
    AND lower(s.name) NOT LIKE 'db_%'
    AND lower(s.name) NOT LIKE 'rosbank%'
"""

df_rdwh = get_df_from_rdwh(query)

df_rdwh['col_comment_meta'] = df_rdwh['col_comment_meta'].apply(lambda x: x.decode("utf-8").lower() if type(x) == bytes else x)
df_rdwh['tab_comment_meta'] = df_rdwh['tab_comment_meta'].apply(lambda x: x.decode("utf-8").lower() if type(x) == bytes else x)
print('RDWH - готово')

# Склеем вместе
df_meta = pd.concat([df_cdwh, greenplum_df,df_rdwh, df_metaflow]) # df_risk,
del df_cdwh
del greenplum_df
del df_rdwh
# del df_risk
# del df_hist
del df_metaflow

df_meta = df_meta[['src_schema','src_table','tab_comment_meta','col_name','col_type_meta','col_comment_meta','it_code_meta','src_name_meta','meta', 'col_position']].query('it_code_meta == it_code_meta and src_schema == src_schema and src_table == src_table and col_name == col_name')
df_meta.fillna('NULL', inplace=True)

execute_dq_profiling("TRUNCATE TABLE dq_sbx.meta")
n = 0
while n <= len(df_meta):
    nn = n + 100000
    tmp = df_meta.iloc[n:nn]
    n += 100001
    meta_query   = get_query_from_df('dq_sbx', 'meta', tmp)
    execute_dq_profiling(meta_query)
    print(nn, ' - готово')
    
print('Meta - Готово')

# Columns
query = """
SELECT  i.id_table, 
        lower(c.name) as col_name,
        c."POSITION" as col_position,
        lower(c."TYPE") as col_type
FROM hist.columns as c
LEFT JOIN hist.table_info as i
ON i.id_table = c.id_table
WHERE i.id_table IS NOT NULL
"""
df_columns = get_df_from_hist(query)

query = get_query_from_df('dq_sbx','columns',df_columns)
execute_dq_profiling("TRUNCATE TABLE dq_sbx.columns")
execute_dq_profiling(query)

print('columns - Готово')


query = """
    SELECT ns.nspname as function_schema, p.proname as function_name, oidvectortypes(p.proargtypes) as type_param
    FROM pg_proc p INNER JOIN pg_namespace ns ON (p.pronamespace = ns.oid)
    WHERE 1=1
    AND (lower(ns.nspname) in ('dds','dm','dict','dq','ods','stg','em') OR lower(ns.nspname) like 'dm_%' ) 
"""
df_function = get_df_from_greenplum(query)
query = get_query_from_df('dq_sbx','function',df_function)
execute_dq_profiling(query)
print('GP_function - готово')

print('metadata.py - готово')