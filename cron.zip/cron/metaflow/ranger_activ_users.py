#! /usr/local/basement/Python-3.7.4/bin/python3.7

import os 
import sys
import subprocess
import pyspark.sql.column
import pyspark.sql.functions as f
from pyspark.sql import SparkSession
from pyspark import StorageLevel
from pyspark.sql.window import Window
from pyspark.sql.types import *
import pandas as pd
import numpy as np
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta
import time
import re
import logging
from typing import Callable, List, Dict
import subprocess, re
from subprocess import Popen, PIPE
from datetime import date


from db_connectors import *

print('*********************************')
print('*    ranger_activ_users.py      *')
print('*********************************')

def get_query_from_df(schema, table, df):
    query_list = []
    df = df.fillna('NULL')
    for index, row in df.iterrows():
        row = row.apply(lambda x: x.replace("'",'`') if type(x) == str else 
                        (str(x) if type(x) == pd._libs.tslibs.timestamps.Timestamp or type(x) == date else 
                         float(x)))
        query_list.append(str(tuple(row)).replace("'NULL'", "NULL"))

    query_full = f'INSERT INTO {schema}.{table} VALUES' +  ', '.join(query_list)
    return query_full

username = "rbsdq_odpp@ROSBANK.RUS.SOCGEN"
p = subprocess.Popen(f"/usr/bin/id {username} -u", shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
id_str1 = p.stdout.readline().decode("utf-8").replace("\n", "")
p = subprocess.Popen(f"id  -u", shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
id_str2 = p.stdout.readline().decode("utf-8").replace("\n", "")
os.environ ["JAVA_TOOL_OPTIONS"] = "-Djava.security.krb5.conf=/etc/krb5.conf.d/krb5.conf"
os.environ ["KRB5_CONFIG"] = "/etc/krb5.conf.d/krb5.conf"
os.environ ["KRB5CCNAME"] = f"/tmp/krb5cc_{id_str1}_{id_str2}"
spark_home = "/usr/hdp/current/spark2-client/"
os.environ ['SPARK_HOME'] = spark_home
sys.path.insert(0, os.path.join(spark_home, 'python'))
os.environ['PYSPARK_PYTHON'] = './environment/bin/python3.7'
os.environ ['HADOOP_CONF_DIR'] = '/usr/hdp/current/hadoop-client/conf/'
os.environ ['PYTHONPATH'] = '/usr/hdp/current/spark2-client/python/lib/py4j-0.10.7-src.zip:/usr/hdp/current/spark2-client/python/'
os.environ ['PYTHONSTARTUP'] = '/usr/hdp/current/spark2-client/python/pyspark/shell.py'
os.environ['PYSPARK_SUBMIT_ARGS'] = '''
--master yarn 
--deploy-mode client 
--num-executors 30
--executor-cores 1 
--driver-memory 12g  
--conf spark.driver.maxResultSize=12g 
--conf spark.serializer=org.apache.spark.serializer.KryoSerializer
--conf spark.sql.execution.arrow.pyspark.enabled=true
--conf spark.sql.crossJoin.enabled=true
--executor-memory 6g 
--conf spark.driver.cores=1
--conf spark.memory.fraction=0.7
--conf spark.shuffle.service.enabled=true 
--conf spark.shuffle.partitions=120
--conf spark.executor.memoryOverhead=2048
--conf spark.driver.memoryOverhead=2048
--conf spark.executor.extraJavaOptions=-XX:+UseG1GC
--conf spark.yarn.dist.archives=hdfs:///datalab/python/python-3.7-dev/python3-venv.tar.gz#environment 
pyspark-shell'''


spark = (SparkSession
    .builder
    .appName('collect_active_users_logs')
    .enableHiveSupport()
    .getOrCreate())

schema = StructType([
    StructField('reqUser', StringType())
])

sourse_dict = {
    'hdfs':'hdfs',
    'kafka':'kafka',
    'hbase':'hbaseRegional',
}

try:
    for key,val in sourse_dict.items():
        start_data = str(get_df_from_dq_profiling(f"""
                                                    SELECT max(event_date) 
                                                    FROM dq_sbx.ranger_activ_users 
                                                    WHERE source_system = '{key}'
                                                    """).loc[0][0])
        start_data =  datetime.strptime(start_data, '%Y-%m-%d').date()
        start_data = (start_data + timedelta(days=1))
        
        finish_date = (datetime.today() - timedelta(days=1)).date()
        while start_data <= finish_date:
            paths = str(f"hdfs://odpp/ranger/audit/{val}/") + str(start_data.strftime('%Y%m%d'))
            df = (spark.read.schema(schema).json(paths)).drop_duplicates().toPandas()
            df['source_system'] = str(key)
            df['evtTime'] = str(start_data.strftime('%Y-%m-%d'))
            execute_dq_profiling(get_query_from_df("dq_sbx","ranger_activ_users",df[['source_system','evtTime','reqUser']]))
            print(f"Готово для {key} за дату", start_data.strftime('%Y.%m.%d'))
            
            start_data = (start_data + timedelta(days=1))
except Exception as e:
    print(e)
    
spark.stop()