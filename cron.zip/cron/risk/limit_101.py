#! /usr/local/basement/Python-3.7.4/bin/python3.7

import datetime

from db_connectors import *

print('*********************************')
print('*          limit_101.py         *')
print('*********************************')


# execute_hive("""DROP TABLE IF EXISTS dq_sbx.zhoh_limit_101 purge """)

# execute_hive("""CREATE TABLE dq_sbx.zhoh_limit_101 
#     (   
#     BUSINESSDATE date,
#     AC_CODE string,
#     CLS_BAL_91317 float,
#     BALANCEEQUIVALENT int,
#     CLIENT_ID string,
#     ISUNCOMMITTED string
#     ) 
# """)

# Обработка строк
def params_string(s):
    if s is not None and s != 'NULL' and s != 'null' and s != 'nan':
        s = str(s).replace("[", "")
        s = str(s).replace("]", "")
        s = str(s).replace("{", "")
        s = str(s).replace("}", "")
        s = str(s).replace("Timestamp('", "")
        s = str(s).replace(" 00:00:00')", "")
        s = str(s).replace(" 00:00:00", "")
        s = str(s).replace("'", '"')
        s = "'" + s + "'"
    else:
        s = 'NULL'
    return s

params = {}
params['dates'] = []

# дата последнего отчёта
params['d'] = get_df_from_hive("""select max(businessdate) as businessdate FROM dq_sbx.zhoh_limit_101""").loc[0, 'businessdate']
# params['d'] = '2020-01-01'
df_dates = get_df_from_mart("""SELECT DISTINCT BUSINESSDATE FROM PWCCALC.EXPINFO WHERE  BUSINESSDATE > '{d}'""".format(**params))

if (len(df_dates)) < 1:
    raise SystemExit('Новых данных на витрине нет')    

i =0    
for d in df_dates.BUSINESSDATE:
    params['dates'].append(d)
    

# получаем данные с витрины IFRS9
tmp =[]

for data in params['dates']:
    params['date'] = data
    print(data)

    query = """
    SELECT DISTINCT
        BUSINESSDATE
        , CLIENTID
        , AR_ID
        , CURRENCY
        , BALANCEEQUIVALENT
    FROM PWCCALC.EXPINFO
    WHERE 1=1
        and BUSINESSDATE = '{date}'       
    """
    tmp.append(get_df_from_mart(query.format(**params)))
    
df_MART = pd.concat(tmp) 
df_MART = df_MART.reset_index(drop=True)

# Получаем счета, ar_id и суммы по аналогии со 101ф
# Нужно исключить сделки не Росбанка по коду системы источника. Нужные нам источники – БИС и АБС
query = """SELECT DISTINCT SRC_STM_ID
FROM DIM.SRC_STM
where SRC_STM_NM in ('STL','ZSL','DTL','CNL','SBL','IPS')
"""
df_SRC_STM_ID = get_df_from_mart(query)
params['SRC_STM_ID'] = str(list(df_SRC_STM_ID.SRC_STM_ID))[1:-1]

# Исключаем межбанковские лимиты (бранч равен 0000 и код клиента начинается с 2 или 3)
tmp =[]

for data in params['dates']:
    params['date'] = data   
    query = """
    SELECT DISTINCT '{date}' as BUSINESSDATE, AR_ID, S.CLS_BAL_DMST, S.CLS_BAL, AC_CODE,SUBSTR(UNQ_ID_SRC_STM,5,6) as CLIENT_ID
    ,(CASE WHEN (lah.UCDTL_LMT_CLS_F = 1) THEN '1' ELSE '0' END) as IsUncommitted
    FROM SMY.AU_SMY S
    INNER JOIN CDWH.AU A ON S.AU_ID = A.AU_ID
    LEFT JOIN DWH.CDWH.AR_X_AU ds_axa ON S.AU_ID = ds_axa.AU_ID
    LEFT JOIN CDWH.LOAN_AR_HIST lah ON lah.LOAN_AR_ID = AR_ID
        AND '{date}' BETWEEN lah.EFF_DT AND lah.END_DT
    WHERE S.MSR_PRD_ID = (
        SELECT MSR_PRD_ID
        FROM NCI.MSR_PRD
        WHERE  EFF_DT = '{date}'
        AND EFF_DT = END_DT
        )
    AND TO_DATE('{date}','YYYY-MM-DD') BETWEEN A.EFF_DT AND A.END_DT
    AND TO_DATE('{date}','YYYY-MM-DD') BETWEEN A.AU_OPN_DT AND A.AU_CLS_DT
    AND A.AU_TP_ID = 1727
    AND SUBSTR(A.AC_CODE,1,5) = '91317'
    AND (SUBSTR(A.AC_CODE,16,1) || SUBSTR(A.AC_CODE,10,4) NOT IN ('20000','30000'))
    AND A.SRC_STM_ID in ({SRC_STM_ID})
    """
    tmp.append(get_df_from_dwh(query.format(**params)))

df_DWH = pd.concat(tmp) 
df_DWH = df_DWH.reset_index(drop=True)

# Приклеем счета к витрине по ar_id и дате
tmp = pd.merge(df_DWH,
              df_MART.drop('CURRENCY',1),
              suffixes=(False, False),
              how='left',
              left_on=['BUSINESSDATE','AR_ID'],
              right_on=['BUSINESSDATE','AR_ID']
             )

# очистим данные из витрины от дублей, оставив дату счёт и лимит
tmp = tmp[['BUSINESSDATE','AC_CODE','BALANCEEQUIVALENT']].fillna(0).groupby(['AC_CODE','BUSINESSDATE'], as_index=False).max()

# очистим данные из 101
tmp2 = df_DWH[['BUSINESSDATE','AC_CODE','CLS_BAL_DMST','CLS_BAL','CLIENT_ID','ISUNCOMMITTED']].drop_duplicates()

# Соеденим витрину и 101
df_client = pd.merge(tmp2,
              tmp,
              suffixes=(False, False),
              how='left',
              left_on=['BUSINESSDATE','AC_CODE'],
              right_on=['BUSINESSDATE','AC_CODE']
             )

df_client = df_client.fillna(0)

# Счета которые должны были прийти на витрину но не пришли
df_all = df_client.query('CLS_BAL > BALANCEEQUIVALENT')[['BUSINESSDATE','AC_CODE','CLS_BAL_DMST','CLS_BAL','BALANCEEQUIVALENT','CLIENT_ID','ISUNCOMMITTED']]
df_all.rename(columns={'CLS_BAL': 'CLS_BAL_91317'}, inplace=True)
df_all = df_all.drop_duplicates()

df_all.ISUNCOMMITTED = df_all.ISUNCOMMITTED.astype(str)
df_all = df_all.groupby(['BUSINESSDATE','AC_CODE','CLS_BAL_91317','BALANCEEQUIVALENT','CLIENT_ID','ISUNCOMMITTED'], as_index = False)['ISUNCOMMITTED'].apply(','.join)

# query для дашборда
def query_params_dashboard(tmp):
    query_full = """
    INSERT INTO dq_sbx.zhoh_limit_101 VALUES 
    """  
    params = {} 
    for i,s in tmp.iterrows():
        params['BUSINESSDATE']= params_string(s[0])
        params['AC_CODE']= params_string(s[1])
        params['CLS_BAL_91317']= (s[2])  
        params['BALANCEEQUIVALENT']= (s[3])
        params['CLIENT_ID']= params_string(s[4])
        params['ISUNCOMMITTED']= params_string(s[5])
        
        query = """ (
        {BUSINESSDATE},
        {AC_CODE},
        {CLS_BAL_91317},
        {BALANCEEQUIVALENT},
        {CLIENT_ID},
        {ISUNCOMMITTED}
        )
        ,"""
        query = query.format(**params)
        query_full = query_full + query
    query_full = query_full[:-1]
    query_full = query_full.replace("'NULL'", "NULL")
    return query_full

query = query_params_dashboard(df_all)
execute_hive(query)

print('limit_101.py - готово')