import pandas as pd
import jaydebeapi
import jpype
import psycopg2
from psycopg2 import sql
import os
import subprocess
import cx_Oracle
import pymssql
from pyhive import hive
import mysql.connector 
import json



# json с логинами и паролями должен лежать в той же папке что и db_connectors.py
with open("user_pass.json", "r") as read_file:
    user_pass = json.load(read_file)
    

# *****************************************************************************************************************************************
#                                                    db2 - заменить путь к драйверу на свой 
# *****************************************************************************************************************************************

def get_df_from_mart(query):
    rows=[]
    lst=[]
    try:
        jar = '/home/rosbank.rus.socgen/rba079895/db2/db2jcc4.jar' #путь к драйверам JDBC
        login=user_pass['user_kxd']
        password=user_pass['pass_kxd']
        conn=jaydebeapi.connect('com.ibm.db2.jcc.DB2Driver','jdbc:db2://10.46.69.11:50002/MART',[login,password], jar, libs=None)
        cursor=conn.cursor()
        cursor.execute(query)
        columns = [column[0] for column in cursor.description]
        records = cursor.fetchall()
        cursor.close()
        return pd.DataFrame(data=records, columns=columns)
    except Exception as e:
        print(e)
    finally:
        if conn is not None:
            conn.close()

def get_df_from_dwh(query):
    rows=[]
    lst=[]
    try:
        jar='/home/rosbank.rus.socgen/rba079895/db2/db2jcc4.jar' #путь к драйверам JDBC
        login=user_pass['user_kxd']
        password=user_pass['pass_kxd']
        conn=jaydebeapi.connect('com.ibm.db2.jcc.DB2Driver','jdbc:db2://10.45.1.38:50000/DWH',[login,password], jar, libs=None)
        cursor=conn.cursor()
        cursor.execute(query)
        columns=[column[0] for column in cursor.description]
        records=cursor.fetchall()
        cursor.close()
        return pd.DataFrame(data=records, columns=columns)
    except Exception as e:
        print(e)
    finally:
        if conn is not None:
            conn.close()
    
def get_df_from_datahub(query):
    rows=[]
    lst=[]
    try:
        jar='/home/rosbank.rus.socgen/rba079895/db2/db2jcc4.jar' #путь к драйверам JDBC
        login=user_pass['user_kxd']
        password=user_pass['pass_kxd']
        conn=jaydebeapi.connect('com.ibm.db2.jcc.DB2Driver','jdbc:db2://10.45.1.41:50004/DATAHUB',[login,password], jar, libs=None)
        cursor=conn.cursor()
        cursor.execute(query)
        columns=[column[0] for column in cursor.description]
        records=cursor.fetchall()
        cursor.close()
        return pd.DataFrame(data=records, columns=columns)
    except Exception as e:
        print(e)
    finally:
        if conn is not None:
            conn.close()
            

# *****************************************************************************************************************************************
#                                                              mssql  
# *****************************************************************************************************************************************

def get_df_from_rdwh(query):
    # Connect to cti_omni_prod database
    conn = None
    try:
        conn =pymssql.connect(server='RSB-DBPMOSAVDBM',
                user=f"ROSBANK\\{user_pass['user_rb']}",
                password=user_pass['pass_rb'],
                database='SGG',
                port='1433')
        cursor = conn.cursor()
 
        cursor.execute(query)
        columns = [column[0] for column in cursor.description]
        records = cursor.fetchall()
        cursor.close()
        return pd.DataFrame(data=records, columns=columns)
    except Exception as e:
        print(e)
    finally:
        if conn is not None:
            conn.close()



def get_df_from_bi_rdt(query):
    # Connect to cti_omni_prod database
    conn = None
    try:
        conn =pymssql.connect(server='10.45.0.63',
                user=f"ROSBANK\\{user_pass['user_dg_bi_rdt']}",
                password=user_pass['pass_dg_bi_rdt'],
                database='ReportServer',
                port='1433')
        cursor = conn.cursor()
 
        cursor.execute(query)
        columns = [column[0] for column in cursor.description]
        records = cursor.fetchall()
        cursor.close()
        return pd.DataFrame(data=records, columns=columns)
    except Exception as e:
        print(e)
    finally:
        if conn is not None:
            conn.close()



def get_df_from_karen(query):
    conn=None
    try:
        user=user_pass['user_karen']
        password=user_pass['pass_karen']
        dbname='karendb'
        host='193.48.0.224'
        port=3306
        conn=mysql.connector.connect(database=dbname, user=user,
                                password=password, host=host, port=port)
        cursor=conn.cursor()
 
        cursor.execute(query)
        columns=[column[0] for column in cursor.description]
        records=cursor.fetchall()
        cursor.close()
        return pd.DataFrame(data=records, columns=columns)
    except Exception as e:
        print(e)
    finally:
        if conn is not None:
            conn.close()
            
            
# *****************************************************************************************************************************************
#                                                              postgres  
# *****************************************************************************************************************************************

def get_df_from_dq_profiling(query):
    conn=None
    try:
        user=user_pass['user_dq_prof']
        password=user_pass['pass_dq_prof']
        dbname='dq_profiling'
        host='193.48.6.35'
        port=5432
        conn=psycopg2.connect(dbname=dbname, user=user,
                                password=password, host=host, port=port)
        cursor=conn.cursor()
 
        cursor.execute(query)
        columns=[column[0] for column in cursor.description]
        records=cursor.fetchall()
        cursor.close()
        return pd.DataFrame(data=records, columns=columns)
    except Exception as e:
        print(e)
    finally:
        if conn is not None:
            conn.close()
            
def get_df_from_dq_profiling_ro(query):
    conn=None
    try:
        user=user_pass['user_dq_prof_ro']
        password=user_pass['pass_dq_prof_ro']
        dbname ='dq_profiling'
        host='193.48.6.35'
        port=5432
        conn=psycopg2.connect(dbname=dbname, user=user,
                                password=password, host=host, port=port)
        cursor=conn.cursor()
 
        cursor.execute(query)
        columns=[column[0] for column in cursor.description]
        records=cursor.fetchall()
        cursor.close()
        return pd.DataFrame(data=records, columns=columns)
    except Exception as e:
        print(e)
    finally:
        if conn is not None:
            conn.close()
                       
def execute_dq_profiling(query):
    conn=None
    try:
        user=user_pass['user_dq_prof']
        password=user_pass['pass_dq_prof']
        dbname='dq_profiling'
        host='193.48.6.35'
        port=5432
        conn=psycopg2.connect(dbname=dbname, user=user,
                                password=password, host=host, port=port)
        cursor=conn.cursor()
        cursor.execute(query)
        conn.commit()
    except Exception as e:
        print(e)
    finally:
        if conn is not None:
            conn.close()
                
def get_df_from_hist(query):
    conn=None
    try:
        user=user_pass['user_hist']
        password=user_pass['pass_hist']
        dbname='postgres'
        host='10.45.8.10'
        port=5432
        conn=psycopg2.connect(dbname=dbname, user=user,
                                password=password, host=host, port=port)
        cursor=conn.cursor()
 
        cursor.execute(query)
        columns=[column[0] for column in cursor.description]
        records=cursor.fetchall()
        cursor.close()
        return pd.DataFrame(data=records, columns=columns)
    except Exception as e:
        print(e)
    finally:
        if conn is not None:
            conn.close()
            
def get_df_from_greenplum(query):
    conn=None
    try:
        user=user_pass['user_gp']
        password=user_pass['pass_gp']
        dbname='rdwh'
        host='10.45.8.44'
        port=5432
        conn=psycopg2.connect(dbname=dbname, user=user,
                                password=password, host=host, port=port)
        cursor=conn.cursor()
 
        cursor.execute(query)
        columns=[column[0] for column in cursor.description]
        records=cursor.fetchall()
        cursor.close()
        return pd.DataFrame(data=records, columns=columns)
    except Exception as e:
        print(e)
    finally:
        if conn is not None:
            conn.close()   
            
def get_df_from_greenplum_rb(query):
    conn=None
    try:
        user=user_pass['user_rb']
        password=user_pass['pass_rb']
        dbname='rdwh'
        host='10.45.8.44'
        port=5432
        conn=psycopg2.connect(dbname=dbname, user=user,
                                password=password, host=host, port=port)
        cursor=conn.cursor()
 
        cursor.execute(query)
        columns=[column[0] for column in cursor.description]
        records=cursor.fetchall()
        cursor.close()
        return pd.DataFrame(data=records, columns=columns)
    except Exception as e:
        print(e)
    finally:
        if conn is not None:
            conn.close()   
            
# *****************************************************************************************************************************************
#                                                              postgres TEST и CERT  
# *****************************************************************************************************************************************    
def get_df_from_dq_profiling_TEST(query):
    conn=None
    try:
        user=user_pass['user_dq_prof']
        password=user_pass['pass_dq_prof']
        dbname='dq_profiling'
        host='193.48.100.168'
        port=5432
        conn=psycopg2.connect(dbname=dbname, user=user,
                                password=password, host=host, port=port)
        cursor=conn.cursor()
 
        cursor.execute(query)
        columns=[column[0] for column in cursor.description]
        records=cursor.fetchall()
        cursor.close()
        return pd.DataFrame(data=records, columns=columns)
    except Exception as e:
        print(e)
    finally:
        if conn is not None:
            conn.close()

def get_df_from_dq_profiling_CERT(query):
    conn=None
    try:
        user=user_pass['user_dq_prof']
        password=user_pass['pass_dq_prof']
        dbname='dq_profiling'
        host='193.48.66.181'
        port=5432
        conn=psycopg2.connect(dbname=dbname, user=user,
                                password=password, host=host, port=port)
        cursor=conn.cursor()
 
        cursor.execute(query)
        columns=[column[0] for column in cursor.description]
        records=cursor.fetchall()
        cursor.close()
        return pd.DataFrame(data=records, columns=columns)
    except Exception as e:
        print(e)
    finally:
        if conn is not None:
            conn.close()


def execute_dq_profiling_TEST(query):
    conn=None
    try:
        user=user_pass['user_dq_prof']
        password=user_pass['pass_dq_prof']
        dbname='dq_profiling'
        host='193.48.100.168'
        port=5432
        conn=psycopg2.connect(dbname=dbname, user=user,
                                password=password, host=host, port=port)
        cursor=conn.cursor()
        cursor.execute(query)
        conn.commit()
    except Exception as e:
        print(e)
    finally:
        if conn is not None:
            conn.close()


def execute_dq_profiling_CERT(query):
    conn=None
    try:
        user=user_pass['user_dq_prof']
        password=user_pass['pass_dq_prof']
        dbname='dq_profiling'
        host='193.48.66.181'
        port=5432
        conn=psycopg2.connect(dbname=dbname, user=user,
                                password=password, host=host, port=port)
        cursor=conn.cursor()
        cursor.execute(query)
        conn.commit()
    except Exception as e:
        print(e)
    finally:
        if conn is not None:
            conn.close()
            
            

# *****************************************************************************************************************************************
#                                                              hive  
# *****************************************************************************************************************************************

def get_df_from_hive(query):
    username = f"{user_pass['user_hive']}@ROSBANK.RUS.SOCGEN"
    p = subprocess.Popen(f"id {username} -u",
                         shell=True,
                         stdout=subprocess.PIPE,
                         stderr=subprocess.STDOUT)
    
    id_str1 = p.stdout.readline().decode("utf-8").replace("\n", "")
    
    p = subprocess.Popen(f"id  -u",
                         shell=True,
                         stdout=subprocess.PIPE,
                         stderr=subprocess.STDOUT)
    
    id_str2 = p.stdout.readline().decode("utf-8").replace("\n", "")
    
    os.environ ["JAVA_TOOL_OPTIONS"]="-Djava.security.krb5.conf=/etc/krb5.conf.d/krb5.conf"
    os.environ ["KRB5_CONFIG"]="/etc/krb5.conf.d/krb5.conf"
    os.environ ["KRB5CCNAME"]=f"/tmp/krb5cc_{id_str1}_{id_str2}"  
    
    PYHIVE_CONNECTIONS_PARAMS = {"host": "10.45.8.10",
                                 "port": 10000,
                                 "username": f"{user_pass['user_hive']}@ROSBANK.RUS.SOCGEN",
                                 "auth": "KERBEROS",
                                 "database": "dq_sbx",
                                 "kerberos_service_name": "hive"}
    try:
        conn=hive.Connection(**PYHIVE_CONNECTIONS_PARAMS)
        cur=conn.cursor()
        cur.execute(query)
        columns=cur.description
        result=cur.fetchall()
        return pd.DataFrame(data=result, columns=[column[0] for column in columns])
    except Exception as e:
        print(e)
    finally:
        if conn is not None:
            conn.close()
            
def execute_hive(query):
    username=f"{user_pass['user_hive']}@ROSBANK.RUS.SOCGEN"
    p=subprocess.Popen(f"id {username} -u",
                         shell=True,
                         stdout=subprocess.PIPE,
                         stderr=subprocess.STDOUT)
    
    id_str1 = p.stdout.readline().decode("utf-8").replace("\n", "")
    
    p = subprocess.Popen(f"id  -u",
                         shell=True,
                         stdout=subprocess.PIPE,
                         stderr=subprocess.STDOUT)
    
    id_str2 = p.stdout.readline().decode("utf-8").replace("\n", "")
    
    os.environ ["JAVA_TOOL_OPTIONS"]="-Djava.security.krb5.conf=/etc/krb5.conf.d/krb5.conf"
    os.environ ["KRB5_CONFIG"]="/etc/krb5.conf.d/krb5.conf"
    os.environ ["KRB5CCNAME"]=f"/tmp/krb5cc_{id_str1}_{id_str2}"  
    
    PYHIVE_CONNECTIONS_PARAMS = {"host": "10.45.8.10",
                                 "port": 10000,
                                 "username": f"{user_pass['user_hive']}@ROSBANK.RUS.SOCGEN",
                                 "auth": "KERBEROS",
                                 "database": "dq_sbx",
                                 "kerberos_service_name": "hive"}
    try:
        conn=hive.Connection(**PYHIVE_CONNECTIONS_PARAMS)
        cur=conn.cursor()
        cur.execute(query)
        conn.commit()
    except Exception as e:
        print(e)
    finally:
        if conn is not None:
            conn.close()
            

# *****************************************************************************************************************************************
#                                                              oracle  
# *****************************************************************************************************************************************

def get_df_from_siebel(query): 
    host='rsb-dbpmossmsi-scan'
    port=1525
    service_name='SBNRT_PRIMARY'
    st='{}:{}/{}'.format(host, port, service_name)
    
    conn=None
    try:
        conn=cx_Oracle.connect(user_pass['user_siebel'], user_pass['pass_siebel'], st, encoding="UTF-8")
        cursor=conn.cursor()
        cursor.execute(query)
        columns=[column[0] for column in cursor.description]
        records=cursor.fetchall()
        cursor.close()
        return pd.DataFrame(data=records, columns=columns)
    except Exception as e:
        print(e)
    finally:
        if conn is not None:
            conn.close()
            
def get_df_from_risk(query):
    host='rsb-dbpmosrhd-scan'
    port=1525
    service_name='RISKTE_PRIMARY'
    st='{}:{}/{}'.format(host, port, service_name)
    
    conn = None
    try:
        conn=connection = cx_Oracle.connect(user_pass['user_risk'], user_pass['pass_risk'], st, encoding="UTF-8")
        cursor=conn.cursor()
        cursor.execute(query)
        columns=[column[0] for column in cursor.description]
        records=cursor.fetchall()
        cursor.close()
        return pd.DataFrame(data=records, columns=columns)
    except Exception as e:
        print(e)
    finally:
        if conn is not None:
            conn.close()
           