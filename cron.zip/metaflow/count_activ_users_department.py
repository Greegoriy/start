#! /usr/local/basement/Python-3.7.4/bin/python3.7

from datetime import datetime,date,timedelta
import sqlite3 as sq
import os
import numpy as np

from db_connectors import *


print('*********************************')
print('*count_activ_users_department.py*')
print('*********************************')


def get_query_from_df(schema, table, df):
    """Сформировать запрос для insert в таблицу из df"""
    query_list = []
    df = df.fillna('NULL')
    for index, row in df.iterrows():
        row = row.apply(lambda x: x.replace("'",'`') if type(x) == str else 
                        (str(x) if type(x) == pd._libs.tslibs.timestamps.Timestamp or type(x) == date else float(x)))
        query_list.append(str(tuple(row)).replace("'NULL'", "NULL").replace("''", "NULL"))

    query_full = f'INSERT INTO {schema}.{table} VALUES' +  ', '.join(query_list)
    return query_full

#GP
df_gp = get_df_from_greenplum("""

SELECT 
    DISTINCT
    'Greenplum' as source_system,
    CURRENT_DATE as sampling_date,
    CASE 
        WHEN lower(left(user_nm, 3)) = 'rbs' THEN 'Технические' 
        WHEN lower(left(user_nm, 2)) != 'rb' AND lower(substr(user_nm, 0,7)) != 'rosbank' THEN 'Технические' 
        ELSE 'Пользователь' 
    END as rb_flag,
    lower(user_nm) as rb
FROM meta.vw_hist_users
where last_log_time >= (NOW() - INTERVAL '30 DAY') 
""")
print('GP - готово')

#hdfs
df_hdfs = get_df_from_dq_profiling_ro("""
SELECT 
    DISTINCT
    source_system,
    CURRENT_DATE as sampling_date,
    CASE 
        WHEN lower(left(ranger_user, 3)) = 'rbs' THEN 'Технические' 
        WHEN lower(left(ranger_user, 2)) != 'rb' AND lower(substr(ranger_user, 0,7)) != 'rosbank' THEN 'Технические' 
        ELSE 'Пользователь'  
    END as rb_flag,
    lower(ranger_user) as rb
FROM dq_sbx.ranger_activ_users
WHERE 1=1
    AND source_system = 'hdfs'
    AND event_date  > ((SELECT MAX(event_date) FROM dq_sbx.ranger_activ_users WHERE source_system = 'hdfs')- INTERVAL '30 DAY') 
""")
print('hdfs - готово')

#kafka
df_kafka = get_df_from_dq_profiling_ro("""
SELECT 
    DISTINCT
    source_system,
    CURRENT_DATE as sampling_date,
    CASE 
        WHEN lower(left(ranger_user, 3)) = 'rbs' THEN 'Технические' 
        WHEN lower(left(ranger_user, 2)) != 'rb' AND lower(substr(ranger_user, 0,7)) != 'rosbank' THEN 'Технические' 
        ELSE 'Пользователь'  
    END as rb_flag,
    lower(ranger_user) as rb
FROM dq_sbx.ranger_activ_users
WHERE 1=1
    AND source_system = 'kafka'
    AND event_date  > ((SELECT MAX(event_date) FROM dq_sbx.ranger_activ_users WHERE source_system = 'kafka')- INTERVAL '30 DAY') 
""")
print('kafka - готово')

#hbase
df_hbase = get_df_from_dq_profiling_ro("""
SELECT 
    DISTINCT
    source_system,
    CURRENT_DATE as sampling_date,
    CASE 
        WHEN lower(left(ranger_user, 3)) = 'rbs' THEN 'Технические' 
        WHEN lower(left(ranger_user, 2)) != 'rb' AND lower(substr(ranger_user, 0,7)) != 'rosbank' THEN 'Технические' 
        ELSE 'Пользователь'  
    END as rb_flag,
    lower(ranger_user) as rb
FROM dq_sbx.ranger_activ_users
WHERE 1=1
    AND source_system = 'hbase'
    AND event_date  > ((SELECT MAX(event_date) FROM dq_sbx.ranger_activ_users WHERE source_system = 'hbase')- INTERVAL '30 DAY') 
""")
print('hbase - готово')

#Mflow
df_mflow = get_df_from_dq_profiling_ro("""
SELECT 
    DISTINCT
    'Metaflow' as source_system,
    CURRENT_DATE as sampling_date,
    CASE 
        WHEN lower(left(login, 3)) = 'rbs' THEN 'Технические' 
        WHEN lower(left(login, 2)) != 'rb' AND lower(substr(login, 0,7)) != 'rosbank' THEN 'Технические' 
        ELSE 'Пользователь'  
    END as rb_flag,
    lower(login) as rb
FROM  dq_sbx.users_log
WHERE action_time >= (NOW() - INTERVAL '30 DAY') 
""")
print('Mflow - готово')

# Data_Lake
df_odpp = get_df_from_hive("""
SELECT 
    DISTINCT
    'Data_Lake' as source_system,
    current_date() as sampling_date ,
    CASE 
        WHEN lower(substr(requser, 0,3)) = 'rbs' THEN 'Технические' 
        WHEN lower(substr(requser, 0,2)) != 'rb' AND lower(substr(requser, 0,7)) != 'rosbank'  THEN 'Технические' 
        ELSE 'Пользователь' 
    END as rb_flag,
    lower(requser) as rb
FROM default.ranger_hive_audit_ext
where evttime >= date_add(current_date(),-30) 
""")
print('df_odpp - готово')

#JH
os.system('cp /etc/jupyterhub/jupyterhub.sqlite jupyterhub.sqlite')
con = sq.connect("jupyterhub.sqlite")
cur = con.cursor()

cur.execute("""
SELECT
    DISTINCT
    'Jupyterhub' as source_system,
    date('now') as sampling_date ,
    CASE 
        WHEN lower(substr(name, 1,3)) = 'rbs' THEN 'Технические' 
        WHEN lower(substr(name, 1,2)) != 'rb' AND lower(substr(name, 1,7)) != 'rosbank' THEN 'Технические'
        ELSE 'Пользователь' 
    END as rb_flag,
    lower(name) as rb
FROM users 
WHERE last_activity >= datetime('now', '-30 days') 
""")

columns = [column[0] for column in cur.description]
records = cur.fetchall()
df_jh = pd.DataFrame(data=records, columns=columns)
print('JH - готово')



#bi_rdt
df_bi_rdt=get_df_from_bi_rdt('''
select distinct
    'BI RDT'as source_system,
    cast(getdate() as date) sampling_date,
    CASE 
        WHEN lower(SUBSTRING(UserName,9, 3)) = 'rbs' THEN N'Технические' 
        WHEN lower(SUBSTRING(UserName,9, 2)) != 'rb' AND lower(SUBSTRING(UserName,0, 8)) != 'rosbank'
        THEN N'Технические' 
        ELSE N'Пользователь'
        END as rb_flag,
    LOWER( RIGHT(UserName, LEN(UserName) - 8) ) as rb 
from ReportServer.dbo.ExecutionLog3
where RequestType = 'Interactive' 
    AND Format = 'PBIX'
    AND cast(TimeStart as date) >= dateadd(dd,-30,cast(getdate() as date)) 
''')
print('bi_rdt - готово')

#bi
df_bi=get_df_from_hive('''
   select distinct
    'BI' as source_system,
    current_date() as sampling_date,
    CASE 
        WHEN lower(substr(UserName,9, 3)) = 'rbs' THEN 'Технические' 
        WHEN lower(substr(UserName,9, 2)) != 'rb' AND lower(substr(UserName,0, 7)) != 'rosbank'
        THEN 'Технические' 
        ELSE 'Пользователь'
        END as rb_flag,
        lower(substr(UserName,9)) as rb
from hist_rdwh_bi_etl.dbo_executionlog3
where RequestType ='Interactive' 
    AND Format = 'PBIX'
    and  TimeStart >= date_add(current_date(),-30) 
''')
print('bi - готово')

            
#sap_bo           
df_sap_bo=get_df_from_karen('''
SELECT distinct 
    'SAP BO'as source_system, 
    CURRENT_DATE() sampling_date,
    'Пользователь' as rb_flag,
    CONCAT('rb', right(CONCAT('000000',IFNULL( SI_TN,'')),6)) as rb
FROM
  bo_rp_user_cert
WHERE
  (bo_rp_user_cert.SI_LASTLOGON  >  ADDDATE(CURRENT_DATE(),-30)  AND
   bo_rp_user_cert.SI_DISABLED_ID  =  0
  AND   bo_rp_user_cert.SI_TN  NOT IN  ( ''  )
  )
  ''')
print('sap_bo - готово')

# КХД -MART
df_khd_mart=get_df_from_mart('''
   SELECT DISTINCT 
    'КХД_MART' source_system, 
    CURRENT date  as sampling_date,
    CASE 
        WHEN lower(left("USER", 3)) = 'rbs' THEN 'Технические' 
        WHEN lower(left("USER", 2)) != 'rb' AND lower(SUBSTRING("USER",0,7)) != 'rosbank' THEN 'Технические' 
        ELSE 'Пользователь'  
    END as rb_flag,
    lower("USER") as rb
FROM MON.V_ACTIVITY_DB2ACTIVITIES 
WHERE date(START_TS) >= date(CURRENT date - 30 days)
''')
df_khd_mart.rename(str.lower, axis='columns',inplace=True)
print('df_khd_mart - готово')

# КХД -CDWHT
df_khd_cdwh=get_df_from_dwh('''
   SELECT DISTINCT 
    'КХД_DWH' source_system, 
    CURRENT date  as sampling_date,
    CASE 
        WHEN lower(left("USER", 3)) = 'rbs' THEN 'Технические' 
        WHEN lower(left("USER", 2)) != 'rb' AND lower(SUBSTRING("USER",0,7)) != 'rosbank' THEN 'Технические' 
        ELSE 'Пользователь'  
    END as rb_flag,
    lower("USER") as rb
FROM MON.V_ACTIVITY_DB2ACTIVITIES 
WHERE date(START_TS) >= date(CURRENT date - 30 days)
''')
df_khd_cdwh.rename(str.lower, axis='columns',inplace=True)
print('df_khd_cdwh - готово')

df_khd_datahub=get_df_from_datahub('''
SELECT DISTINCT 
    'КХД_DATAHUB' source_system, 
    CURRENT date  as sampling_date,
    CASE 
        WHEN lower(left("USER", 3)) = 'rbs' THEN 'Технические' 
        WHEN lower(left("USER", 2)) != 'rb' AND lower(SUBSTRING("USER",0,7)) != 'rosbank' THEN 'Технические' 
        ELSE 'Пользователь'  
    END as rb_flag,
    lower("USER") as rb
FROM MON.V_ACTIVITY_DB2ACTIVITIES 
WHERE date(START_TS) >= date(CURRENT date - 30 days)
''')
df_khd_datahub.rename(str.lower, axis='columns',inplace=True)
print('df_khd_datahub - готово')

# Объединим в 1 df
df = pd.concat([df_gp, df_odpp, df_mflow, df_jh, df_hbase, df_kafka, df_hdfs, df_bi_rdt, df_bi, df_sap_bo,df_khd_mart,df_khd_cdwh,df_khd_datahub])

# приведём rb к стандартному виду
df["rb"] = df["rb"].apply(lambda x: str(x).split("@")[0].replace("rosbank", "").replace("\\","").replace("rba","rb").replace("rbla","rb").replace("rbxmos","rb"))
df.drop_duplicates(inplace=True)


# БК

# rb = '('+str(set(df.rb))[1:-1]+')'

# query = f"""
# select 
#     fio,
#     department,
#     lower(rb) as rb,
#     is_fired
# from (
# select
#     h.full_nm  as fio ,
#     CASE 
#         WHEN (string_to_array(d.department_full_nm, ' -> '))[4] IS NOT NULL THEN (string_to_array(d.department_full_nm, ' -> '))[4] 
#         ELSE (string_to_array(d.department_full_nm, ' -> '))[array_upper((string_to_array(d.department_full_nm, ' -> ')), 1)] 
#         END as department,
#     COALESCE(rb.value_text, 'rb' || "right"('000000' || h.employee_code, 6)) AS rb,
#     CASE
#         WHEN h.dt_to <= now() THEN 1
#         ELSE 0
#     END AS is_fired
# FROM dds.employee h
#     LEFT JOIN dds.employee_property rb
#         ON h.id_employee = rb.id_employee 
#         AND now() >= rb.dt_from 
#         AND now() <= rb.dt_to 
#         AND rb.id_property = 53
# LEFT JOIN dict.department d 
#     ON h.id_department = d.id_department
# where 1=1
#     and ( rb.value_text in {rb}
#     or ('rb' || "right"('000000' || h.employee_code, 6)) in {rb} )
# ) as t
# """
# df_bk = get_df_from_greenplum_rb(query)

# Новый БК
query = """ SELECT department, job_desc, fio, rb FROM dq_sbx.rb_list """
df_bk = get_df_from_dq_profiling_ro(query)
df_bk['is_fired'] = 0 

# соеденим БК и основной df
df_full = df.merge(df_bk, how='left', on='rb')
df_full = df_full[['source_system','sampling_date','rb_flag','rb','department','is_fired','fio']]

# Для не технических rb для которых не нашлось записи в БК поставим флаг уволенные
df_full.loc[(df_full.is_fired != 0)&(df_full.rb_flag != 'Технические'), 'is_fired'] = 1

# Запишем данные в базу
execute_dq_profiling(get_query_from_df("dq_sbx","count_activ_users_department",df_full))
print('count_activ_users_department - готово')