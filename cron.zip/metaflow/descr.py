#! /usr/local/basement/Python-3.7.4/bin/python3.7

import time
import numpy as np
from datetime import date

from db_connectors import *

"""Формирует таблицы для поиска тулом Mflow"""
print('*********************************')
print('*         descr.py              *')
print('*********************************')

# Перепишем dq_sbx.descr из вьюхи dq_sbx.full_description
query = """ truncate dq_sbx.descr;
insert into dq_sbx.descr 
SELECT 
    id_table, 
    src_name, 
    src_schema, 
    src_table, 
    tab_comment, 
    col_name, 
    col_type, 
    col_comment, 
    personal_data_group, 
    attribute_quality, 
    contact_person, 
    domain_data_owner, 
    col_comment_meta, 
    col_comment_glossary, 
    flag_algorithm, 
    schema_name, 
    table_name, 
    it_code, 
    table_code, 
    is_in_archive, 
    count_columns, 
    col_position, 
    user_comments, 
    entity_name, 
    null as entity_flag,
    object_type,
    editable,
    team, 
    developer_rb, 
    developer_fio, 
    analyst_rb, 
    analyst_fio, 
    link_confluence
FROM dq_sbx.full_description
ORDER BY table_code,col_position,col_name;"""
execute_dq_profiling(query)
print('descr')

# Разделим  descr на descr_tab и  descr_col
query = """
truncate dq_sbx.descr_tab;
insert into dq_sbx.descr_tab 

SELECT  
    it_code,
    id_table,
    src_name,
    src_schema,
    src_table,
    max(tab_comment) as tab_comment,
    schema_name,
    table_name,
    is_in_archive,
    table_code,
    object_type,
    editable,
    team, 
    developer_rb, 
    developer_fio, 
    analyst_rb, 
    analyst_fio, 
    link_confluence
FROM dq_sbx.descr
GROUP BY it_code,
    id_table,
    src_name,
    src_schema,
    src_table,
    schema_name,
    table_name,
    is_in_archive,
    table_code,
    object_type,
    editable,
    team, 
    developer_rb, 
    developer_fio, 
    analyst_rb, 
    analyst_fio, 
    link_confluence
;
"""
execute_dq_profiling(query)
print('descr_tab')

query = """
truncate dq_sbx.descr_col;
insert into dq_sbx.descr_col 

SELECT DISTINCT 
    table_code,
    col_name,
    col_type,
    col_comment,
    flag_algorithm,
    personal_data_group,
    attribute_quality,
    contact_person,
    domain_data_owner,
    min(col_position) as col_position,
    user_comments,
    entity_name
FROM dq_sbx.descr
GROUP BY table_code, col_name, col_type, col_comment, flag_algorithm, personal_data_group, attribute_quality, contact_person, domain_data_owner, user_comments, entity_name
ORDER BY table_code,min(col_position),col_name;

"""
execute_dq_profiling(query)
print('descr_col')

print()
print('descr.py - готово')