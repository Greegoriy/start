-- dq_sbx.full_description source

CREATE OR REPLACE VIEW dq_sbx.full_description
AS WITH info_columns AS (
         SELECT DISTINCT i.id_table,
            lower(i.schema_name::text) AS schema_name,
            lower(i.table_name::text) AS table_name,
            lower(i.it_system_code::text) AS it_code,
            i.is_in_archive,
            i.count_columns,
            lower(i.src_name::text) AS src_name_info,
            lower(i.src_schema::text) AS src_schema,
            lower(i.src_table::text) AS src_table,
            lower(c.col_name::text) AS col_name,
                CASE
                    WHEN lower(c.col_type::text) ~ similar_escape('%[a-z]%'::text, NULL::text) THEN lower(c.col_type::text)
                    ELSE NULL::text
                END AS col_type_info,
            c.col_position AS col_position_info
           FROM dq_sbx.info i
             LEFT JOIN dq_sbx.columns c ON 1 = 1 AND i.id_table = c.id_table
        ), description_table_max AS (
         SELECT t_1.src_schema,
            t_1.src_table,
            t_1.sampling_date,
            t_1.it_code,
            max(lower(tt.tab_comment::text)) AS tab_comment
           FROM ( SELECT lower(description_table.src_schema::text) AS src_schema,
                    lower(description_table.src_table::text) AS src_table,
                    lower(description_table.it_code::text) AS it_code,
                    max(description_table.sampling_date) AS sampling_date
                   FROM dq_sbx.description_table
                  GROUP BY (lower(description_table.src_schema::text)), (lower(description_table.src_table::text)), (lower(description_table.it_code::text))) t_1
             LEFT JOIN dq_sbx.description_table tt ON 1 = 1 AND (lower(t_1.src_schema) = lower(tt.src_schema::text) OR t_1.src_schema IS NULL AND tt.src_schema IS NULL) AND t_1.src_table = lower(tt.src_table::text) AND (lower(t_1.it_code) = lower(tt.it_code::text) OR t_1.it_code IS NULL AND tt.it_code IS NULL) AND t_1.sampling_date = tt.sampling_date
          GROUP BY t_1.src_schema, t_1.src_table, t_1.sampling_date, t_1.it_code
        ), description_col_max AS (
         SELECT t_1.src_schema,
            t_1.src_table,
            t_1.col_name,
            t_1.sampling_date,
            t_1.it_code,
            max(lower(tt.col_comment::text)) AS col_comment
           FROM ( SELECT lower(description_col.src_schema::text) AS src_schema,
                    lower(description_col.src_table::text) AS src_table,
                    lower(description_col.col_name::text) AS col_name,
                    lower(description_col.it_code::text) AS it_code,
                    max(description_col.sampling_date) AS sampling_date
                   FROM dq_sbx.description_col
                  GROUP BY (lower(description_col.src_schema::text)), (lower(description_col.src_table::text)), (lower(description_col.col_name::text)), (lower(description_col.it_code::text))) t_1
             LEFT JOIN dq_sbx.description_col tt ON 1 = 1 AND (lower(t_1.src_schema) = lower(tt.src_schema::text) OR t_1.src_schema IS NULL AND tt.src_schema IS NULL) AND t_1.src_table = lower(tt.src_table::text) AND t_1.col_name = lower(tt.col_name::text) AND (lower(t_1.it_code) = lower(tt.it_code::text) OR t_1.it_code IS NULL AND tt.it_code IS NULL) AND t_1.sampling_date = tt.sampling_date
          GROUP BY t_1.src_schema, t_1.src_table, t_1.col_name, t_1.sampling_date, t_1.it_code
        ), col_type_max AS (
         SELECT t_1.src_schema,
            t_1.src_table,
            t_1.col_name,
            t_1.sampling_date,
            t_1.it_code,
            max(lower(tt.col_type::text)) AS col_type
           FROM ( SELECT lower(col_type.src_schema::text) AS src_schema,
                    lower(col_type.src_table::text) AS src_table,
                    lower(col_type.col_name::text) AS col_name,
                    lower(col_type.it_code::text) AS it_code,
                    max(col_type.sampling_date) AS sampling_date
                   FROM dq_sbx.col_type
                  GROUP BY (lower(col_type.src_schema::text)), (lower(col_type.src_table::text)), (lower(col_type.col_name::text)), (lower(col_type.it_code::text))) t_1
             LEFT JOIN dq_sbx.col_type tt ON 1 = 1 AND (lower(t_1.src_schema) = lower(tt.src_schema::text) OR t_1.src_schema IS NULL AND tt.src_schema IS NULL) AND t_1.src_table = lower(tt.src_table::text) AND t_1.col_name = lower(tt.col_name::text) AND (lower(t_1.it_code) = lower(tt.it_code::text) OR t_1.it_code IS NULL AND tt.it_code IS NULL) AND t_1.sampling_date = tt.sampling_date
          GROUP BY t_1.src_schema, t_1.src_table, t_1.col_name, t_1.sampling_date, t_1.it_code
        ), owner_max AS (
         SELECT t_1.src_schema,
            t_1.src_table,
            t_1.col_name,
            t_1.sampling_date,
            t_1.it_code,
            max(lower(tt.contact_person::text)) AS contact_person,
            max(lower(tt.domain_data_owner::text)) AS domain_data_owner
           FROM ( SELECT lower(data_owner.src_schema::text) AS src_schema,
                    lower(data_owner.src_table::text) AS src_table,
                    lower(data_owner.col_name::text) AS col_name,
                    lower(data_owner.it_code::text) AS it_code,
                    max(data_owner.sampling_date) AS sampling_date
                   FROM dq_sbx.data_owner
                  WHERE data_owner.flag_confirm = true
                  GROUP BY (lower(data_owner.src_schema::text)), (lower(data_owner.src_table::text)), (lower(data_owner.col_name::text)), (lower(data_owner.it_code::text))) t_1
             LEFT JOIN dq_sbx.data_owner tt ON 1 = 1 AND (lower(t_1.src_schema) = lower(tt.src_schema::text) OR t_1.src_schema IS NULL AND tt.src_schema IS NULL) AND t_1.src_table = lower(tt.src_table::text) AND t_1.col_name = lower(tt.col_name::text) AND (lower(t_1.it_code) = lower(tt.it_code::text) OR t_1.it_code IS NULL AND tt.it_code IS NULL) AND t_1.sampling_date = tt.sampling_date
          GROUP BY t_1.src_schema, t_1.src_table, t_1.col_name, t_1.sampling_date, t_1.it_code
        ), quality_max AS (
         SELECT t_1.src_schema,
            t_1.src_table,
            t_1.col_name,
            t_1.sampling_date,
            t_1.it_code,
            max(lower(tt.attribute_quality::text)) AS attribute_quality
           FROM ( SELECT lower(quality.src_schema::text) AS src_schema,
                    lower(quality.src_table::text) AS src_table,
                    lower(quality.col_name::text) AS col_name,
                    lower(quality.it_code::text) AS it_code,
                    max(quality.sampling_date) AS sampling_date
                   FROM dq_sbx.quality
                  GROUP BY (lower(quality.src_schema::text)), (lower(quality.src_table::text)), (lower(quality.col_name::text)), (lower(quality.it_code::text))) t_1
             LEFT JOIN dq_sbx.quality tt ON 1 = 1 AND (lower(t_1.src_schema) = lower(tt.src_schema::text) OR t_1.src_schema IS NULL AND tt.src_schema IS NULL) AND t_1.src_table = lower(tt.src_table::text) AND t_1.col_name = lower(tt.col_name::text) AND (lower(t_1.it_code) = lower(tt.it_code::text) OR t_1.it_code IS NULL AND tt.it_code IS NULL) AND t_1.sampling_date = tt.sampling_date
          GROUP BY t_1.src_schema, t_1.src_table, t_1.col_name, t_1.sampling_date, t_1.it_code
        ), group_max AS (
         SELECT t_1.src_schema,
            t_1.src_table,
            t_1.col_name,
            t_1.sampling_date,
            t_1.it_code,
            max(lower(tt.personal_data_group::text)) AS personal_data_group
           FROM ( SELECT lower(data_group.src_schema::text) AS src_schema,
                    lower(data_group.src_table::text) AS src_table,
                    lower(data_group.col_name::text) AS col_name,
                    lower(data_group.it_code::text) AS it_code,
                    max(data_group.sampling_date) AS sampling_date
                   FROM dq_sbx.data_group
                  GROUP BY (lower(data_group.src_schema::text)), (lower(data_group.src_table::text)), (lower(data_group.col_name::text)), (lower(data_group.it_code::text))) t_1
             LEFT JOIN dq_sbx.data_group tt ON 1 = 1 AND (lower(t_1.src_schema) = lower(tt.src_schema::text) OR t_1.src_schema IS NULL AND tt.src_schema IS NULL) AND t_1.src_table = lower(tt.src_table::text) AND t_1.col_name = lower(tt.col_name::text) AND (lower(t_1.it_code) = lower(tt.it_code::text) OR t_1.it_code IS NULL AND tt.it_code IS NULL) AND t_1.sampling_date = tt.sampling_date
          GROUP BY t_1.src_schema, t_1.src_table, t_1.col_name, t_1.sampling_date, t_1.it_code
        ), entity_max AS (
         SELECT t_1.src_schema,
            t_1.src_table,
            t_1.col_name,
            t_1.sampling_date,
            t_1.it_code,
            max(lower(tt.entity_name::text)) AS entity_name
           FROM ( SELECT lower(entity.src_schema::text) AS src_schema,
                    lower(entity.src_table::text) AS src_table,
                    lower(entity.col_name::text) AS col_name,
                    lower(entity.it_code::text) AS it_code,
                    max(entity.sampling_date) AS sampling_date
                   FROM dq_sbx.entity
                  GROUP BY (lower(entity.src_schema::text)), (lower(entity.src_table::text)), (lower(entity.col_name::text)), (lower(entity.it_code::text))) t_1
             LEFT JOIN dq_sbx.entity tt ON 1 = 1 AND (lower(t_1.src_schema) = lower(tt.src_schema::text) OR t_1.src_schema IS NULL AND tt.src_schema IS NULL) AND t_1.src_table = lower(tt.src_table::text) AND t_1.col_name = lower(tt.col_name::text) AND (lower(t_1.it_code) = lower(tt.it_code::text) OR t_1.it_code IS NULL AND tt.it_code IS NULL) AND t_1.sampling_date = tt.sampling_date
          GROUP BY t_1.src_schema, t_1.src_table, t_1.col_name, t_1.sampling_date, t_1.it_code
        ), comments_max AS (
         SELECT t_1.src_schema,
            t_1.src_table,
            t_1.col_name,
            t_1.sampling_date,
            t_1.it_code,
            max(lower(tt.comments::text)) AS user_comments
           FROM ( SELECT lower(user_comments.src_schema::text) AS src_schema,
                    lower(user_comments.src_table::text) AS src_table,
                    lower(user_comments.col_name::text) AS col_name,
                    lower(user_comments.it_code::text) AS it_code,
                    max(user_comments.sampling_date) AS sampling_date
                   FROM dq_sbx.user_comments
                  GROUP BY (lower(user_comments.src_schema::text)), (lower(user_comments.src_table::text)), (lower(user_comments.col_name::text)), (lower(user_comments.it_code::text))) t_1
             LEFT JOIN dq_sbx.user_comments tt ON 1 = 1 AND (lower(t_1.src_schema) = lower(tt.src_schema::text) OR t_1.src_schema IS NULL AND tt.src_schema IS NULL) AND t_1.src_table = lower(tt.src_table::text) AND t_1.col_name = lower(tt.col_name::text) AND (lower(t_1.it_code) = lower(tt.it_code::text) OR t_1.it_code IS NULL AND tt.it_code IS NULL) AND t_1.sampling_date = tt.sampling_date
          GROUP BY t_1.src_schema, t_1.src_table, t_1.col_name, t_1.sampling_date, t_1.it_code
        ), glossary_col_ AS (
         WITH full_ AS (
                 SELECT description_col_max.src_schema,
                    description_col_max.src_table,
                    description_col_max.col_name,
                    description_col_max.it_code
                   FROM description_col_max
                UNION
                 SELECT col_type_max.src_schema,
                    col_type_max.src_table,
                    col_type_max.col_name,
                    col_type_max.it_code
                   FROM col_type_max
                UNION
                 SELECT owner_max.src_schema,
                    owner_max.src_table,
                    owner_max.col_name,
                    owner_max.it_code
                   FROM owner_max
                UNION
                 SELECT quality_max.src_schema,
                    quality_max.src_table,
                    quality_max.col_name,
                    quality_max.it_code
                   FROM quality_max
                UNION
                 SELECT group_max.src_schema,
                    group_max.src_table,
                    group_max.col_name,
                    group_max.it_code
                   FROM group_max
                UNION
                 SELECT comments_max.src_schema,
                    comments_max.src_table,
                    comments_max.col_name,
                    comments_max.it_code
                   FROM comments_max
                UNION
                 SELECT entity_max.src_schema,
                    entity_max.src_table,
                    entity_max.col_name,
                    entity_max.it_code
                   FROM entity_max
                )
         SELECT DISTINCT t.src_schema,
            t.src_table,
            t.col_name,
            t.it_code,
            t7.col_type AS col_type_glossary,
            t1.col_comment AS col_comment_glossary,
            t4.personal_data_group,
            t3.attribute_quality,
            t2.contact_person,
            t2.domain_data_owner,
            t5.user_comments,
            t6.entity_name,
            row_number() OVER (PARTITION BY t.src_schema, t.src_table ORDER BY t.src_schema, t.src_table) AS col_position_glossary
           FROM full_ t
             LEFT JOIN description_col_max t1 ON 1 = 1 AND (t.src_schema = t1.src_schema OR t.src_schema IS NULL AND t1.src_schema IS NULL) AND t.src_table = t1.src_table AND t.col_name = t1.col_name AND (lower(t.it_code) = lower(t1.it_code) OR t.it_code IS NULL AND t1.it_code IS NULL)
             LEFT JOIN owner_max t2 ON 1 = 1 AND (t.src_schema = t2.src_schema OR t.src_schema IS NULL AND t2.src_schema IS NULL) AND t.src_table = t2.src_table AND t.col_name = t2.col_name AND (lower(t.it_code) = lower(t2.it_code) OR t.it_code IS NULL AND t2.it_code IS NULL)
             LEFT JOIN quality_max t3 ON 1 = 1 AND (t.src_schema = t3.src_schema OR t.src_schema IS NULL AND t3.src_schema IS NULL) AND t.src_table = t3.src_table AND t.col_name = t3.col_name AND (lower(t.it_code) = lower(t3.it_code) OR t.it_code IS NULL AND t3.it_code IS NULL)
             LEFT JOIN group_max t4 ON 1 = 1 AND (t.src_schema = t4.src_schema OR t.src_schema IS NULL AND t4.src_schema IS NULL) AND t.src_table = t4.src_table AND t.col_name = t4.col_name AND (lower(t.it_code) = lower(t4.it_code) OR t.it_code IS NULL AND t4.it_code IS NULL)
             LEFT JOIN comments_max t5 ON 1 = 1 AND (t.src_schema = t5.src_schema OR t.src_schema IS NULL AND t5.src_schema IS NULL) AND t.src_table = t5.src_table AND t.col_name = t5.col_name AND (lower(t.it_code) = lower(t5.it_code) OR t.it_code IS NULL AND t5.it_code IS NULL)
             LEFT JOIN entity_max t6 ON 1 = 1 AND (t.src_schema = t6.src_schema OR t.src_schema IS NULL AND t6.src_schema IS NULL) AND t.src_table = t6.src_table AND t.col_name = t6.col_name AND (lower(t.it_code) = lower(t6.it_code) OR t.it_code IS NULL AND t6.it_code IS NULL)
             LEFT JOIN col_type_max t7 ON 1 = 1 AND (t.src_schema = t7.src_schema OR t.src_schema IS NULL AND t7.src_schema IS NULL) AND t.src_table = t7.src_table AND t.col_name = t7.col_name AND (lower(t.it_code) = lower(t7.it_code) OR t.it_code IS NULL AND t7.it_code IS NULL)
        ), info_meta AS (
         SELECT i.id_table,
            i.schema_name,
            i.table_name,
            i.count_columns,
            i.it_code,
            i.is_in_archive,
            i.src_name_info AS src_name,
            i.src_schema,
            i.src_table,
            i.col_name,
            i.col_type_info AS col_type,
            m.tab_comment_meta,
            m.col_comment_meta,
            'info'::character varying AS meta,
            i.col_position_info AS col_position
           FROM info_columns i
             LEFT JOIN ( SELECT meta.it_code_meta,
                    meta.src_schema,
                    meta.src_table,
                    meta.col_name,
                    max(meta.tab_comment_meta::text) AS tab_comment_meta,
                    max(meta.col_comment_meta::text) AS col_comment_meta
                   FROM dq_sbx.meta
                  GROUP BY meta.it_code_meta, meta.src_schema, meta.src_table, meta.col_name) m ON m.src_schema::text = i.src_schema AND m.src_table::text = i.src_table AND m.col_name::text = i.col_name AND m.it_code_meta::text = i.it_code
        UNION
         SELECT NULL::integer AS id_table,
            NULL::text AS schema_name,
            NULL::text AS table_name,
            NULL::integer AS count_columns,
            meta.it_code_meta AS it_code,
            NULL::character varying AS is_in_archive,
            meta.src_name_meta AS src_name,
            meta.src_schema,
            meta.src_table,
            meta.col_name,
            meta.col_type_meta AS col_type,
            meta.tab_comment_meta,
            meta.col_comment_meta,
            meta.meta,
            meta.col_position
           FROM dq_sbx.meta
        ), hist_clean AS (
         SELECT hb.src_schema,
            hb.src_table,
            hb.tab_comment_meta,
            hb.col_name,
            hb.col_type_meta,
            hb.col_comment_meta,
            hb.it_code_meta,
            hb.src_name_meta,
            hb.meta,
            hb.col_position
           FROM dq_sbx.hist_backup hb
             LEFT JOIN ( SELECT DISTINCT h.it_code_meta,
                    h.src_schema,
                    h.src_table,
                    h.col_name
                   FROM dq_sbx.hist_backup h
                     LEFT JOIN description_col_max d ON d.it_code = h.it_code_meta::text AND d.src_schema = h.src_schema::text AND d.src_table = h.src_table::text AND d.col_name = h.col_name::text
                     LEFT JOIN dq_sbx.meta m ON m.it_code_meta::text = h.it_code_meta::text AND m.src_schema::text = h.src_schema::text AND m.src_table::text = h.src_table::text AND m.col_name::text = h.col_name::text
                  WHERE 1 = 1 AND h.col_comment_meta IS NOT NULL AND (d.col_comment IS NOT NULL OR m.col_comment_meta IS NOT NULL)) t ON t.it_code_meta::text = hb.it_code_meta::text AND t.src_schema::text = hb.src_schema::text AND t.src_table::text = hb.src_table::text AND t.col_name::text = hb.col_name::text
          WHERE t.col_name IS NULL AND hb.col_comment_meta IS NOT NULL
        ), info_meta_hist AS (
         SELECT im.id_table,
            im.schema_name,
            im.table_name,
            im.count_columns,
            im.it_code,
            im.is_in_archive,
            im.src_name,
            im.src_schema,
            im.src_table,
            im.col_name,
            im.col_type,
                CASE
                    WHEN im.tab_comment_meta IS NOT NULL THEN im.tab_comment_meta::character varying
                    ELSE hc.tab_comment_meta
                END AS tab_comment_meta,
                CASE
                    WHEN im.col_comment_meta IS NOT NULL THEN im.col_comment_meta::character varying
                    ELSE hc.col_comment_meta
                END AS col_comment_meta,
            im.meta,
            min(im.col_position) AS col_position
           FROM info_meta im
             LEFT JOIN hist_clean hc ON im.it_code = hc.it_code_meta::text AND im.src_schema = hc.src_schema::text AND im.src_table = hc.src_table::text AND im.col_name = hc.col_name::text
          GROUP BY im.id_table, im.schema_name, im.table_name, im.count_columns, im.it_code, im.is_in_archive, im.src_name, im.src_schema, im.src_table, im.col_name, im.col_type, im.meta, (
                CASE
                    WHEN im.tab_comment_meta IS NOT NULL THEN im.tab_comment_meta::character varying
                    ELSE hc.tab_comment_meta
                END), (
                CASE
                    WHEN im.col_comment_meta IS NOT NULL THEN im.col_comment_meta::character varying
                    ELSE hc.col_comment_meta
                END)
        ), descr_full AS (
         SELECT imh.id_table,
            imh.schema_name,
            imh.table_name,
            imh.count_columns,
            imh.it_code,
            imh.is_in_archive,
            imh.src_name,
            imh.src_schema,
            imh.src_table,
            imh.col_name,
            imh.col_type,
                CASE
                    WHEN dt.tab_comment IS NOT NULL THEN dt.tab_comment::character varying
                    ELSE imh.tab_comment_meta
                END AS tab_comment,
                CASE
                    WHEN gc.col_comment_glossary IS NOT NULL THEN gc.col_comment_glossary::character varying
                    ELSE imh.col_comment_meta
                END AS col_comment,
            imh.tab_comment_meta,
            imh.col_comment_meta,
            dt.tab_comment AS tab_comment_glossary,
            gc.col_comment_glossary,
            gc.personal_data_group,
            gc.attribute_quality,
            gc.contact_person,
            gc.domain_data_owner,
            gc.user_comments,
            gc.entity_name,
            imh.meta,
            imh.col_position
           FROM info_meta_hist imh
             LEFT JOIN glossary_col_ gc ON imh.it_code = gc.it_code AND imh.src_schema = gc.src_schema AND imh.src_table = gc.src_table AND imh.col_name = gc.col_name
             LEFT JOIN description_table_max dt ON imh.it_code = dt.it_code AND imh.src_schema = dt.src_schema AND imh.src_table = dt.src_table
        ), auto_comment_ AS (
         WITH glossary_count AS (
                 SELECT glossary_col_.col_name,
                    glossary_col_.col_comment_glossary AS col_comment,
                    count(glossary_col_.col_comment_glossary) AS count_col
                   FROM glossary_col_
                  WHERE 1 = 1 AND glossary_col_.col_comment_glossary IS NOT NULL AND (glossary_col_.col_comment_glossary <> ALL (ARRAY['*удалено*'::text, '(пока не используется)'::text, 'не исп.'::text, 'не используется'::text, 'нет информации'::text, 'не используется, удалить при случае'::text, 'не используется с версии 2.2'::text, ''::text]))
                  GROUP BY glossary_col_.col_name, glossary_col_.col_comment_glossary
                ), glossary_auto AS (
                 SELECT t1.col_name AS new_col_name,
                    max(t2.col_comment) AS new_col_comment
                   FROM ( SELECT glossary_count.col_name,
                            max(glossary_count.count_col) AS max_count_col
                           FROM glossary_count
                          GROUP BY glossary_count.col_name) t1
                     LEFT JOIN glossary_count t2 ON t1.col_name = t2.col_name AND t1.max_count_col = t2.count_col
                  GROUP BY t1.col_name
                ), meta_full AS (
                 SELECT meta.col_name,
                    meta.col_comment_meta AS col_comment
                   FROM dq_sbx.meta
                  WHERE 1 = 1 AND meta.col_comment_meta IS NOT NULL AND (meta.col_comment_meta::text <> ALL (ARRAY['*удалено*'::character varying::text, '(пока не используется)'::character varying::text, 'не исп.'::character varying::text, 'не используется'::character varying::text, 'нет информации'::character varying::text, 'не используется, удалить при случае'::character varying::text, 'не используется с версии 2.2'::character varying::text, ''::character varying::text]))
                UNION ALL
                 SELECT hist_clean.col_name,
                    hist_clean.col_comment_meta AS col_comment
                   FROM hist_clean
                  WHERE 1 = 1 AND hist_clean.col_comment_meta IS NOT NULL AND (hist_clean.col_comment_meta::text <> ALL (ARRAY['*удалено*'::character varying::text, '(пока не используется)'::character varying::text, 'не исп.'::character varying::text, 'не используется'::character varying::text, 'нет информации'::character varying::text, 'не используется, удалить при случае'::character varying::text, 'не используется с версии 2.2'::character varying::text, ''::character varying::text]))
                ), meta_count AS (
                 SELECT meta_full.col_name,
                    meta_full.col_comment,
                    count(meta_full.col_comment) AS count_col
                   FROM meta_full
                  GROUP BY meta_full.col_name, meta_full.col_comment
                ), meta_auto AS (
                 SELECT t1.col_name AS new_col_name,
                    max(t2.col_comment::text) AS new_col_comment
                   FROM ( SELECT meta_count.col_name,
                            max(meta_count.count_col) AS max_count_col
                           FROM meta_count
                          GROUP BY meta_count.col_name) t1
                     LEFT JOIN meta_count t2 ON t1.col_name::text = t2.col_name::text AND t1.max_count_col = t2.count_col
                  GROUP BY t1.col_name
                )
         SELECT
                CASE
                    WHEN ga.new_col_name IS NOT NULL THEN ga.new_col_name::character varying
                    ELSE ma.new_col_name
                END AS new_col_name,
                CASE
                    WHEN ga.new_col_comment IS NOT NULL THEN ga.new_col_comment
                    ELSE ma.new_col_comment
                END AS new_col_comment
           FROM glossary_auto ga
             FULL JOIN meta_auto ma ON ga.new_col_name = ma.new_col_name::text
        ), table_auto_comment AS (
         SELECT df.id_table,
            df.schema_name,
            df.table_name,
            df.count_columns,
            df.it_code,
            df.is_in_archive,
            df.src_name,
            df.src_schema,
            df.src_table,
            df.col_name,
            df.col_type,
            df.tab_comment,
                CASE
                    WHEN df.col_comment IS NOT NULL THEN df.col_comment::text
                    ELSE ac.new_col_comment
                END AS col_comment,
            df.tab_comment_meta,
            df.col_comment_meta,
            df.tab_comment_glossary,
            df.col_comment_glossary,
            df.personal_data_group,
            df.attribute_quality,
            df.contact_person,
            df.domain_data_owner,
            df.user_comments,
            df.entity_name,
            df.meta,
            df.col_position,
                CASE
                    WHEN df.col_comment::text = df.col_comment_glossary THEN 'glossary'::text
                    WHEN df.col_comment::text = df.col_comment_meta::text THEN 'meta'::text
                    WHEN ac.new_col_comment IS NOT NULL THEN 'auto'::text
                    ELSE NULL::text
                END AS flag_algorithm,
            (((((df.it_code || '_'::text) || replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(df.src_name, ' (cdc)'::text, ''::text), 'stl'::text, '_'::text), 'zsl'::text, '_'::text), 'dtl'::text, '_'::text), 'cnl'::text, '_'::text), 'sbl'::text, '_'::text), 'ips'::text, '_'::text), 'luni'::text, '_'::text), '__'::text, '_'::text), 'etl (bisc)'::text, '_'::text)) || '_'::text) || replace(replace(replace(replace(replace(replace(replace(replace(df.src_schema, 'stl'::text, '_'::text), 'zsl'::text, '_'::text), 'dtl'::text, '_'::text), 'cnl'::text, '_'::text), 'sbl'::text, '_'::text), 'ips'::text, '_'::text), 'luni'::text, '_'::text), '__'::text, '_'::text)) || '_'::text) || replace(replace(replace(replace(replace(replace(replace(replace(df.src_table, 'stl'::text, '_'::text), 'zsl'::text, '_'::text), 'dtl'::text, '_'::text), 'cnl'::text, '_'::text), 'sbl'::text, '_'::text), 'ips'::text, '_'::text), 'luni'::text, '_'::text), '__'::text, '_'::text) AS table_code
           FROM descr_full df
             LEFT JOIN auto_comment_ ac ON df.col_name = ac.new_col_name::text
          WHERE 1 = 1 AND df.it_code IS NOT NULL AND df.src_schema IS NOT NULL AND df.it_code <> ''::text AND df.src_schema <> ''::text
        ), table_function AS (
         SELECT t.id_table,
            t.schema_name,
            t.table_name,
            t.count_columns,
            t.it_code,
            t.is_in_archive,
            t.src_name,
            t.src_schema,
            t.src_table,
            t.col_name,
            t.col_type,
            t.tab_comment,
            t.col_comment,
            t.tab_comment_meta,
            t.col_comment_meta,
            t.tab_comment_glossary,
            t.col_comment_glossary,
            t.personal_data_group,
            t.attribute_quality,
            t.contact_person,
            t.domain_data_owner,
            t.user_comments,
            t.entity_name,
            t.meta,
            t.col_position,
            t.flag_algorithm,
            t.table_code,
            'table/view'::text AS object_type,
                CASE
                    WHEN t.it_code = 'ci466068'::text AND t.table_name IS NULL THEN 'editable'::text
                    ELSE NULL::text
                END AS editable
           FROM table_auto_comment t
        UNION
         SELECT NULL::integer AS id_table,
            NULL::text AS schema_name,
            NULL::text AS table_name,
            NULL::integer AS count_columns,
            'ci466068'::text AS it_code,
            NULL::character varying AS is_in_archive,
            'greenplum'::text AS src_name,
            function_gp.function_schema AS src_schema,
            function_gp.function_name AS src_table,
            NULL::text AS col_name,
            NULL::text AS col_type,
            NULL::character varying AS tab_comment,
            NULL::text AS col_comment,
            NULL::character varying AS tab_comment_meta,
            NULL::character varying AS col_comment_meta,
            NULL::text AS tab_comment_glossary,
            NULL::text AS col_comment_glossary,
            NULL::text AS personal_data_group,
            NULL::text AS attribute_quality,
            NULL::text AS contact_person,
            NULL::text AS domain_data_owner,
            NULL::text AS user_comments,
            NULL::text AS entity_name,
            NULL::character varying AS meta,
            NULL::integer AS col_position,
            NULL::text AS flag_algorithm,
            ((((('ci466068'::text || '_'::text) || 'greenplum'::text) || '_'::text) || function_gp.function_schema::text) || '_'::text) || function_gp.function_name::text AS table_code,
            'function'::text AS object_type,
            'editable'::text AS editable
           FROM dq_sbx.function_gp
        )
 SELECT tf.id_table,
    tf.schema_name,
    tf.table_name,
    tf.count_columns,
    tf.it_code,
    tf.is_in_archive,
    tf.src_name,
    tf.src_schema,
    tf.src_table,
    tf.col_name,
    tf.col_type,
    tf.tab_comment,
    tf.col_comment,
    tf.tab_comment_meta,
    tf.col_comment_meta,
    tf.tab_comment_glossary,
    tf.col_comment_glossary,
    tf.personal_data_group,
    tf.attribute_quality,
    tf.contact_person,
    tf.domain_data_owner,
    tf.user_comments,
    tf.entity_name,
    tf.meta,
    tf.col_position,
    tf.flag_algorithm,
    tf.table_code,
    tf.object_type,
    tf.editable,
    o.team,
    o.developer_rb,
    rb1.fio AS developer_fio,
    o.analyst_rb,
    rb2.fio AS analyst_fio,
        CASE
            WHEN tf.editable IS NOT NULL THEN (('https://kb.rosbank.rus.socgen/display/ODPP/'::text || tf.src_schema) || '.'::text) || tf.src_table
            ELSE NULL::text
        END AS link_confluence
   FROM table_function tf
     LEFT JOIN dq_sbx.gp_object o ON tf.it_code = o.it_code::text AND tf.src_name = o.src_name::text AND tf.src_schema = o.object_schema::text AND tf.src_table = o.object_name::text AND tf.object_type = o.object_type::text AND tf.editable = 'editable'::text
     LEFT JOIN dq_sbx.rb_list rb1 ON o.developer_rb::text = rb1.rb::text
     LEFT JOIN dq_sbx.rb_list rb2 ON o.analyst_rb::text = rb2.rb::text;

-- Permissions

ALTER TABLE dq_sbx.full_description OWNER TO dq_prof;