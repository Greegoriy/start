#! /usr/local/basement/Python-3.7.4/bin/python3.7

from ldap3 import Server, Connection, SUBTREE
from datetime import datetime,date,timedelta
import sqlite3 as sq
import os

from db_connectors import *


print('*********************************')
print('*         owner_check           *')
print('*********************************')


def get_query_from_df(schema, table, df):
    """Сформировать запрос для insert в таблицу из df"""
    query_list = []
    df = df.fillna('NULL')
    for index, row in df.iterrows():
        row = row.apply(lambda x: x.replace("'",'`') if type(x) == str else 
                        (str(x) if type(x) == pd._libs.tslibs.timestamps.Timestamp or type(x) == date else float(x)))
        query_list.append(str(tuple(row)).replace("'NULL'", "NULL").replace("''", "NULL"))

    query_full = f'INSERT INTO {schema}.{table} VALUES' +  ', '.join(query_list)
    return query_full

# Параметры LDAP
attr = ['member']

AD_SERVER = 'rosbank.rus.socgen'
AD_USER = f"ROSBANK\\{user_pass['user_rb']}"
AD_PASSWORD = user_pass['pass_rb']
AD_SEARCH_TREE = 'DC=rosbank,DC=rus,DC=socgen'

#соединяюсь с сервером. LDAP
server = Server(AD_SERVER)
conn = Connection(server, user=AD_USER, password=AD_PASSWORD)

# Функция поиска юзера по LDAP 
def findUser(login):
    """ Поиск по базе LDAP пользователя """
    at=['distinguishedName','department','userAccountControl','manager']
    conn.bind()
    userDN = None
    base = "DC=rosbank,DC=rus,DC=socgen"
    search_filter = '(&(objectClass=user)(sAMAccountName=%s))'% (login)
    x = conn.search(base, search_filter,attributes=at)
    if x != False:
        userDN = conn.response[0]['attributes']
        conn.unbind()
    return [login,userDN['distinguishedName'].split(',')[0][3:],userDN['distinguishedName'].split(',')[2][3:], 
            userDN['userAccountControl'], userDN['department'], userDN['manager'].split(',')[0][3:] ]


df_owner = get_df_from_dq_profiling_ro("""
SELECT 
    rb
FROM  dq_sbx.data_owner
WHERE flag_confirm = True
GROUP BY rb
""")


# Приклеем по rb пользователей
owner_check = []
for i in list(df_owner['rb']):
    owner_check.append(findUser(i))
owner_check = pd.DataFrame(owner_check)

# Запись в таблицу
execute_dq_profiling('TRUNCATE dq_sbx.owner_check')
execute_dq_profiling(get_query_from_df('dq_sbx', 'owner_check', owner_check))

print('owner_check - готово')