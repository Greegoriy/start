#! /usr/local/basement/Python-3.7.4/bin/python3.7

import time
import numpy as np
from datetime import date


from db_connectors import *

print('*********************************')
print('*         rb_list.py            *')
print('*********************************')

""" Скрипт собирает не уволенных пользователей и их rb Замена GP - БК"""

def get_query_from_df(schema, table, df):
    """Сформировать запрос для insert в таблицу из df"""
    query_list = []
    df = df.fillna('NULL')
    for index, row in df.iterrows():
        row = row.apply(lambda x: x.replace("'",'`') if type(x) == str else 
                        (str(x) if type(x) == pd._libs.tslibs.timestamps.Timestamp or type(x) == date else float(x)))
        query_list.append(str(tuple(row)).replace("'NULL'", "NULL").replace("''", "NULL"))

    query_full = f'INSERT INTO {schema}.{table} VALUES' +  ', '.join(query_list)
    return query_full

# Тащим данные из ODPP
query = """
SELECT 
    CASE 
        WHEN split(t.department_full_nm, ' -> ')[4] IS NOT NULL THEN split(t.department_full_nm, ' -> ')[4]
        ELSE split(t.department_full_nm, ' -> ')[size(split(t.department_full_nm, ' -> ')) -1] 
        END as department,
    t.job_desc,
    t.client_nm as fio,
    lower(t.employee_login) as rb
FROM (SELECT employee_login, max(dt_from) as dt_from FROM hist_gp_etl.dm_employee_list GROUP BY employee_login) as tt
LEFT JOIN hist_gp_etl.dm_employee_list as t ON tt.employee_login = t.employee_login AND tt.dt_from = t.dt_from
"""
rb_df = get_df_from_hive(query)
query = get_query_from_df('dq_sbx','rb_list',rb_df)
execute_dq_profiling("truncate dq_sbx.rb_list")
execute_dq_profiling(query)

print('rb_list - готово!')