#! /usr/local/basement/Python-3.7.4/bin/python3.7

import datetime

from db_connectors import *

print('*********************************')
print('*       product_code_NA.py      *')
print('*********************************')


# Ищем не заполненные product_code

params = {}
params['dates'] = []

# дата последнего отчёта
params['d'] = get_df_from_hive("""select max(businessdate) as businessdate FROM dq_sbx.zhoh_product_code_NA""").loc[0, 'businessdate']
df_dates = get_df_from_mart("""SELECT DISTINCT BUSINESSDATE FROM PWCCALC.EXPINFO WHERE  BUSINESSDATE > '{d}'""".format(**params))

if (len(df_dates)) < 1:
    raise SystemExit('Новых данных на витрине нет')    


# получаем данные с витрины IFRS9
query = """
    SELECT 
        DISTINCT
        ex.BUSINESSDATE, 
        BANK_ACCOUNT,
        BRANCH,
        CLIENT,
        PRODUCTID,
        BRANCHCODE
    FROM (SELECT DISTINCT BUSINESSDATE FROM PWCCALC.EXPINFO WHERE BUSINESSDATE > '{d}') as ex
    LEFT JOIN (
                SELECT 
                    e.BUSINESSDATE, 
                    substr(e.EXPID, 7,4) || '-' || substr(e.EXPID, 11,6) || '-' || substr(e.EXPID, 17,3) as BANK_ACCOUNT,
                    substr(e.EXPID, 7,4) as BRANCH,
                    substr(e.EXPID, 11,6) as CLIENT,
                    e.PRODUCTID as PRODUCTID,
                    c.BRANCHCODE as BRANCHCODE
                FROM PWCCALC.EXPINFO as e
                LEFT JOIN PWCCALC.CLIENTINFO as c 
                    ON e.BUSINESSDATE = c.BUSINESSDATE
                    AND e.CLIENTID = c.CLIENTID
                    AND e.PRTFLTPCD = c.PRTFLTPCD
                WHERE 1=1
                    AND e.PRODUCTID = 'N/A'
                    AND e.BUSINESSDATE > '{d}'
                ORDER BY e.BUSINESSDATE DESC
                ) t
        ON t.BUSINESSDATE = ex.BUSINESSDATE
    ORDER BY ex.BUSINESSDATE
    """
df = (get_df_from_mart(query.format(**params)))
df.fillna('NULL', inplace=True)



# Обработка строк
def params_string(s):
    if s is not None and s != 'NULL' and s != 'null' and s != 'nan':
        s = str(s).replace("[", "")
        s = str(s).replace("]", "")
        s = str(s).replace("{", "")
        s = str(s).replace("}", "")
        s = str(s).replace("Timestamp('", "")
        s = str(s).replace(" 00:00:00')", "")
        s = str(s).replace(" 00:00:00", "")
        s = str(s).replace("'", '"')
        s = "'" + s + "'"
    else:
        s = 'NULL'
    return s


# query для дашборда
def query_params_dashboard(tmp):
    query_full = """
    INSERT INTO dq_sbx.zhoh_product_code_NA VALUES 
    """  
    params = {} 
    for i,s in tmp.iterrows():
        params['BUSINESSDATE']= params_string(s[0])
        params['BANK_ACCOUNT']= params_string(s[1])
        params['BRANCH']= params_string(s[2])  
        params['CLIENT']= params_string(s[3])
        params['PRODUCTID']= params_string(s[4])
        params['BRANCHCODE']= params_string(s[5])
        
        query = """ (
        {BUSINESSDATE},
        {BANK_ACCOUNT},
        {BRANCH},
        {CLIENT},
        {PRODUCTID},
        {BRANCHCODE}
        )
        ,"""
        query = query.format(**params)
        query_full = query_full + query
    query_full = query_full[:-1]
    query_full = query_full.replace("'NULL'", "NULL")
    return query_full

query = query_params_dashboard(df)
execute_hive(query)

print('product_code_NA.py - готово')