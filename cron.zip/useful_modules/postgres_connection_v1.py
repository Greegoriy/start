import psycopg2
from psycopg2.pool import ThreadedConnectionPool
import pandas as pd
import json

with open("user_pass.json", "r") as read_file:
    user_pass = json.load(read_file)
    
    
pg_pool = ThreadedConnectionPool(minconn=1, 
                                    maxconn=2, 
                                    user=user_pass['user_dq_prof'],
                                    password=user_pass['pass_dq_prof'], 
                                    host='193.48.6.35', 
                                    port=5432,
                                    dbname='dq_profiling')


class PostgresConnection:
            
    def __init__(self, db_connection: ThreadedConnectionPool):
        self.db_connection = db_connection
    
    
    def getData(self, query: str) -> pd.DataFrame:
        db = self.db_connection.getconn()
        cursor = db.cursor()
        try:
            cursor.execute(query)
            columns=[column[0] for column in cursor.description]
            records=cursor.fetchall()
            return pd.DataFrame(data=records, columns=columns)
        except Exception as e:
            print(e)
        finally:
            self.db_connection.putconn(db)
            cursor.close()